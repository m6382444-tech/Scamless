import React from 'react';
import { X, Brain, ShieldCheck, AlertTriangle, Lightbulb, ArrowRight, ArrowLeft, BookOpen } from 'lucide-react';
import { PSYCHOLOGICAL_TRICKS } from '../data/psychologyTricks';

export default function MobileBottomSheet({ highlight, onClose, allHighlights, onSelectHighlight }) {
  if (!highlight) return null;

  const trick = highlight.trickData || PSYCHOLOGICAL_TRICKS[highlight.trickKey] || PSYCHOLOGICAL_TRICKS.urgency;

  const currentIndex = allHighlights ? allHighlights.findIndex(h => h.id === highlight.id) : -1;
  const hasPrev = currentIndex > 0;
  const hasNext = allHighlights && currentIndex < allHighlights.length - 1;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      
      {/* Backdrop tap to close */}
      <div className="absolute inset-0" onClick={onClose}></div>

      {/* Slide-Up Sheet Container */}
      <div className="relative w-full max-w-lg bg-slate-900 border-t border-slate-700/80 rounded-t-[28px] p-5 pb-8 shadow-2xl max-h-[88vh] overflow-y-auto animate-in slide-in-from-bottom duration-300 z-10 space-y-4">
        
        {/* Top Pull Handle */}
        <div className="w-12 h-1.5 bg-slate-700 rounded-full mx-auto mb-2 opacity-80 cursor-grab" onClick={onClose}></div>

        {/* Header with Title and Close Button */}
        <div className="flex items-start justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 shrink-0">
              <Brain className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                  {highlight.label}
                </span>
                <span className="text-[10px] font-semibold text-rose-400">
                  {highlight.severity}
                </span>
              </div>
              <h3 className="text-base sm:text-lg font-bold text-white mt-0.5">
                {trick.title}
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Trigger Quote */}
        <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs sm:text-sm text-rose-300">
          <span className="text-[10px] text-slate-400 font-sans font-bold uppercase tracking-wider block mb-0.5">
            Trigger In Message:
          </span>
          <span className="font-bold text-rose-200">"{highlight.text}"</span>
        </div>

        {/* Structured Sections */}
        <div className="space-y-3 text-xs sm:text-sm">
          
          {/* Plain-English Explanation */}
          <div className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700/60 space-y-1">
            <div className="flex items-center space-x-1.5 text-amber-400 font-bold">
              <Lightbulb className="w-4 h-4 shrink-0" />
              <span>Plain-English Meaning</span>
            </div>
            <p className="text-slate-300 leading-relaxed text-[13px]">
              {trick.description}
            </p>
          </div>

          {/* Why Scammers Do This */}
          <div className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700/60 space-y-1">
            <div className="flex items-center space-x-1.5 text-rose-400 font-bold">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>The Psychological Trap</span>
            </div>
            <p className="text-slate-300 leading-relaxed text-[13px]">
              {trick.whyScammersUseIt}
            </p>
          </div>

          {/* Legitimate Organization Policy */}
          <div className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700/60 space-y-1">
            <div className="flex items-center space-x-1.5 text-indigo-400 font-bold">
              <BookOpen className="w-4 h-4 shrink-0" />
              <span>How Real Organizations Work</span>
            </div>
            <p className="text-slate-300 leading-relaxed text-[13px]">
              {trick.legitimateReality}
            </p>
          </div>

          {/* Safe Alternative */}
          <div className="p-3.5 rounded-xl bg-emerald-950/30 border border-emerald-500/40 space-y-1">
            <div className="flex items-center space-x-1.5 text-emerald-400 font-bold">
              <ShieldCheck className="w-4 h-4 shrink-0" />
              <span>What You Should Do Now</span>
            </div>
            <p className="text-emerald-200/90 leading-relaxed text-[13px]">
              {trick.safeAlternative}
            </p>
          </div>

        </div>

        {/* Bottom Navigation between triggers */}
        {allHighlights && allHighlights.length > 1 && (
          <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
            <button
              disabled={!hasPrev}
              onClick={() => onSelectHighlight(allHighlights[currentIndex - 1])}
              className={`px-3 py-2 rounded-xl border border-slate-700 flex items-center space-x-1 font-medium ${
                hasPrev ? 'bg-slate-800 text-slate-200' : 'opacity-40 text-slate-500'
              }`}
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Previous</span>
            </button>

            <span className="text-slate-400 font-medium">
              {currentIndex + 1} / {allHighlights.length}
            </span>

            <button
              disabled={!hasNext}
              onClick={() => onSelectHighlight(allHighlights[currentIndex + 1])}
              className={`px-3 py-2 rounded-xl bg-rose-600 text-white flex items-center space-x-1 font-bold ${
                hasNext ? 'hover:bg-rose-500' : 'opacity-40 cursor-not-allowed'
              }`}
            >
              <span>Next</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

      </div>
    </div>
  );
}
