import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import MobileBottomNav from './components/MobileBottomNav';
import ScamAnalyzer from './components/ScamAnalyzer';
import WhatsAppVerifier from './components/WhatsAppVerifier';
import QrScanner from './components/QrScanner';
import ImageMailScanner from './components/ImageMailScanner';
import CallGuardian from './components/CallGuardian';
import UrlSandbox from './components/UrlSandbox';
import TemplateSelector from './components/TemplateSelector';
import EmergencyHub from './components/EmergencyHub';
import { SCAM_TEMPLATES } from './data/templates';
import { analyzeMessageNLP } from './services/nlpEngine';
import { Wifi, Battery, Signal, Shield, Smartphone } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState('scanner');
  const [deviceFrameMode, setDeviceFrameMode] = useState(false); // Toggle mobile device mockup frame
  
  // By default: Keep Interactive User Mode ON (blank input ready for user)
  const [inputText, setInputText] = useState('');
  const [sandboxUrl, setSandboxUrl] = useState('https://bit.ly/power-pay-bill');
  const [guardianPhone, setGuardianPhone] = useState('+91 98765 43210');

  // Handle WhatsApp Share-to-Scan incoming URL parameters (?scan=... or ?tab=...)
  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const scanParam = params.get('scan') || params.get('text') || params.get('msg');
      const tabParam = params.get('tab');
      
      if (scanParam) {
        setInputText(decodeURIComponent(scanParam));
        if (tabParam) {
          setActiveTab(tabParam);
        } else {
          setActiveTab('scanner');
        }
      } else if (tabParam) {
        setActiveTab(tabParam);
      }
    } catch (e) {
      console.warn("Failed to parse URL search params:", e);
    }
  }, []);

  const currentAnalysis = analyzeMessageNLP(inputText);

  const handleNavigateToSandbox = (url) => {
    setSandboxUrl(url);
    setActiveTab('sandbox');
  };

  const handleNavigateToCallGuardian = (phone) => {
    setGuardianPhone(phone);
    setActiveTab('call-guardian');
  };

  const handleSelectTemplate = (template) => {
    setInputText(template.message);
    setActiveTab('scanner');
  };

  // Main active tab content
  const renderTabContent = () => {
    switch (activeTab) {
      case 'scanner':
        return (
          <ScamAnalyzer
            inputText={inputText}
            setInputText={setInputText}
            onNavigateToSandbox={handleNavigateToSandbox}
            onNavigateToCallGuardian={handleNavigateToCallGuardian}
            onNavigateToEmergency={() => setActiveTab('emergency')}
          />
        );
      case 'whatsapp':
        return (
          <WhatsAppVerifier
            onNavigateToSandbox={handleNavigateToSandbox}
            onNavigateToCallGuardian={handleNavigateToCallGuardian}
            onNavigateToEmergency={() => setActiveTab('emergency')}
          />
        );
      case 'qr-shield':
        return (
          <QrScanner
            onNavigateToSandbox={handleNavigateToSandbox}
          />
        );
      case 'image-mail':
        return (
          <ImageMailScanner
            onNavigateToSandbox={handleNavigateToSandbox}
            onNavigateToCallGuardian={handleNavigateToCallGuardian}
          />
        );
      case 'call-guardian':
        return (
          <CallGuardian
            prefilledNumber={guardianPhone}
          />
        );
      case 'sandbox':
        return (
          <UrlSandbox
            initialUrl={sandboxUrl}
          />
        );
      case 'templates':
        return (
          <TemplateSelector
            onSelectTemplate={handleSelectTemplate}
          />
        );
      case 'emergency':
        return (
          <EmergencyHub
            currentAnalysis={currentAnalysis}
            rawText={inputText}
            senderNumber={guardianPhone}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-rose-500 selection:text-white">
      {/* Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        deviceFrameMode={deviceFrameMode}
        setDeviceFrameMode={setDeviceFrameMode}
      />

      {/* Main Viewport Container */}
      {deviceFrameMode ? (
        /* ================= SMARTPHONE MOCKUP FRAME MODE ================= */
        <div className="flex-1 flex flex-col items-center justify-center p-2 sm:p-6 bg-slate-900/50">
          
          <div className="text-center mb-3 text-xs text-slate-400 flex items-center space-x-1.5">
            <Smartphone className="w-3.5 h-3.5 text-rose-500" />
            <span>Interactive Mobile Device Simulator (iPhone 16 Pro Layout)</span>
          </div>

          {/* Smartphone Frame Outer Shell */}
          <div className="relative w-full max-w-[420px] h-[840px] bg-slate-950 rounded-[50px] p-3 shadow-2xl border-[8px] border-slate-800 shadow-rose-950/20 flex flex-col overflow-hidden ring-1 ring-white/10">
            
            {/* Dynamic Island & Speaker */}
            <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 flex items-center justify-between w-32 h-6 bg-black rounded-full px-3.5 shadow-md">
              <div className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-800"></div>
              <div className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-indigo-950/60"></div>
            </div>

            {/* Mobile Status Bar (9:41 AM, 5G, Battery) */}
            <div className="pt-2 px-6 pb-1 flex items-center justify-between text-[11px] font-semibold text-slate-300 z-40 select-none">
              <span>9:41</span>
              <div className="flex items-center space-x-1.5 text-slate-400">
                <Signal className="w-3 h-3" />
                <Wifi className="w-3 h-3" />
                <Battery className="w-3.5 h-3.5 text-slate-200" />
              </div>
            </div>

            {/* Internal Mobile Scrollable App Screen */}
            <div className="flex-1 overflow-y-auto px-3 pt-2 pb-24 scrollbar-none overscroll-contain">
              {renderTabContent()}
            </div>

            {/* Mobile Bottom Navigation Bar (Inside Frame) */}
            <div className="absolute bottom-0 left-0 right-0 z-40">
              <MobileBottomNav
                activeTab={activeTab}
                setActiveTab={setActiveTab}
                triggerCount={currentAnalysis.highlights.length}
              />
              {/* Home Indicator Bar */}
              <div className="w-32 h-1 bg-slate-600/70 rounded-full mx-auto my-1.5"></div>
            </div>

          </div>

        </div>
      ) : (
        /* ================= FULL RESPONSIVE MOBILE WEB VIEW ================= */
        <div className="flex-1 flex flex-col pb-20 md:pb-8">
          <main className="max-w-5xl w-full mx-auto px-3 sm:px-6 py-4 sm:py-6">
            {renderTabContent()}
          </main>

          {/* Fixed Mobile Bottom Navigation Bar (Shown on mobile & narrow screens) */}
          <div className="md:hidden">
            <MobileBottomNav
              activeTab={activeTab}
              setActiveTab={setActiveTab}
              triggerCount={currentAnalysis.highlights.length}
            />
          </div>
        </div>
      )}

      {/* Global Compact Footer */}
      {!deviceFrameMode && (
        <footer className="hidden md:block bg-slate-950 border-t border-slate-800/80 py-5 text-center text-xs text-slate-500">
          ScamLens Pro Defense Shield • Citizens Cyber Protection Hub (1930 Helpline & Chakshu Sanchar Saathi)
        </footer>
      )}
    </div>
  );
}
