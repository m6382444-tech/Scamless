export const SCAM_TEMPLATES = [
  {
    id: "electricity-bill",
    title: "Electricity Disconnection Threat",
    category: "Utility Fraud",
    urgencyLevel: "Critical",
    sender: "+91 98765 43210 (Spoofed 'Electricity Officer')",
    channel: "SMS / WhatsApp",
    summary: "Threatens immediate power cutoff tonight unless victim calls a personal mobile number or pays through an unofficial link.",
    message: "Dear Consumer, your electricity power will be disconnected tonight at 9:30 PM from the electricity office because your previous month bill was not updated. Please immediately contact our electricity officer Mr. Sharma at 9876543210 or update bill online at bit.ly/power-pay-bill to avoid disconnection. - Electricity Dept.",
    tags: ["Mahavitaran", "BSES", "UPPCL", "Urgency Trap"]
  },
  {
    id: "india-post",
    title: "India Post Failed Delivery & ₹25 Fee",
    category: "Courier / Smishing",
    urgencyLevel: "High",
    sender: "+91 91234 56789 (Posing as India Post)",
    channel: "SMS",
    summary: "Claims parcel could not be delivered due to incomplete address. Asks for a tiny ₹25 redelivery fee to harvest debit/credit card CVV and OTP.",
    message: "India Post: Your parcel consignment IN98273641IN cannot be delivered to your address due to incomplete house number. Please update your delivery address and pay ₹25 redelivery fee within 24 hours at indiapost-track-update.cc/track or the package will be permanently returned to sender.",
    tags: ["India Post", "Package Delivery", "Micro-Fee Trap", "Phishing Link"]
  },
  {
    id: "sbi-kyc",
    title: "SBI YONO Account Suspended (KYC Update)",
    category: "Banking Phishing",
    urgencyLevel: "Critical",
    sender: "AD-SBIPAY / +91 87654 32109",
    channel: "SMS / WhatsApp",
    summary: "Threatens that your bank account or YONO access will be blocked within 2 hours unless you update Aadhaar and PAN on a spoofed portal.",
    message: "Dear SBI User, your YONO NetBanking account has been blocked today due to pending KYC verification. Please click immediately on https://sbi-kyc-verify-portal.top to update your PAN and Aadhaar details within 2 hours, otherwise your bank account will be permanently deactivated. - State Bank of India",
    tags: ["State Bank of India", "YONO", "KYC Fraud", "Credential Theft"]
  },
  {
    id: "digital-arrest",
    title: "CBI / Police 'Digital Arrest' Threat",
    category: "Extortion / Impersonation",
    urgencyLevel: "Critical",
    sender: "+92 300 1234567 / +91 99887 76655 (Posing as CBI/Cyber Cell)",
    channel: "WhatsApp / Direct Call",
    summary: "Claims 14 illegal SIMs or contraband parcel was seized in victim's name. Claims victim is under 'Digital Arrest' and must join Skype video call.",
    message: "Urgent Legal Notice from Central Bureau of Investigation (CBI) & Telecom Regulatory Authority of India (TRAI): A criminal case FIR #492/2026 has been registered against you at Delhi Cyber Cell. 14 illegal SIM cards used in money laundering and narcotics trafficking were found registered under your Aadhaar. You are placed under immediate DIGITAL ARREST. Do not disconnect this call or leave your room. Join the official CBI interrogation video room now at cbi-cyber-investigation.online/court or warrant of arrest will be executed within 60 minutes.",
    tags: ["Digital Arrest", "CBI", "TRAI", "Extortion", "Video Interrogation"]
  },
  {
    id: "traffic-challan-apk",
    title: "Traffic Police e-Challan APK Scam",
    category: "Malware / APK Dropper",
    urgencyLevel: "Critical",
    sender: "VK-ECHLN / +91 78901 23456",
    channel: "SMS",
    summary: "Alleges an unpaid traffic challan and non-bailable warrant, directing victim to download an '.apk' file that reads SMS and OTPs.",
    message: "Virtual Court Notice: Challan No. DL-89230198 for vehicle overspeeding is unpaid. Fine amount: ₹2,500. Due to non-payment, non-bailable court warrant issued. Immediately clear your fine within 48 hours or surrender at court. Download official Virtual Court e-Challan App to pay online: http://echallan-parivahan-gov.buzz/echallan.apk",
    tags: ["Traffic Police", "eChallan", "APK Malware", "SmsSpy Trojan"]
  },
  {
    id: "job-task-scam",
    title: "Work From Home 'YouTube Like' Job",
    category: "Task / Investment Fraud",
    urgencyLevel: "Medium",
    sender: "+1 (415) 890-1234 / Telegram @official_hr_tasks",
    channel: "WhatsApp / Telegram",
    summary: "Lures victim with promises of ₹2,000 to ₹8,000 daily for liking videos, which evolves into 'prepaid merchant recharge' task fraud.",
    message: "Congratulations! We have reviewed your resume and selected you for our online part-time job. Earn ₹2,000 to ₹8,000 daily from home just by liking YouTube videos and rating hotels on Google Maps. No investment required! Instant daily payment via Google Pay or PhonePe. Only 15 vacancies left today. Contact HR Manager Priya on Telegram: t.me/official_hr_tasks to claim your ₹500 joining bonus immediately.",
    tags: ["Part Time Job", "Telegram Task Scam", "Fake Salary", "Greed Bait"]
  },
  {
    id: "kbc-lottery",
    title: "Kaun Banega Crorepati (KBC) WhatsApp Lottery",
    category: "Lottery Advance Fee",
    urgencyLevel: "High",
    sender: "+92 345 6789012 (Pakistan VOIP sender)",
    channel: "WhatsApp Audio / Image",
    summary: "Sends fake Amitabh Bachchan letter claiming victim won ₹25 Lakh lottery in Jio/Airtel lucky draw, requiring ₹15,000 'processing tax'.",
    message: "Congratulations Dear Sir/Madam! Your mobile SIM card has won ₹25,00,000 (25 Lakh Rupees) in Kaun Banega Crorepati (KBC) Lucky Draw organized by Reliance Jio. Your lottery number is KBC-8921. To claim your cash prize directly in your bank account today, contact KBC Head Office Manager Rana Pratap Singh on WhatsApp at +92-345-6789012. You must pay refundable processing tax of ₹12,500 within 24 hours to release the bank draft.",
    tags: ["KBC Lottery", "WhatsApp Fraud", "Advance Fee", "+92 Number"]
  },
  {
    id: "credit-card-points",
    title: "Credit Card Reward Points Expiry to Cash",
    category: "Card Credential Phishing",
    urgencyLevel: "High",
    sender: "BP-HDFCBK / +91 93456 78901",
    channel: "SMS",
    summary: "Claims ₹9,850 worth of reward points are expiring today and can be converted to instant bank cash via a phishing link.",
    message: "Dear Cardholder, your 9,850 accumulated Credit Card Reward Points worth ₹9,850 will expire tonight at 11:59 PM. Click http://hdfc-reward-redeem-cash.top to redeem points directly into your savings account as cash. Enter card number, expiry date and CVV to claim.",
    tags: ["HDFC Bank", "Reward Points", "CVV Theft", "Phishing Portal"]
  }
];
