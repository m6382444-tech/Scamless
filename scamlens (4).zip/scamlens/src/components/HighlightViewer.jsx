import React from 'react';
import { AlertCircle, Clock, Link2, Award, CreditCard, ShieldX, DollarSign, MousePointerClick, ShieldCheck, Edit3 } from 'lucide-react';

const CATEGORY_STYLES = {
  urgency: {
    bg: 'bg-rose-500/25 text-rose-100 border-b-2 border-rose-500 hover:bg-rose-500/40 ring-1 ring-rose-500/40',
    icon: Clock,
    badgeText: 'Urgency (Red)',
    dotColor: 'bg-rose-500',
    tagColor: 'text-rose-300 bg-rose-500/20 border-rose-500/40'
  },
  suspicious_link: {
    bg: 'bg-orange-500/25 text-orange-100 border-b-2 border-orange-500 hover:bg-orange-500/40 ring-1 ring-orange-500/40',
    icon: Link2,
    badgeText: 'Suspicious Link (Orange)',
    dotColor: 'bg-orange-500',
    tagColor: 'text-orange-300 bg-orange-500/20 border-orange-500/40'
  },
  fake_authority: {
    bg: 'bg-yellow-500/25 text-yellow-100 border-b-2 border-yellow-400 hover:bg-yellow-500/40 ring-1 ring-yellow-400/40',
    icon: Award,
    badgeText: 'Fake Authority (Yellow)',
    dotColor: 'bg-yellow-400',
    tagColor: 'text-yellow-200 bg-yellow-500/20 border-yellow-500/40'
  },
  financial_trap: {
    bg: 'bg-purple-500/25 text-purple-100 border-b-2 border-purple-500 hover:bg-purple-500/40 ring-1 ring-purple-500/40',
    icon: CreditCard,
    badgeText: 'Financial / OTP Trap',
    dotColor: 'bg-purple-500',
    tagColor: 'text-purple-300 bg-purple-500/20 border-purple-500/40'
  },
  fear_intimidation: {
    bg: 'bg-sky-500/25 text-sky-100 border-b-2 border-sky-500 hover:bg-sky-500/40 ring-1 ring-sky-500/40',
    icon: ShieldX,
    badgeText: 'Intimidation',
    dotColor: 'bg-sky-400',
    tagColor: 'text-sky-300 bg-sky-500/20 border-sky-500/40'
  },
  greed_bait: {
    bg: 'bg-emerald-500/25 text-emerald-100 border-b-2 border-emerald-500 hover:bg-emerald-500/40 ring-1 ring-emerald-500/40',
    icon: DollarSign,
    badgeText: 'Greed / Task Bait',
    dotColor: 'bg-emerald-400',
    tagColor: 'text-emerald-300 bg-emerald-500/20 border-emerald-500/40'
  }
};

export default function HighlightViewer({ analysis, selectedHighlight, onSelectHighlight, rawText }) {
  if (!analysis || !analysis.segments) return null;

  const hasHighlights = analysis.highlights && analysis.highlights.length > 0;
  const hasText = rawText && rawText.trim().length > 0;

  return (
    <div className="space-y-3">
      {/* Interactive Legend Bar */}
      <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 text-xs bg-slate-900/80 p-2.5 sm:p-3 rounded-xl border border-slate-800">
        <span className="text-slate-400 font-semibold flex items-center space-x-1 mr-1">
          <MousePointerClick className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
          <span>Interactive Legend:</span>
        </span>
        
        <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-md bg-rose-500/15 border border-rose-500/30 text-rose-300 font-medium text-[11px]">
          <span className="w-2 h-2 rounded-full bg-rose-500"></span>
          <span>Urgency (Red)</span>
        </span>

        <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-md bg-orange-500/15 border border-orange-500/30 text-orange-300 font-medium text-[11px]">
          <span className="w-2 h-2 rounded-full bg-orange-500"></span>
          <span>Suspicious Link (Orange)</span>
        </span>

        <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-md bg-yellow-500/15 border border-yellow-500/30 text-yellow-300 font-medium text-[11px]">
          <span className="w-2 h-2 rounded-full bg-yellow-400"></span>
          <span>Fake Authority (Yellow)</span>
        </span>

        <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-md bg-purple-500/15 border border-purple-500/30 text-purple-300 font-medium text-[11px]">
          <span className="w-2 h-2 rounded-full bg-purple-500"></span>
          <span>Financial / OTP Trap</span>
        </span>

        <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-md bg-sky-500/15 border border-sky-500/30 text-sky-300 font-medium text-[11px]">
          <span className="w-2 h-2 rounded-full bg-sky-400"></span>
          <span>Intimidation</span>
        </span>
      </div>

      {/* Main Render Canvas */}
      {!hasText ? (
        <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 text-center space-y-2">
          <Edit3 className="w-8 h-8 text-slate-600 mx-auto" />
          <p className="text-sm font-semibold text-slate-300">
            Interactive Analysis Ready
          </p>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Type or paste any suspicious SMS, message or URL into the text box above to see red flags highlighted live.
          </p>
        </div>
      ) : !hasHighlights ? (
        <div className="p-4 sm:p-5 rounded-2xl bg-emerald-950/20 border border-emerald-500/30 text-xs sm:text-sm text-emerald-300 space-y-2">
          <div className="flex items-center space-x-2 font-bold text-white">
            <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
            <span>No Overt Manipulation Triggers Detected</span>
          </div>
          <p className="text-emerald-200/90 leading-relaxed text-xs">
            We didn't detect common high-pressure urgency words, suspicious URL shorteners, or spoofed authority patterns in this text.
          </p>
          <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 font-mono text-xs text-slate-300">
            "{rawText}"
          </div>
        </div>
      ) : (
        <div className="relative p-4 sm:p-5 rounded-2xl bg-slate-900 border border-slate-800 font-mono text-xs sm:text-sm leading-relaxed tracking-wide text-slate-200 shadow-inner">
          <div className="text-[10px] font-sans font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center justify-between border-b border-slate-800 pb-1.5">
            <span>Live Color-Coded Highlighter</span>
            <span className="text-rose-400">{analysis.highlights.length} Triggers Active</span>
          </div>

          <div>
            {analysis.segments.map((segment, index) => {
              if (segment.type === 'text') {
                return <span key={index} className="whitespace-pre-wrap">{segment.text}</span>;
              }

              const hl = segment.highlight;
              const style = CATEGORY_STYLES[hl.category] || CATEGORY_STYLES.urgency;
              const isSelected = selectedHighlight && selectedHighlight.id === hl.id;

              return (
                <button
                  key={index}
                  onClick={() => onSelectHighlight(hl)}
                  className={`inline cursor-pointer px-1.5 py-0.5 mx-0.5 rounded transition-all duration-150 font-semibold text-left relative group ${style.bg} ${
                    isSelected ? 'ring-2 ring-white shadow-lg scale-[1.03]' : ''
                  }`}
                  title={`Click to inspect: ${hl.label} - ${hl.trickData ? hl.trickData.title : ''}`}
                >
                  <span>{segment.text}</span>
                  
                  {/* Floating trigger indicator tag */}
                  <span className={`inline-block ml-1 text-[9px] font-bold uppercase tracking-wider px-1 py-0.1 rounded border ${style.tagColor} select-none`}>
                    {hl.label}
                  </span>
                </button>
              );
            })}
          </div>

          <p className="mt-3 pt-2 border-t border-slate-800/80 text-[11px] font-sans text-slate-400 flex items-center space-x-1.5">
            <AlertCircle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>
              Tap any highlighted trigger above to reveal the psychological manipulation trick behind it.
            </span>
          </p>
        </div>
      )}
    </div>
  );
}
