export const PSYCHOLOGICAL_TRICKS = {
  urgency: {
    title: "Artificial Urgency & Time Compression",
    color: "rose",
    badge: "Urgency Tactic",
    description: "The scammer imposes an arbitrary, artificial deadline (e.g. 'within 2 hours', 'tonight at 9:30 PM', 'within 24 hours').",
    whyScammersUseIt: "High stress and immediate deadlines trigger the 'fight-or-flight' survival response in human neurology. This shuts down logical deliberation, stops the victim from verifying with family or official channels, and forces a panicked mistake.",
    legitimateReality: "Real institutions (banks, electricity boards, courts, tax departments) operate under strict legal statutory notice periods. They never disconnect utilities at night, suspend bank accounts within 2 hours, or issue sudden arrest ultimatums via SMS.",
    safeAlternative: "Step back, take three deep breaths, and never react on the sender's timeline. Open the official utility app or visit the physical bank branch independently."
  },
  fake_authority: {
    title: "Authority Impersonation & Institutional Cloaking",
    color: "amber",
    badge: "Fake Authority",
    description: "The scammer mimics legitimate authorities such as CBI, Police, India Post, State Bank of India, TRAI, or an 'Electricity Officer'.",
    whyScammersUseIt: "Human beings are conditioned from childhood to comply with uniforms, badges, government agencies, and banking institutions (Milgram authority bias). Questioning authority feels risky, so victims comply automatically.",
    legitimateReality: "Police and law enforcement NEVER conduct investigations, interrogate citizens, or declare 'Digital Arrests' over WhatsApp, Skype, or phone calls. Official summons are always served in physical stamped paper with official case numbers.",
    safeAlternative: "Hang up immediately. No legitimate officer will penalize you for verifying via official landlines or visiting the nearest local police station."
  },
  suspicious_link: {
    title: "Domain Masking & Weaponized Hyperlinks",
    color: "orange",
    badge: "Suspicious Link",
    description: "The message uses shortened links (bit.ly, tinyurl), deceptive top-level domains (.top, .cc, .buzz), lookalike domains (sbi-kyc-verify.top), or direct .apk downloads.",
    whyScammersUseIt: "Shortened links conceal the actual destination server. Spoofed domains mimic official brand names to trick users into trusting a cloned credential-harvesting webpage.",
    legitimateReality: "Indian banks and government bodies exclusively use official domains (.sbi, .gov.in, .nic.in, official registered .com/co.in) and NEVER use free URL shorteners or unofficial TLDs (.top, .buzz, .cc, .xyz) for critical updates.",
    safeAlternative: "Never click links received in SMS or chat. Manually type the official known website URL (e.g. onlinesbi.sbi or indiapost.gov.in) into your browser bookmark."
  },
  financial_trap: {
    title: "Micro-Fee Compliance / Credential Harvesting Trap",
    color: "purple",
    badge: "Financial Trap",
    description: "The message requests a trivial payment (e.g. '₹25 redelivery fee', '₹10 bill verification') or demands confidential credentials (PAN, Aadhaar, CVV, OTP).",
    whyScammersUseIt: "Psychological 'Foot-in-the-Door' technique: Asking for ₹25 seems harmless, so victim lowers defenses. However, the fake payment gateway captures full card credentials, debit card PIN, and OTP, enabling scammers to drain the entire account.",
    legitimateReality: "India Post does not demand ₹25 redelivery fees via payment links. Banks never require Aadhaar/PAN re-entry on third-party websites or over SMS.",
    safeAlternative: "Treat any request for card details or OTP for small fee waivers as an absolute red flag. Never enter banking credentials on unfamiliar forms."
  },
  fear_intimidation: {
    title: "Coercive Intimidation & Catastrophic Threat",
    color: "blue",
    badge: "Fear & Coercion",
    description: "Threatens catastrophic consequences: 'non-bailable arrest warrant', 'immediate FIR', 'Aadhaar tied to money laundering & narcotics', 'permanent account ban'.",
    whyScammersUseIt: "Fear induces extreme cognitive tunnel vision. When facing perceived social ruin, imprisonment, or financial catastrophe, victims surrender logic to protect themselves.",
    legitimateReality: "There is NO legal concept called 'Digital Arrest' in the Indian Penal Code or Criminal Procedure Code. Neither CBI, ED, nor State Police can place someone under digital house arrest via webcam.",
    safeAlternative: "Remember that true legal notices arrive via registered post. Hang up, do not join video calls, and report immediately to the 1930 Cybercrime Helpline."
  },
  greed_bait: {
    title: "Greed Bait & Sunk-Cost Illusion",
    color: "emerald",
    badge: "Greed / Task Bait",
    description: "Promises effortless money: 'Earn ₹2,000-₹8,000 daily liking YouTube videos', 'Won ₹25 Lakh KBC Lottery', 'Claim ₹9,850 cash from points'.",
    whyScammersUseIt: "Exploits financial vulnerability and optimism. After paying a tiny 'advance tax' or receiving a small ₹150 initial payout, the victim falls into the 'Sunk Cost Fallacy', pouring thousands into fake merchant tasks.",
    legitimateReality: "Nobody pays ₹100 per video like or gives away 25 Lakhs to random phone numbers. Legitimate corporate rewards are redeemed strictly in-app without advance deposits.",
    safeAlternative: "Ignore and block unsolicited job offers from foreign codes (+1, +44, +92) or Telegram recruiters. There is no legitimate work-from-home job that pays for rating Google Maps."
  }
};
