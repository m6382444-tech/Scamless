// Comprehensive dataset of WhatsApp Scams with Multi-Bubble Conversations & Inline Demo Images

// Helper to safely encode SVG strings into valid Data URIs for all browsers
const createSvgDataUri = (svg) => `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg.trim())}`;

// Realistic Inline SVG Demo Images
export const DEMO_IMAGES = {
  digitalArrestSummons: createSvgDataUri(`<svg xmlns="http://www.w3.org/2000/svg" width="400" height="260" viewBox="0 0 400 260" fill="#0f172a"><rect width="400" height="260" rx="12" fill="#1e293b" stroke="#dc2626" stroke-width="2"/><rect x="16" y="16" width="368" height="36" rx="6" fill="#991b1b"/><text x="200" y="38" font-family="sans-serif" font-size="12" font-weight="bold" fill="white" text-anchor="middle" letter-spacing="1">CENTRAL BUREAU OF INVESTIGATION (CBI)</text><text x="200" y="50" font-family="sans-serif" font-size="8" fill="#fca5a5" text-anchor="middle">NEW DELHI CYBER CRIME HEADQUARTERS</text><rect x="250" y="70" width="120" height="28" rx="4" fill="#7f1d1d" stroke="#ef4444" stroke-width="1.5"/><text x="310" y="88" font-family="sans-serif" font-size="9" font-weight="bold" fill="#fecaca" text-anchor="middle">ARREST WARRANT</text><text x="24" y="90" font-family="sans-serif" font-size="11" font-weight="bold" fill="#f8fafc">CASE FILE: FIR-492/2026</text><text x="24" y="112" font-family="sans-serif" font-size="9" fill="#94a3b8">SECTIONS: 420 IPC, 66D IT ACT, PMLA HAWALA</text><text x="24" y="132" font-family="sans-serif" font-size="10" font-weight="bold" fill="#fca5a5">CRIME: ILLEGAL SIMS &amp; MONEY LAUNDERING RS 3.8 CR</text><text x="24" y="152" font-family="sans-serif" font-size="9" fill="#cbd5e1">ACCUSED: MOBILE SUBSCRIBER (AADHAAR VERIFIED)</text><text x="24" y="172" font-family="sans-serif" font-size="9" fill="#cbd5e1">COURT: SPECIAL PMLA SESSIONS COURT, NEW DELHI</text><rect x="24" y="190" width="352" height="34" rx="6" fill="#450a0a" stroke="#ef4444" stroke-width="1"/><text x="200" y="206" font-family="sans-serif" font-size="9" font-weight="bold" fill="#f87171" text-anchor="middle">STATUS: IMMEDIATE DIGITAL ARREST ORDERED</text><text x="200" y="218" font-family="sans-serif" font-size="8" fill="#fca5a5" text-anchor="middle">DO NOT LEAVE ROOM. REMAIN ON WHATSAPP VIDEO CALL.</text><circle cx="60" cy="242" r="10" fill="#b91c1c"/><text x="60" y="246" font-family="sans-serif" font-size="8" font-weight="bold" fill="white" text-anchor="middle">SEAL</text><text x="80" y="245" font-family="sans-serif" font-size="7" fill="#64748b">CHIEF INVESTIGATING OFFICER (CYBER CELL)</text></svg>`),

  partTimeJobPaymentProof: createSvgDataUri(`<svg xmlns="http://www.w3.org/2000/svg" width="400" height="240" viewBox="0 0 400 240" fill="#064e3b"><rect width="400" height="240" rx="12" fill="#064e3b" stroke="#10b981" stroke-width="2"/><circle cx="200" cy="55" r="26" fill="#10b981"/><path d="M190 55 L197 62 L212 47" stroke="white" stroke-width="3" fill="none" stroke-linecap="round"/><text x="200" y="105" font-family="sans-serif" font-size="14" font-weight="bold" fill="white" text-anchor="middle">UPI Payment Successful</text><text x="200" y="140" font-family="sans-serif" font-size="28" font-weight="extrabold" fill="#a7f3d0" text-anchor="middle">₹150.00</text><text x="200" y="162" font-family="sans-serif" font-size="9" fill="#6ee7b7" text-anchor="middle">From: Apex Media Task Rewards</text><text x="200" y="178" font-family="sans-serif" font-size="8" font-family="monospace" fill="#d1fae5" text-anchor="middle">UPI Ref ID: 482910482910 • Completed</text><rect x="40" y="196" width="320" height="28" rx="6" fill="#047857"/><text x="200" y="213" font-family="sans-serif" font-size="9" font-weight="bold" fill="white" text-anchor="middle">TRIAL TASK #1 APPROVED • VIP TASKS UNLOCKED</text></svg>`),

  kbcLotteryCheque: createSvgDataUri(`<svg xmlns="http://www.w3.org/2000/svg" width="400" height="250" viewBox="0 0 400 250" fill="#172554"><rect width="400" height="250" rx="12" fill="#1e1b4b" stroke="#f59e0b" stroke-width="2"/><rect x="16" y="16" width="368" height="36" rx="6" fill="#78350f"/><text x="200" y="38" font-family="sans-serif" font-size="11" font-weight="bold" fill="#fef08a" text-anchor="middle">ALL INDIA SIM CARD WHATSAPP LUCKY DRAW 2026</text><text x="200" y="50" font-family="sans-serif" font-size="8" fill="#fde68a" text-anchor="middle">AUTHORIZED BY JIO TELECOM &amp; KBC ENTERTAINMENT</text><text x="24" y="85" font-family="sans-serif" font-size="10" fill="#94a3b8">PAY TO THE ORDER OF:</text><text x="160" y="85" font-family="sans-serif" font-size="11" font-weight="bold" fill="white">WHATSAPP MOBILE WINNER</text><line x1="24" y1="95" x2="376" y2="95" stroke="#334155" stroke-width="1"/><text x="24" y="120" font-family="sans-serif" font-size="10" fill="#94a3b8">SUM OF RUPEES:</text><text x="140" y="120" font-family="sans-serif" font-size="11" font-weight="bold" fill="#fde047">TWENTY FIVE LAKH RUPEES ONLY</text><rect x="250" y="135" width="126" height="34" rx="4" fill="#854d0e" stroke="#fbbf24" stroke-width="1"/><text x="313" y="156" font-family="sans-serif" font-size="13" font-weight="extrabold" fill="white" text-anchor="middle">₹ 25,00,000/-</text><text x="24" y="180" font-family="sans-serif" font-size="9" fill="#cbd5e1">LOTTERY NO: KBC-9842 • MANAGER: RANA PRATAP SINGH</text><rect x="24" y="198" width="352" height="36" rx="6" fill="#451a03" stroke="#f59e0b" stroke-width="1"/><text x="200" y="213" font-family="sans-serif" font-size="8" font-weight="bold" fill="#fcd34d" text-anchor="middle">MANDATORY GST REGISTRATION TAX: ₹12,500 BEFORE DISBURSEMENT</text><text x="200" y="226" font-family="sans-serif" font-size="8" fill="#fed7aa" text-anchor="middle">CALL WHATSAPP VOICE ONLY: +91 99887 76655</text></svg>`),

  electricityDisconnectionNotice: createSvgDataUri(`<svg xmlns="http://www.w3.org/2000/svg" width="400" height="240" viewBox="0 0 400 240" fill="#1e293b"><rect width="400" height="240" rx="12" fill="#1e293b" stroke="#ea580c" stroke-width="2"/><rect x="16" y="16" width="368" height="36" rx="6" fill="#9a3412"/><text x="200" y="38" font-family="sans-serif" font-size="11" font-weight="bold" fill="white" text-anchor="middle">STATE ELECTRICITY DISTRIBUTION CO. LTD.</text><text x="200" y="50" font-family="sans-serif" font-size="8" fill="#ffedd5" text-anchor="middle">SUB-DIVISION REVENUE AND METERING DIVISION</text><text x="24" y="85" font-family="sans-serif" font-size="10" font-weight="bold" fill="#fca5a5">URGENT NOTICE OF POWER DISCONNECTION</text><text x="24" y="105" font-family="sans-serif" font-size="9" fill="#cbd5e1">CONSUMER NO: 89274019284 • PREVIOUS BILL: UNPAID</text><text x="24" y="125" font-family="sans-serif" font-size="9" fill="#cbd5e1">DISCONNECTION SCHEDULED: TONIGHT AT 09:30 PM SHARP</text><text x="24" y="145" font-family="sans-serif" font-size="9" fill="#94a3b8">RECONNECTION PENALTY: ₹1,500 + 18% GST IF DISCONNECTED</text><rect x="24" y="165" width="352" height="48" rx="6" fill="#431407" stroke="#f97316" stroke-width="1"/><text x="200" y="185" font-family="sans-serif" font-size="9" font-weight="bold" fill="#fdba74" text-anchor="middle">INSTALL OFFICIAL BIJLI UPDATE APP (APK) OR CALL OFFICER</text><text x="200" y="200" font-family="sans-serif" font-size="8" fill="#fed7aa" text-anchor="middle">OFFICER MR. VERMA: 8899001122 • PORTAL: bijli-bill-seva.top</text></svg>`),

  swiggyReceipt: createSvgDataUri(`<svg xmlns="http://www.w3.org/2000/svg" width="400" height="240" viewBox="0 0 400 240" fill="#1e293b"><rect width="400" height="240" rx="12" fill="#111827" stroke="#f97316" stroke-width="1.5"/><rect x="16" y="16" width="368" height="34" rx="6" fill="#ea580c"/><text x="200" y="38" font-family="sans-serif" font-size="12" font-weight="bold" fill="white" text-anchor="middle">SWIGGY FOOD DELIVERY ORDER</text><text x="24" y="78" font-family="sans-serif" font-size="10" fill="#94a3b8">ORDER #SWIG-8942 • PUNJAB GRILL</text><text x="24" y="98" font-family="sans-serif" font-size="10" fill="white">1x Paneer Butter Masala, 2x Garlic Naan</text><text x="24" y="118" font-family="sans-serif" font-size="9" fill="#10b981">PAID ONLINE VIA UPI: ₹540.00</text><rect x="24" y="135" width="352" height="55" rx="8" fill="#1f2937" stroke="#374151"/><text x="200" y="158" font-family="sans-serif" font-size="11" font-weight="bold" fill="white" text-anchor="middle">DELIVERY PARTNER HAS ARRIVED</text><text x="200" y="176" font-family="sans-serif" font-size="12" font-weight="extrabold" fill="#fb923c" text-anchor="middle">SHARE DELIVERY OTP: 4821</text><text x="200" y="215" font-family="sans-serif" font-size="8" fill="#64748b" text-anchor="middle">Share OTP with delivery partner only after food parcel is received.</text></svg>`)
};

export const WHATSAPP_SCAMS = [
  {
    id: 'digital-arrest',
    title: 'CBI "Digital Arrest" Summons',
    senderName: 'IPS Inspector R.K. Patil (Cyber Cell)',
    senderPhone: '+92 301 8472910',
    profileBadge: 'Fake CBI Seal',
    isForwarded: true,
    category: 'Digital Arrest / Extortion',
    urgencyLevel: 'Critical',
    time: '10:42 AM',
    threatScore: 98,
    isScam: true,
    messages: [
      {
        id: 'msg-1',
        sender: 'contact',
        senderName: 'IPS Inspector R.K. Patil',
        time: '10:42 AM',
        isForwarded: true,
        image: DEMO_IMAGES.digitalArrestSummons,
        imageCaption: 'OFFICIAL_CBI_ARREST_WARRANT_492.PDF.JPG',
        text: `🚨 *OFFICIAL SUMMONS - CENTRAL BUREAU OF INVESTIGATION (CBI) & TRAI*

Case File: FIR #492/2026 / Canara Bank Money Laundering.

To Citizen: Your Aadhaar Card (Linked to mobile) has been found in 16 illicit bank accounts with ₹3.8 Crore money transfer linked to Naresh Goyal Jet Airways Hawala case.

A Supreme Court non-bailable arrest warrant has been approved. You are placed under immediate *DIGITAL ARREST*.
1. Do not step out of your room or contact family.
2. Join the official WhatsApp Video Interrogation Room immediately:
👉 https://cbi-court-investigation.online/room/492

Failure to join within 15 minutes will result in local police raid at your home address. - Delhi Cyber Headquarters`
      },
      {
        id: 'msg-2',
        sender: 'contact',
        senderName: 'IPS Inspector R.K. Patil',
        time: '10:44 AM',
        isForwarded: false,
        text: `We are monitoring your location. If you disconnect, a PCR van from your local police station will break your door in 20 minutes. Turn on your video camera immediately.`
      }
    ],
    redFlags: [
      'Digital Arrest does NOT legally exist in Indian Law or CrPC.',
      'Indian Police / CBI NEVER interrogate citizens or issue warrants over WhatsApp video calls.',
      'Caller uses international Pakistani country code (+92).',
      'Extortion trap demanding victim stay isolated on camera while savings accounts are emptied.'
    ],
    safeAlternative: 'Disconnect call immediately, block number, and dial 1930 Cybercrime Helpline.'
  },
  {
    id: 'part-time-job',
    title: 'YouTube Like & Telegram Job Trap',
    senderName: 'Priya Sharma (Global HR Team)',
    senderPhone: '+84 92 817 4021',
    profileBadge: 'HR Specialist',
    isForwarded: false,
    category: 'Part-Time Job / Task Trap',
    urgencyLevel: 'High',
    time: '02:15 PM',
    threatScore: 92,
    isScam: true,
    messages: [
      {
        id: 'msg-1',
        sender: 'contact',
        senderName: 'Priya Sharma (HR)',
        time: '02:15 PM',
        isForwarded: false,
        text: `Hello! 🌟 Greetings from Apex Media Marketing!

We noticed your resume and want to offer you a flexible Work-From-Home opportunity. You can easily earn ₹3,500 to ₹8,000 daily from your phone!

📌 *Job Description:*
- Just like 3 YouTube videos and take screenshots
- We pay ₹150 for every liked video instantly via UPI
- No prior experience required! Students & housewives welcome.`
      },
      {
        id: 'msg-2',
        sender: 'contact',
        senderName: 'Priya Sharma (HR)',
        time: '02:16 PM',
        isForwarded: false,
        image: DEMO_IMAGES.partTimeJobPaymentProof,
        imageCaption: 'UPI_PAYOUT_PROOF_₹150.PNG',
        text: `See payment proof above! We already transferred ₹150 trial bonus to another candidate. To claim your trial bonus of ₹300, contact our Receptionist on Telegram now:
👉 https://t.me/apex_task_rewards_bonus

Limited slots available today. Reply 1 to get started!`
      }
    ],
    redFlags: [
      'Task scams initially pay small amounts (₹150-₹300) to build trust, then demand "VIP investment" of ₹50,000 to ₹5,00,000.',
      'International sender (+84 Vietnam) claiming to be an Indian HR recruiter.',
      'Legitimate companies never recruit employees via unsolicited WhatsApp messages directing to Telegram.'
    ],
    safeAlternative: 'Never send money to "unlock" earnings. Block the sender.'
  },
  {
    id: 'hi-mum-dad',
    title: 'Emergency "Hi Mom New Phone" Trap',
    senderName: 'Unknown Contact',
    senderPhone: '+91 76543 21098',
    profileBadge: 'No Photo',
    isForwarded: false,
    category: 'Family Impersonation',
    urgencyLevel: 'Critical',
    time: '11:04 PM',
    threatScore: 90,
    isScam: true,
    messages: [
      {
        id: 'msg-1',
        sender: 'contact',
        senderName: 'Unknown Contact',
        time: '11:04 PM',
        isForwarded: false,
        text: `Hi Mummy, my phone fell into water and broke completely so this is my temporary WhatsApp on my roommate Rahul's number. 

I'm in hospital clinic right now because I sprained my ankle during college match and need to pay ₹18,500 emergency scan fee right now. My Google Pay is blocked on this new phone.`
      },
      {
        id: 'msg-2',
        sender: 'contact',
        senderName: 'Unknown Contact',
        time: '11:05 PM',
        isForwarded: false,
        text: `Can you please urgently transfer ₹18,500 to the clinic doctor's UPI ID:
UPI: clinic.care982@okaxis

Please mummy do it fast, the doctor is waiting. I will call you from hostel landline as soon as plaster is done!`
      }
    ],
    redFlags: [
      'Exploits parental panic and love late at night to bypass critical thinking.',
      'Claims old phone is broken to prevent parent from calling the real child.',
      'Demands immediate UPI transfer to a random virtual payment address.'
    ],
    safeAlternative: 'ALWAYS call your child on their regular phone number or call their college hostel before transferring money.'
  },
  {
    id: 'kbc-lottery',
    title: 'KBC ₹25 Lakh WhatsApp Lucky Draw',
    senderName: 'Rana Pratap Singh (KBC Head Manager)',
    senderPhone: '+91 99887 76655',
    profileBadge: 'KBC Official Logo',
    isForwarded: true,
    category: 'Lottery / Advance Fee',
    urgencyLevel: 'Critical',
    time: '09:20 AM',
    threatScore: 95,
    isScam: true,
    messages: [
      {
        id: 'msg-1',
        sender: 'contact',
        senderName: 'Rana Pratap Singh',
        time: '09:20 AM',
        isForwarded: true,
        image: DEMO_IMAGES.kbcLotteryCheque,
        imageCaption: 'KBC_LUCKY_DRAW_CHEQUE_₹25LAKH.JPG',
        text: `🎉 *CONGRATULATIONS ALL INDIA SIM CARD LUCKY DRAW 2026* 🎉

Respected Customer, your WhatsApp mobile number has won *₹25,00,000 (Twenty Five Lakh Rupees)* in joint collaboration with Kaun Banega Crorepati (KBC) & Jio Telecom!

Your Lottery Number: *KBC-9842*
Manager: *Rana Pratap Singh*

To deposit your cash prize directly into your State Bank or HDFC account:
1. Do not make normal voice call (Manager is busy).
2. Make WhatsApp Voice Call only to: +91 99887 76655
3. Pay government GST tax verification fee of ₹12,500 to release SBI demand draft.

Note: Prize expires in 24 hours if registration tax is unpaid. - KBC Head Office, Mumbai`
      }
    ],
    redFlags: [
      'You cannot win a lottery in a contest you never purchased a ticket for.',
      'Legitimate lotteries NEVER ask winners to pay "GST / release fees" in advance.',
      'Insists on "WhatsApp Voice Call only" to evade telecom lawful interception.'
    ],
    safeAlternative: 'Sony TV & Amitabh Bachchan have repeatedly warned citizens that this is a 100% fraudulent advance-fee scam.'
  },
  {
    id: 'electricity-bill',
    title: 'Electricity Midnight Cutoff & APK Trap',
    senderName: 'Electricity Dept Officer',
    senderPhone: '+91 88990 01122',
    profileBadge: 'State Power Emblem',
    isForwarded: true,
    category: 'Utility Impersonation',
    urgencyLevel: 'High',
    time: '06:45 PM',
    threatScore: 89,
    isScam: true,
    messages: [
      {
        id: 'msg-1',
        sender: 'contact',
        senderName: 'Electricity Dept Officer',
        time: '06:45 PM',
        isForwarded: true,
        image: DEMO_IMAGES.electricityDisconnectionNotice,
        imageCaption: 'POWER_DISCONNECTION_NOTICE_TONIGHT.JPG',
        text: `Dear Consumer,
Your electricity power will be disconnected tonight at 09:30 PM from the electricity sub-station office because your previous month bill was not updated in government server.

Kindly contact our electricity officer Mr. Verma immediately at 8899001122 or download our official Mahavitaran/Bijli bill update app:
👉 https://bijli-bill-seva.top/pay.apk

Do not ignore this notice to avoid midnight blackout. - Electricity Department.`
      }
    ],
    redFlags: [
      'Electricity boards NEVER send disconnection notices from individual personal mobile numbers.',
      'Power utilities NEVER ask consumers to install `.apk` files or call private mobile numbers.',
      'Fabricated tight deadline ("tonight at 9:30 PM") designed to create panic.'
    ],
    safeAlternative: 'Only pay electricity bills via the official state board app (BESCOM, TNEB, Mahavitaran, etc.).'
  },
  {
    id: 'safe-swiggy-otp',
    title: 'Genuine Food Delivery OTP & Arrival',
    senderName: 'Swiggy Delivery Bot',
    senderPhone: 'VK-SWIGGY / +91 80 6746 6746',
    profileBadge: 'Verified Green Badge',
    isForwarded: false,
    category: 'Legitimate Transaction',
    urgencyLevel: 'None',
    time: '01:30 PM',
    threatScore: 5,
    isScam: false,
    messages: [
      {
        id: 'msg-1',
        sender: 'contact',
        senderName: 'Swiggy Delivery Bot',
        time: '01:30 PM',
        isForwarded: false,
        image: DEMO_IMAGES.swiggyReceipt,
        imageCaption: 'SWIGGY_RECEIPT_ORDER_8942.PNG',
        text: `Hi Rahul! 🍔 Your Swiggy delivery partner, Ramesh Kumar, has arrived at your location with order #SWIG-8942 from Punjab Grill.

Please share your delivery OTP: *4821* with Ramesh when he hands over your food parcel. 

Enjoy your meal! Track on live map: https://www.swiggy.com/orders/8942`
      }
    ],
    redFlags: [],
    safeAlternative: 'This is a genuine delivery confirmation. Only share the OTP once you inspect and receive your food.'
  }
];
