export const SCAM_CALLER_DATABASE = [
  {
    number: "+91 98765 43210",
    normalized: "9876543210",
    callerName: "Electricity Officer Mr. Sharma (SPOOFED)",
    carrier: "Virtual / Leased PRI Gateway",
    circle: "Mumbai / Maharashtra",
    reportCount: 384,
    threatScore: 98,
    threatLevel: "Critical Scam",
    category: "Electricity Disconnection Threat",
    status: "Active Threat - High Volume",
    lastReported: "10 minutes ago",
    reportedOn: ["Chakshu (Sanchar Saathi)", "Cybercrime 1930 Portal", "Truecaller Community"],
    tags: ["Power Cutoff Scam", "Extortion", "Payment Gateway Harvesting"],
    scriptSummary: "Caller claims electricity will be severed at 9:30 PM due to unpaid balance; urges installing QuickSupport/AnyDesk or paying immediately on phishing link.",
    incomingSimulation: {
      callerDisplay: "⚡ Electricity Dept Officer",
      subText: "Suspected Fraud • 384 Reports",
      ringtoneNote: "Urgent alarm tone",
      audioTranscript: [
        { speaker: "Scammer", time: "00:01", text: "Hello! This is Officer Sharma from Central Electricity Discom head office. Are you listening?" },
        { speaker: "Scammer", time: "00:05", text: "Your previous month bill update failed in our server. Your power line is scheduled for automatic disconnect at 9:30 PM tonight!" },
        { speaker: "Scammer", time: "00:11", text: "If you don't want darkness tonight, immediately open the SMS I sent and pay ₹10 verification fee, or install our remote support app right now!" }
      ]
    }
  },
  {
    number: "+92 300 1234567",
    normalized: "923001234567",
    callerName: "CBI Cyber Branch / Officer R.K. Yadav (SPOOFED)",
    carrier: "Jazz Telecom (Pakistan / Foreign VOIP)",
    circle: "International Origin (+92 Pakistan)",
    reportCount: 1420,
    threatScore: 99,
    threatLevel: "Critical Threat",
    category: "Digital Arrest / Police Impersonation",
    status: "High Priority Cybercrime Syndicate",
    lastReported: "3 minutes ago",
    reportedOn: ["Ministry of Home Affairs I4C", "Chakshu Portal", "National 1930 Helpline"],
    tags: ["Digital Arrest", "CBI Impersonation", "Narcotics Blackmail", "Extortion"],
    scriptSummary: "Caller wears fake police uniform on Skype/WhatsApp, claims victim's Aadhaar is linked to money laundering and narcotics; threatens arrest unless money is wired to 'government verification escrow'.",
    incomingSimulation: {
      callerDisplay: "🚨 CBI Cyber Crime Division",
      subText: "WARNING: International Foreign VOIP (+92)",
      ringtoneNote: "Siren sound / Red Alert",
      audioTranscript: [
        { speaker: "Scammer", time: "00:01", text: "I am Inspector R.K. Yadav from CBI Headquarters New Delhi. Turn on your video camera immediately!" },
        { speaker: "Scammer", time: "00:07", text: "Your Aadhaar card was found at a narcotics crime scene in Mumbai Airport. You are under official Digital Arrest!" },
        { speaker: "Scammer", time: "00:13", text: "Do NOT cut this call, do not speak to your family! You must transfer your savings to the RBI verification account immediately!" }
      ]
    }
  },
  {
    number: "+91 87654 32109",
    normalized: "8765432109",
    callerName: "SBI YONO Verification Desk (SPOOFED)",
    carrier: "Airtel Virtual PBX",
    circle: "Noida / Delhi NCR",
    reportCount: 512,
    threatScore: 95,
    threatLevel: "Critical Scam",
    category: "Banking KYC Suspension",
    status: "Active Automated IVR Phishing",
    lastReported: "25 minutes ago",
    reportedOn: ["SBI Security Team", "Chakshu", "Cybercrime 1930"],
    tags: ["YONO Phishing", "Bank Impersonation", "OTP Theft"],
    scriptSummary: "Robocall notifying account suspension within 2 hours, pressing user to press 1 to connect with fake KYC executive who demands net banking password and OTP.",
    incomingSimulation: {
      callerDisplay: "🏦 State Bank of India YONO Desk",
      subText: "Reported Banking Phishing • High Risk",
      ringtoneNote: "Standard Bell + Alarm Overlay",
      audioTranscript: [
        { speaker: "IVR Robot", time: "00:01", text: "Attention SBI Customer. Your YONO internet banking has been suspended due to expired PAN KYC." },
        { speaker: "Scammer", time: "00:06", text: "Sir, I am connecting you to customer desk. Please share the 6-digit OTP sent to your registered mobile to avoid ₹5,000 penalty." }
      ]
    }
  },
  {
    number: "+91 93110 54321",
    normalized: "9311054321",
    callerName: "Delhi Cyber Police Station Notice (SPOOFED)",
    carrier: "Reliance Jio Leased PRI",
    circle: "New Delhi / NCR",
    reportCount: 890,
    threatScore: 97,
    threatLevel: "Critical Scam",
    category: "Digital Arrest / Police Extortion",
    status: "Active Impersonation Ring",
    lastReported: "8 minutes ago",
    reportedOn: ["Delhi Police IFSO", "Chakshu", "1930 Helpline"],
    tags: ["Police Impersonator", "Illegal SIM", "Video Interrogation"],
    scriptSummary: "Threatens victim that 14 illegal SIM cards were issued under their Aadhaar in Delhi; orders victim to remain in room on video call.",
    incomingSimulation: {
      callerDisplay: "🚔 Delhi Police Cyber Wing",
      subText: "890 Reports • Confirmed Extortion Ring",
      ringtoneNote: "Urgent Siren",
      audioTranscript: [
        { speaker: "Scammer", time: "00:01", text: "This is Sub-Inspector Verma from Delhi Cyber Police. Your Aadhaar was used in illegal terrorist communication." },
        { speaker: "Scammer", time: "00:06", text: "Do not disconnect! If you disconnect, police patrol van will reach your house in 15 minutes." }
      ]
    }
  },
  {
    number: "+1 415 890 1234",
    normalized: "14158901234",
    callerName: "Telegram Global HR Task Recruiter",
    carrier: "Twilio VOIP (USA Virtual)",
    circle: "North America Virtual Gateway",
    reportCount: 275,
    threatScore: 91,
    threatLevel: "High Risk Scam",
    category: "Part-Time Task & Investment Fraud",
    status: "Active Telegram Funnel",
    lastReported: "1 hour ago",
    reportedOn: ["Chakshu", "Truecaller Spam Database"],
    tags: ["Telegram Task", "Job Scam", "UPI Recharge Trap"],
    scriptSummary: "Offers ₹3,000/day for reviewing hotels and liking YouTube videos; lures into cryptocurrency deposit trap.",
    incomingSimulation: {
      callerDisplay: "💼 Global HR Recruitment",
      subText: "Suspected Task Scam • Twilio VOIP",
      ringtoneNote: "Chime tone",
      audioTranscript: [
        { speaker: "Scammer", time: "00:01", text: "Hi! Are you interested in earning ₹5,000 daily working from home for 20 minutes?" },
        { speaker: "Scammer", time: "00:06", text: "We have an urgent opening from Google ratings. Just click our Telegram link and receive ₹500 joining bonus!" }
      ]
    }
  },
  {
    number: "+91 91234 56789",
    normalized: "9123456789",
    callerName: "India Post Delivery Hub (SPOOFED)",
    carrier: "Vodafone Idea Prepaid",
    circle: "Kolkata / West Bengal",
    reportCount: 189,
    threatScore: 89,
    threatLevel: "High Risk Scam",
    category: "Courier / Smishing Verification",
    status: "Active Smishing Dispatcher",
    lastReported: "42 minutes ago",
    reportedOn: ["Chakshu", "India Post Grievances"],
    tags: ["India Post Spoof", "Address Update", "Card Phishing"],
    scriptSummary: "Automated voice claiming package returned; instructs victim to verify address on fake India Post domain.",
    incomingSimulation: {
      callerDisplay: "📦 India Post Speed Post Desk",
      subText: "Spoofed Courier Dispatcher",
      ringtoneNote: "Standard Bell",
      audioTranscript: [
        { speaker: "Scammer", time: "00:01", text: "Speed Post delivery failed for parcel ending in 41IN. House number missing." },
        { speaker: "Scammer", time: "00:05", text: "Please pay ₹25 token fee on the SMS link sent to your phone within 2 hours or parcel will be incinerated." }
      ]
    }
  }
];

// Helper to check any incoming number with heuristics
export function evaluatePhoneNumber(rawNumber) {
  if (!rawNumber) return null;
  
  const cleaned = rawNumber.replace(/[\s\-\(\)\.]/g, '');
  const digitsOnly = cleaned.replace(/^\+/, '');
  
  // 1. Direct match in scam database
  const match = SCAM_CALLER_DATABASE.find(item => {
    return cleaned.includes(item.normalized) || item.normalized.includes(digitsOnly);
  });
  
  if (match) {
    return {
      isScam: true,
      riskScore: match.threatScore,
      threatLevel: match.threatLevel,
      category: match.category,
      callerName: match.callerName,
      reportCount: match.reportCount,
      carrier: match.carrier,
      circle: match.circle,
      reasons: [
        `Direct match in National Cybercrime / Chakshu blacklist (${match.reportCount} confirmed complaints)`,
        `Associated with known '${match.category}' syndicates`,
        match.scriptSummary
      ],
      details: match
    };
  }
  
  // 2. Heuristic checks
  const reasons = [];
  let riskScore = 15;
  let threatLevel = "Low Risk / Unflagged";
  let category = "Unknown Caller";
  let callerName = "Unidentified Caller";
  let reportCount = 0;
  
  // Check for notorious foreign country codes used in Indian cyber extortion
  if (cleaned.startsWith("+92") || digitsOnly.startsWith("92")) {
    riskScore = 98;
    threatLevel = "Critical Threat";
    category = "International Impersonation / Digital Arrest Risk";
    callerName = "High-Risk International Caller (+92)";
    reportCount = 1240;
    reasons.push("Originates from Pakistan (+92 country code). Indian government agencies and banks NEVER use Pakistani telecom networks.");
    reasons.push("Frequently exploited in WhatsApp lottery (KBC) and fake CBI/police digital arrest threats.");
  } else if (cleaned.startsWith("+234") || digitsOnly.startsWith("234")) {
    riskScore = 94;
    threatLevel = "High Risk";
    category = "International Advance-Fee / Customs Scam";
    callerName = "West African Gateway Caller (+234)";
    reportCount = 480;
    reasons.push("Originates from Nigeria (+234 country code). Known for customs lottery, parcel gift, and crypto recovery scams.");
  } else if (cleaned.startsWith("+1") || digitsOnly.startsWith("1")) {
    riskScore = 78;
    threatLevel = "Suspicious VOIP";
    category = "Virtual VOIP / Telegram Recruiter";
    callerName = "US/Canada Virtual Line (+1)";
    reportCount = 210;
    reasons.push("US/Canada number often provisioned via free VOIP apps (TextNow, Twilio, Google Voice) by overseas scammers posing as recruiters.");
  } else if (cleaned.startsWith("+44") || digitsOnly.startsWith("44")) {
    riskScore = 80;
    threatLevel = "Suspicious VOIP";
    category = "UK Virtual Number / Forex Fraud";
    callerName = "UK Virtual Gateway (+44)";
    reportCount = 310;
    reasons.push("UK country code (+44) commonly leased by offshore call centers for fake forex trading, task platforms, or investment scams.");
  } else if (digitsOnly.length === 10 && /^[6-9]\d{9}$/.test(digitsOnly)) {
    // Normal Indian 10-digit mobile
    riskScore = 35;
    threatLevel = "Unverified Mobile";
    category = "Indian Mobile Subscriber";
    callerName = "Indian Cellular Subscriber";
    reasons.push("Standard Indian 10-digit mobile series. Not presently flagged in known blacklist, but exercise vigilance if caller demands OTP, passwords, or immediate payments.");
  } else if (cleaned.length < 8 && !cleaned.includes('+')) {
    // Shortcode or alphanumeric
    riskScore = 55;
    threatLevel = "Header / Shortcode";
    category = "Commercial / Bulk Gateway";
    callerName = "Commercial SMS / IVR Header";
    reasons.push("Sender uses commercial bulk SMS / IVR routing header. Check if header conforms to TRAI DLT registration standard.");
  }
  
  return {
    isScam: riskScore >= 70,
    riskScore,
    threatLevel,
    category,
    callerName,
    reportCount,
    carrier: cleaned.startsWith("+91") ? "Indian Telecom Operator" : "Dynamic Route / VOIP Gateway",
    circle: cleaned.startsWith("+91") ? "India" : "International / Gateway",
    reasons,
    details: null
  };
}
