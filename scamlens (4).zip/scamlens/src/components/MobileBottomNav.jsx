import React from 'react';
import { ShieldAlert, PhoneCall, Globe, QrCode, Camera, AlertTriangle, BookOpen, MessageSquare } from 'lucide-react';

export default function MobileBottomNav({ activeTab, setActiveTab, triggerCount = 0 }) {
  const navItems = [
    {
      id: 'scanner',
      label: 'Scan',
      icon: ShieldAlert,
      badge: triggerCount > 0 ? triggerCount : null,
      color: 'text-rose-500'
    },
    {
      id: 'whatsapp',
      label: 'WhatsApp',
      icon: MessageSquare,
      color: 'text-emerald-400',
      badge: 'NEW'
    },
    {
      id: 'qr-shield',
      label: 'QR Shield',
      icon: QrCode,
      color: 'text-rose-400'
    },
    {
      id: 'call-guardian',
      label: 'Call Shield',
      icon: PhoneCall,
      isPulse: true,
      color: 'text-red-500'
    },
    {
      id: 'emergency',
      label: 'SOS 1930',
      icon: AlertTriangle,
      color: 'text-rose-400',
      isEmergency: true
    }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-xl border-t border-slate-800/80 pb-[env(safe-area-inset-bottom,0px)] shadow-2xl">
      <div className="max-w-md mx-auto flex items-center justify-around px-1 py-1.5">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => {
                if (navigator.vibrate) {
                  try { navigator.vibrate(10); } catch {}
                }
                setActiveTab(item.id);
              }}
              className={`flex flex-col items-center justify-center py-1.5 px-1.5 rounded-xl transition-all duration-200 relative min-w-[54px] ${
                isActive
                  ? 'text-white'
                  : 'text-slate-400 hover:text-slate-200'
              } ${item.isEmergency ? 'text-rose-400 font-bold' : ''}`}
            >
              {/* Active Indicator Glow */}
              {isActive && (
                <span className="absolute -top-1.5 w-7 h-1 bg-gradient-to-r from-rose-500 to-red-500 rounded-full shadow-sm shadow-rose-500/50"></span>
              )}

              <div className="relative">
                <Icon className={`w-5 h-5 transition-transform duration-200 ${
                  isActive ? 'scale-110 ' + item.color : 'text-slate-400'
                }`} />

                {/* Pulse dot for Call Guardian */}
                {item.isPulse && !isActive && (
                  <span className="absolute -top-1 -right-1 flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                  </span>
                )}

                {/* Numeric badge */}
                {item.badge && (
                  <span className="absolute -top-1.5 -right-2 bg-rose-600 text-white font-black text-[9px] px-1 rounded-full border border-slate-900 leading-tight">
                    {item.badge}
                  </span>
                )}
              </div>

              <span className={`text-[9px] tracking-tight mt-1 transition-colors ${
                isActive ? 'font-bold text-white' : 'font-medium'
              }`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
