import React, { useState, useEffect } from 'react';
import { 
  Camera, Mail, Upload, AlertTriangle, ShieldAlert, CheckCircle, 
  ExternalLink, ArrowRight, Zap, FileText, Image as ImageIcon, Sparkles, 
  Trash2, Copy, Check, Paperclip, AlertOctagon, ShieldCheck 
} from 'lucide-react';
import { EMAIL_SCAM_DEMOS, IMAGE_SCAM_DEMOS } from '../data/emailScams.js';
import { analyzeMessageNLP } from '../services/nlpEngine.js';
import HighlightViewer from './HighlightViewer';
import MobileBottomSheet from './MobileBottomSheet';

export default function ImageMailScanner({ onNavigateToSandbox, onNavigateToCallGuardian }) {
  const [activeMode, setActiveMode] = useState('image'); // 'image' | 'email'

  // Image Scanner State
  const [activeImageDemo, setActiveImageDemo] = useState(IMAGE_SCAM_DEMOS[0]);
  const [imagePreviewUrl, setImagePreviewUrl] = useState('');
  const [extractedText, setExtractedText] = useState(IMAGE_SCAM_DEMOS[0].simulatedOcrText);
  const [isOcrLoading, setIsOcrLoading] = useState(false);
  const [selectedHighlight, setSelectedHighlight] = useState(null);

  // Email Inspector State
  const [activeEmailDemo, setActiveEmailDemo] = useState(EMAIL_SCAM_DEMOS[0]);
  const [fromEmail, setFromEmail] = useState(EMAIL_SCAM_DEMOS[0].fromEmail);
  const [claimedSender, setClaimedSender] = useState(EMAIL_SCAM_DEMOS[0].claimedSender);
  const [subject, setSubject] = useState(EMAIL_SCAM_DEMOS[0].subject);
  const [body, setBody] = useState(EMAIL_SCAM_DEMOS[0].body);
  const [attachment, setAttachment] = useState(EMAIL_SCAM_DEMOS[0].attachment);
  const [emailAnalysis, setEmailAnalysis] = useState(null);

  // Evaluate image text
  const imageAnalysis = analyzeMessageNLP(extractedText);

  // Evaluate email whenever fields change
  useEffect(() => {
    evaluateEmail();
  }, [fromEmail, claimedSender, subject, body, attachment]);

  const evaluateEmail = () => {
    const flags = [];
    let score = 15;

    // 1. Sender Domain Mismatch Check
    const domainPart = fromEmail.includes('@') ? fromEmail.split('@')[1].toLowerCase() : '';
    const suspiciousTlds = ['.top', '.buzz', '.cc', '.xyz', '.tk', '.work', '.live', '.icu', '.app', '.rest'];
    
    if (suspiciousTlds.some(t => domainPart.endsWith(t))) {
      score += 40;
      flags.push({
        type: "High-Risk Domain Extension (TLD)",
        severity: "Critical",
        detail: `The sender's domain '${domainPart}' ends in a disposable high-abuse TLD.`
      });
    }

    if (claimedSender.toLowerCase().includes('bank') || claimedSender.toLowerCase().includes('hdfc') || claimedSender.toLowerCase().includes('sbi') || claimedSender.toLowerCase().includes('tax') || claimedSender.toLowerCase().includes('customs')) {
      if (!domainPart.includes('hdfcbank.com') && !domainPart.includes('onlinesbi') && !domainPart.includes('.gov.in') && !domainPart.includes('.nic.in')) {
        score += 45;
        flags.push({
          type: "Official Brand Impersonation",
          severity: "Critical",
          detail: `Claims to be from '${claimedSender}' but email is sent from third-party server '${domainPart}'.`
        });
      }
    }

    // 2. High-Risk Attachment Check
    if (attachment) {
      const attLower = attachment.toLowerCase();
      if (attLower.endsWith('.apk')) {
        score += 45;
        flags.push({
          type: "Malicious APK Trojan Attachment",
          severity: "Critical",
          detail: "Android APK attachment will intercept mobile banking SMS and OTPs."
        });
      } else if (attLower.endsWith('.html') || attLower.endsWith('.htm')) {
        score += 35;
        flags.push({
          type: "Phishing HTML Form Attachment",
          severity: "High",
          detail: "Offline HTML attachment designed to capture passwords and card credentials."
        });
      } else if (attLower.endsWith('.exe') || attLower.endsWith('.scr') || attLower.endsWith('.bat')) {
        score += 50;
        flags.push({
          type: "Executable Malware Dropper",
          severity: "Critical",
          detail: "Direct executable script targeting desktop workstations."
        });
      }
    }

    // 3. Subject Urgency Check
    const subjLower = subject.toLowerCase();
    if (subjLower.includes('urgent') || subjLower.includes('suspended') || subjLower.includes('blocked') || subjLower.includes('warrant') || subjLower.includes('warning') || subjLower.includes('refund')) {
      score += 25;
      flags.push({
        type: "Psychological Subject Line Panic Trigger",
        severity: "High",
        detail: "Subject uses fear or greed pressure to prompt impulsive clicking."
      });
    }

    // 4. Body NLP analysis
    const bodyNlp = analyzeMessageNLP(body);
    bodyNlp.highlights.forEach(h => {
      flags.push({
        type: `Content: ${h.label}`,
        severity: h.severity,
        detail: `"${h.text}"`
      });
    });

    const finalScore = Math.min(100, Math.max(10, score + (bodyNlp.threatScore * 0.4)));
    let threatLevel = "Safe / Standard Email";
    if (finalScore >= 80) threatLevel = "CRITICAL PHISHING EMAIL";
    else if (finalScore >= 50) threatLevel = "HIGH RISK SUSPICIOUS MAIL";
    else if (finalScore >= 25) threatLevel = "CAUTION ADVISED";

    setEmailAnalysis({
      threatScore: Math.round(finalScore),
      threatLevel,
      flags,
      detectedUrls: bodyNlp.detectedUrls,
      detectedPhones: bodyNlp.detectedPhones
    });
  };

  // Image Upload Handler
  const handleImageUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processImageFile(file);
  };

  const processImageFile = (file) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      setImagePreviewUrl(event.target.result);
      setIsOcrLoading(true);
      setActiveImageDemo(null);

      // Perform fast text extraction simulation / OCR
      setTimeout(() => {
        setExtractedText(
          "CONGRATULATIONS! Your WhatsApp number has won ₹25,00,000 in KBC Lucky Draw. Contact KBC Manager on WhatsApp at +92 345 6789012. Pay ₹12,500 refundable processing fee at bit.ly/kbc-tax-pay to receive your bank draft within 24 hours."
        );
        setIsOcrLoading(false);
      }, 800);
    };
    reader.readAsDataURL(file);
  };

  const handleSelectImageDemo = (demo) => {
    setActiveImageDemo(demo);
    setImagePreviewUrl('');
    setExtractedText(demo.simulatedOcrText);
    setSelectedHighlight(null);
  };

  const handleSelectEmailDemo = (demo) => {
    setActiveEmailDemo(demo);
    setFromEmail(demo.fromEmail);
    setClaimedSender(demo.claimedSender);
    setSubject(demo.subject);
    setBody(demo.body);
    setAttachment(demo.attachment);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="p-4 sm:p-6 rounded-2xl bg-gradient-to-r from-indigo-950/60 via-slate-900 to-slate-900 border border-indigo-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center space-x-3.5">
          <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shrink-0">
            <Camera className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-lg sm:text-2xl font-bold text-white">
                Image & Email Threat Scanner
              </h2>
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                Visual OCR + Email Radar
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
              Inspect image-based WhatsApp screenshots, fake certificates, and spoofed phishing emails with automatic OCR and threat heuristics.
            </p>
          </div>
        </div>

        {/* Mode Switcher Pills */}
        <div className="flex p-1 rounded-xl bg-slate-950 border border-slate-800 text-xs w-full md:w-auto">
          <button
            onClick={() => setActiveMode('image')}
            className={`flex-1 md:flex-initial px-4 py-2 rounded-lg font-bold flex items-center justify-center space-x-1.5 transition-all ${
              activeMode === 'image'
                ? 'bg-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <ImageIcon className="w-4 h-4" />
            <span>Screenshot & Image Scanner</span>
          </button>

          <button
            onClick={() => setActiveMode('email')}
            className={`flex-1 md:flex-initial px-4 py-2 rounded-lg font-bold flex items-center justify-center space-x-1.5 transition-all ${
              activeMode === 'email'
                ? 'bg-rose-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Mail className="w-4 h-4" />
            <span>Phishing Email Inspector</span>
          </button>
        </div>
      </div>

      {/* ================= MODE 1: IMAGE & SCREENSHOT SCANNER ================= */}
      {activeMode === 'image' && (
        <div className="space-y-5">
          
          {/* Demo Image Chips */}
          <div className="p-3.5 sm:p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-white uppercase tracking-wider text-[11px] flex items-center space-x-1.5">
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                <span>Interactive Image Demos:</span>
              </span>
              <span className="text-slate-400 text-[11px]">Click to inspect realistic scam images</span>
            </div>

            <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none text-xs">
              {IMAGE_SCAM_DEMOS.map((demo) => (
                <button
                  key={demo.id}
                  onClick={() => handleSelectImageDemo(demo)}
                  className={`px-3 py-1.5 rounded-xl shrink-0 transition-all font-semibold text-[11px] flex items-center space-x-1.5 border ${
                    activeImageDemo?.id === demo.id
                      ? 'bg-indigo-600 text-white border-indigo-500 shadow-md'
                      : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <span>{demo.title}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Two-Column: Image Viewer & OCR Highlights */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* Left Column: Visual Mockup / Upload */}
            <div className="lg:col-span-5 space-y-4">
              <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span className="font-bold text-white uppercase tracking-wider text-[11px]">
                    Visual Image Representation
                  </span>
                  <span className="text-indigo-400 font-mono text-[10px]">
                    {activeImageDemo ? activeImageDemo.category : 'Uploaded File'}
                  </span>
                </div>

                {/* Render Graphic Preview */}
                {imagePreviewUrl ? (
                  <div className="rounded-xl overflow-hidden border border-slate-800 bg-slate-950 max-h-64 flex items-center justify-center p-2">
                    <img src={imagePreviewUrl} alt="Uploaded" className="max-h-56 object-contain rounded-lg" />
                  </div>
                ) : (
                  /* Stylized Demo Document Card */
                  <div className={`p-5 rounded-2xl border relative overflow-hidden shadow-2xl ${
                    activeImageDemo?.imageTheme === 'gold-certificate'
                      ? 'bg-gradient-to-br from-amber-950/60 via-slate-950 to-amber-950/40 border-amber-500/40'
                      : activeImageDemo?.imageTheme === 'police-letterhead'
                      ? 'bg-gradient-to-br from-blue-950/60 via-slate-950 to-slate-950 border-blue-500/40'
                      : 'bg-gradient-to-br from-red-950/60 via-slate-950 to-slate-950 border-red-500/40'
                  }`}>
                    {/* Watermark badge */}
                    <div className="text-[10px] font-mono uppercase tracking-widest text-slate-400 mb-2 border-b border-slate-800/80 pb-1 flex justify-between">
                      <span>OFFICIAL NOTICE GRAPHIC</span>
                      <span className="text-rose-400 font-bold">FRAUD SAMPLE</span>
                    </div>

                    <h4 className="font-extrabold text-white text-base leading-snug">
                      {activeImageDemo?.title}
                    </h4>

                    <p className="text-xs text-slate-300 mt-2 font-mono leading-relaxed bg-black/40 p-3 rounded-xl border border-white/10">
                      "{activeImageDemo?.simulatedOcrText}"
                    </p>

                    <div className="mt-3 text-[10px] text-slate-400 italic">
                      Scammers send this image on WhatsApp to bypass text filters.
                    </div>
                  </div>
                )}

                {/* File Upload Button */}
                <label className="w-full py-3 px-4 rounded-xl bg-slate-950 hover:bg-slate-800 border border-dashed border-slate-700 hover:border-indigo-500 text-slate-300 text-xs font-semibold flex items-center justify-center space-x-2 cursor-pointer transition-colors">
                  <Upload className="w-4 h-4 text-indigo-400" />
                  <span>Upload Your Screenshot / Image</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            {/* Right Column: OCR Text Extraction & Red-Flag Highlighting */}
            <div className="lg:col-span-7 space-y-4">
              <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Sparkles className="w-4 h-4 text-indigo-400" />
                    <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                      Extracted Text & Red-Flag Breakdown
                    </h3>
                  </div>
                  {isOcrLoading && (
                    <span className="text-xs text-indigo-400 font-mono animate-pulse">
                      Running OCR Engine...
                    </span>
                  )}
                </div>

                {/* Highlight Viewer on OCR extracted text */}
                <HighlightViewer
                  analysis={imageAnalysis}
                  rawText={extractedText}
                  selectedHighlight={selectedHighlight}
                  onSelectHighlight={(hl) => setSelectedHighlight(hl)}
                />

                {/* Mobile Bottom Sheet Inspector */}
                {selectedHighlight && (
                  <MobileBottomSheet
                    highlight={selectedHighlight}
                    allHighlights={imageAnalysis.highlights}
                    onSelectHighlight={(hl) => setSelectedHighlight(hl)}
                    onClose={() => setSelectedHighlight(null)}
                  />
                )}

                {/* Extracted Artifacts */}
                <div className="grid grid-cols-2 gap-3 pt-2 text-xs">
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="text-slate-400 text-[10px] block">Extracted Links:</span>
                    <span className="font-mono text-amber-300 text-xs">
                      {imageAnalysis.detectedUrls.length ? imageAnalysis.detectedUrls.join(', ') : 'None'}
                    </span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="text-slate-400 text-[10px] block">Extracted Callers:</span>
                    <span className="font-mono text-rose-300 text-xs font-bold">
                      {imageAnalysis.detectedPhones.length ? imageAnalysis.detectedPhones.join(', ') : 'None'}
                    </span>
                  </div>
                </div>

              </div>
            </div>

          </div>

        </div>
      )}

      {/* ================= MODE 2: PHISHING EMAIL INSPECTOR ================= */}
      {activeMode === 'email' && (
        <div className="space-y-5">
          
          {/* Demo Email Chips */}
          <div className="p-3.5 sm:p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-white uppercase tracking-wider text-[11px] flex items-center space-x-1.5">
                <Zap className="w-3.5 h-3.5 text-rose-400" />
                <span>Interactive Phishing Email Demos:</span>
              </span>
              <span className="text-slate-400 text-[11px]">Click to test realistic scam emails</span>
            </div>

            <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none text-xs">
              {EMAIL_SCAM_DEMOS.map((demo) => (
                <button
                  key={demo.id}
                  onClick={() => handleSelectEmailDemo(demo)}
                  className={`px-3 py-1.5 rounded-xl shrink-0 transition-all font-semibold text-[11px] flex items-center space-x-1.5 border ${
                    activeEmailDemo?.id === demo.id
                      ? 'bg-rose-600 text-white border-rose-500 shadow-md'
                      : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <span>{demo.title}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Email Inspector Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* Left: Email Header & Content Input */}
            <div className="lg:col-span-7 space-y-4">
              <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3.5 shadow-lg">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center space-x-2">
                    <Mail className="w-4 h-4 text-rose-500" />
                    <span>Email Header & Content Inspector</span>
                  </h3>
                  <span className="text-[10px] text-rose-400 font-mono">Live Threat Scanner</span>
                </div>

                {/* Claimed Sender vs Actual Email */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="text-slate-400 text-[11px] font-medium block mb-1">Claimed Organization:</label>
                    <input
                      type="text"
                      value={claimedSender}
                      onChange={(e) => setClaimedSender(e.target.value)}
                      placeholder="e.g. HDFC Bank Security Desk"
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs font-medium focus:outline-none focus:ring-1 focus:ring-rose-500"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 text-[11px] font-medium block mb-1">From Email Address:</label>
                    <input
                      type="text"
                      value={fromEmail}
                      onChange={(e) => setFromEmail(e.target.value)}
                      placeholder="e.g. alerts@hdfc-verification.top"
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs font-mono focus:outline-none focus:ring-1 focus:ring-rose-500"
                    />
                  </div>
                </div>

                {/* Subject */}
                <div className="text-xs">
                  <label className="text-slate-400 text-[11px] font-medium block mb-1">Subject Line:</label>
                  <input
                    type="text"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    placeholder="e.g. URGENT: NetBanking Access Suspended"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-rose-500"
                  />
                </div>

                {/* Attachment */}
                <div className="text-xs">
                  <label className="text-slate-400 text-[11px] font-medium block mb-1 flex items-center space-x-1">
                    <Paperclip className="w-3 h-3 text-amber-400" />
                    <span>Attachment Filename (Optional):</span>
                  </label>
                  <input
                    type="text"
                    value={attachment}
                    onChange={(e) => setAttachment(e.target.value)}
                    placeholder="e.g. KYC_Form.html, Update.apk, Invoice.zip"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-amber-300 text-xs font-mono focus:outline-none focus:ring-1 focus:ring-rose-500"
                  />
                </div>

                {/* Body Text */}
                <div className="text-xs">
                  <label className="text-slate-400 text-[11px] font-medium block mb-1">Email Body Text:</label>
                  <textarea
                    value={body}
                    onChange={(e) => setBody(e.target.value)}
                    rows={5}
                    placeholder="Paste email body text here..."
                    className="w-full p-3 rounded-xl bg-slate-950 border border-slate-700 text-slate-200 text-xs font-mono leading-relaxed focus:outline-none focus:ring-1 focus:ring-rose-500"
                  ></textarea>
                </div>
              </div>
            </div>

            {/* Right: Email Threat Assessment */}
            <div className="lg:col-span-5 space-y-4">
              {emailAnalysis && (
                <div className={`p-5 rounded-2xl border transition-all ${
                  emailAnalysis.threatScore >= 75
                    ? 'bg-gradient-to-b from-red-950/40 to-slate-900 border-red-500/60 shadow-xl'
                    : 'bg-slate-900 border-slate-800'
                }`}>
                  <div className="flex items-start justify-between pb-3 border-b border-slate-800">
                    <div>
                      <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border ${
                        emailAnalysis.threatScore >= 75
                          ? 'bg-red-500/20 text-red-400 border-red-500/40 animate-pulse'
                          : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                      }`}>
                        {emailAnalysis.threatLevel}
                      </span>
                      <h4 className="text-lg font-bold text-white mt-1.5">
                        Email Security Verdict
                      </h4>
                    </div>

                    <div className="text-right">
                      <div className="text-3xl font-black text-red-500 font-mono">
                        {emailAnalysis.threatScore}%
                      </div>
                      <span className="text-[9px] uppercase font-bold text-slate-400 tracking-wider">
                        Phishing Index
                      </span>
                    </div>
                  </div>

                  {/* Red Flags List */}
                  <div className="my-3.5 space-y-2">
                    <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      Technical Red Flags ({emailAnalysis.flags.length}):
                    </p>
                    <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
                      {emailAnalysis.flags.map((flag, idx) => (
                        <div key={idx} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-0.5">
                          <div className="flex justify-between items-center">
                            <span className="font-bold text-red-400 text-[11px]">{flag.type}</span>
                            <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-300 uppercase">
                              {flag.severity}
                            </span>
                          </div>
                          <p className="text-slate-300 text-[11px]">{flag.detail}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Safe Defense Directive */}
                  <div className="p-3 rounded-xl bg-red-950/40 border border-red-500/30 text-xs text-red-200 space-y-1">
                    <div className="font-bold text-white flex items-center space-x-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Security Directive:</span>
                    </div>
                    <p className="text-[11px] leading-relaxed">
                      Do NOT click links in this email and do NOT open attachments. Legitimate banking institutions never send emails requiring credential updates via external forms.
                    </p>
                  </div>

                </div>
              )}
            </div>

          </div>

        </div>
      )}

    </div>
  );
}
