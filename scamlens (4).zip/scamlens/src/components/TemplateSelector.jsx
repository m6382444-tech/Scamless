import React, { useState } from 'react';
import { SCAM_TEMPLATES } from '../data/templates';
import { ShieldAlert, Zap, Package, Landmark, Scale, FileCode, Briefcase, Gift, CreditCard, ArrowRight } from 'lucide-react';

const CATEGORY_ICONS = {
  "Utility Fraud": Zap,
  "Courier / Smishing": Package,
  "Banking Phishing": Landmark,
  "Extortion / Impersonation": Scale,
  "Malware / APK Dropper": FileCode,
  "Task / Investment Fraud": Briefcase,
  "Lottery Advance Fee": Gift,
  "Card Credential Phishing": CreditCard
};

export default function TemplateSelector({ onSelectTemplate }) {
  const [activeFilter, setActiveFilter] = useState('All');

  const categories = ['All', 'Banking & KYC', 'Utility & Delivery', 'Police & Extortion', 'Jobs & Lottery'];

  const filteredTemplates = SCAM_TEMPLATES.filter(template => {
    if (activeFilter === 'All') return true;
    if (activeFilter === 'Banking & KYC') return template.category.includes('Banking') || template.category.includes('Card');
    if (activeFilter === 'Utility & Delivery') return template.category.includes('Utility') || template.category.includes('Courier');
    if (activeFilter === 'Police & Extortion') return template.category.includes('Extortion') || template.category.includes('Malware');
    if (activeFilter === 'Jobs & Lottery') return template.category.includes('Task') || template.category.includes('Lottery');
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-indigo-950/40 via-slate-900 to-slate-900 border border-indigo-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h2 className="text-xl sm:text-2xl font-bold text-white">
              Indian Scam Vault & Template Library
            </h2>
            <span className="text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Verified Real Cases
            </span>
          </div>
          <p className="text-sm text-slate-400 mt-1 max-w-2xl">
            Pre-loaded with notorious cyber scam templates circulating across Indian SMS, WhatsApp, and Telegram channels. Click any template to immediately inspect and deconstruct its manipulative triggers.
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap gap-1.5 text-xs">
          {categories.map((cat, i) => (
            <button
              key={i}
              onClick={() => setActiveFilter(cat)}
              className={`px-3 py-1.5 rounded-lg transition-colors font-medium ${
                activeFilter === cat
                  ? 'bg-indigo-600 text-white font-semibold shadow'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of Templates */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredTemplates.map((template) => {
          const IconComponent = CATEGORY_ICONS[template.category] || ShieldAlert;
          const isCritical = template.urgencyLevel === 'Critical';

          return (
            <div
              key={template.id}
              className="group p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-indigo-500/50 transition-all flex flex-col justify-between hover:shadow-xl hover:shadow-indigo-950/20"
            >
              <div>
                {/* Header */}
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400 group-hover:scale-110 transition-transform shrink-0">
                    <IconComponent className="w-5 h-5" />
                  </div>
                  <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border ${
                    isCritical
                      ? 'bg-red-500/20 text-red-400 border-red-500/30'
                      : 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                  }`}>
                    {template.urgencyLevel} Threat
                  </span>
                </div>

                <h3 className="text-base font-bold text-white group-hover:text-indigo-300 transition-colors">
                  {template.title}
                </h3>
                <span className="text-xs text-indigo-400/90 font-medium block mt-0.5">
                  {template.category} • {template.channel}
                </span>

                <p className="text-xs text-slate-400 mt-2.5 leading-relaxed line-clamp-2">
                  {template.summary}
                </p>

                {/* Snippet Quote */}
                <div className="my-3.5 p-3 rounded-xl bg-slate-950 border border-slate-800/80 font-mono text-xs text-slate-300 line-clamp-3">
                  "{template.message}"
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-1.5 my-2">
                  {template.tags.map((tag, idx) => (
                    <span key={idx} className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Load Button */}
              <div className="pt-3 border-t border-slate-800/80 mt-2">
                <button
                  onClick={() => onSelectTemplate(template)}
                  className="w-full py-2.5 px-4 rounded-xl bg-indigo-600/90 hover:bg-indigo-600 font-semibold text-xs text-white flex items-center justify-center space-x-1.5 shadow transition-all group-hover:shadow-indigo-900/40"
                >
                  <span>Load into Red-Flag Highlighter</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
