import React, { useState, useEffect, useRef } from 'react';
import { 
  MessageSquare, Share2, Copy, Check, ShieldAlert, ShieldCheck, AlertTriangle, 
  Upload, Camera, Sparkles, ExternalLink, RefreshCw, PhoneCall, Globe, CheckCircle2,
  AlertOctagon, UserX, Info, Send, Paperclip, Image as ImageIcon, Trash2, Plus,
  Maximize2, X, Eye, ArrowRight, CornerDownRight, CheckCheck
} from 'lucide-react';
import { WHATSAPP_SCAMS, DEMO_IMAGES } from '../data/whatsappScams';
import { analyzeMessageNLP } from '../services/nlpEngine';
import { extractTextFromImage } from '../services/ocrService';
import VoiceAlertBar from './VoiceAlertBar';

export default function WhatsAppVerifier({
  onNavigateToSandbox,
  onNavigateToCallGuardian,
  onNavigateToEmergency
}) {
  const [activeScamPresetId, setActiveScamPresetId] = useState('digital-arrest');
  const [senderName, setSenderName] = useState(WHATSAPP_SCAMS[0].senderName);
  const [senderPhone, setSenderPhone] = useState(WHATSAPP_SCAMS[0].senderPhone);
  
  // Conversation thread state (Array of message objects)
  const [messages, setMessages] = useState(() => WHATSAPP_SCAMS[0].messages || []);
  const [selectedMessageId, setSelectedMessageId] = useState(() => WHATSAPP_SCAMS[0].messages[0]?.id || null);

  // New message composition state
  const [inputText, setInputText] = useState('');
  const [inputSenderType, setInputSenderType] = useState('contact'); // 'contact' (incoming) or 'me' (outgoing)
  const [inputIsForwarded, setInputIsForwarded] = useState(false);
  const [pendingImage, setPendingImage] = useState(null); // { url, file, name }

  // OCR Loading state
  const [ocrLoading, setOcrLoading] = useState(false);
  const [ocrProgress, setOcrProgress] = useState(0);
  const [ocrError, setOcrError] = useState(null);

  // Full-screen image preview lightbox
  const [lightboxImage, setLightboxImage] = useState(null);

  // Drag and drop / paste state
  const [isDragOver, setIsDragOver] = useState(false);

  // Copy states
  const [copiedShareLink, setCopiedShareLink] = useState(false);
  const [copiedShareText, setCopiedShareText] = useState(false);

  // File input ref
  const fileInputRef = useRef(null);
  const chatBottomRef = useRef(null);

  // Active public URL for share-to-scan
  const publicBaseUrl = "https://earning-increasing-tmp-trek.trycloudflare.com";

  // Auto-scroll chat when messages change
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length]);

  // Combine all incoming messages text to compute overall conversation threat score
  const fullConversationText = messages
    .filter(m => m.sender === 'contact')
    .map(m => m.text)
    .join('\n\n');

  const overallAnalysis = analyzeMessageNLP(fullConversationText || 'Hello');

  // Currently focused message analysis
  const focusedMessage = messages.find(m => m.id === selectedMessageId) || messages[0] || null;
  const focusedAnalysis = focusedMessage 
    ? analyzeMessageNLP(focusedMessage.text)
    : overallAnalysis;

  const isScamVerdict = overallAnalysis.threatScore >= 40;

  // Handle Preset Selection
  const handleSelectPreset = (scam) => {
    setActiveScamPresetId(scam.id);
    setSenderName(scam.senderName);
    setSenderPhone(scam.senderPhone);
    setMessages(scam.messages);
    setSelectedMessageId(scam.messages[0]?.id || null);
    setInputText('');
    setPendingImage(null);
    setOcrError(null);
  };

  // Start Blank Custom Chat
  const handleStartBlankChat = () => {
    setActiveScamPresetId('custom');
    setSenderName('Suspicious Unknown Contact');
    setSenderPhone('+92 300 0000000');
    setMessages([]);
    setSelectedMessageId(null);
    setInputText('');
    setPendingImage(null);
    setOcrError(null);
  };

  // Process image file (from upload, drag-and-drop, or clipboard paste)
  const processImageFile = async (file) => {
    if (!file || !file.type.startsWith('image/')) {
      setOcrError("Please upload a valid image file (PNG, JPG, WEBP).");
      return;
    }

    setOcrLoading(true);
    setOcrProgress(15);
    setOcrError(null);

    const imageUrl = URL.createObjectURL(file);
    setPendingImage({
      url: imageUrl,
      name: file.name || 'Pasted_Screenshot.png',
      size: (file.size / 1024).toFixed(1) + ' KB'
    });

    try {
      const ocrResult = await extractTextFromImage(file, (progress) => {
        setOcrProgress(progress);
      });

      if (ocrResult?.success && ocrResult?.text) {
        setInputText(prev => prev ? `${prev}\n${ocrResult.text}` : ocrResult.text);
      } else {
        // If image has handwritten or stylized text that wasn't OCR-readable
        setInputText(prev => prev || "Extracted Image Content (Inspect red flags below)");
      }
    } catch (err) {
      console.warn("OCR extraction notice:", err);
      setOcrError("Note: Could not extract automated text from image, but you can still add it to the chat and inspect it.");
    } finally {
      setOcrLoading(false);
      setOcrProgress(0);
    }
  };

  // Handle file input change
  const handleFileInputChange = (e) => {
    const file = e.target.files?.[0];
    if (file) processImageFile(file);
  };

  // Handle clipboard paste (Ctrl+V) anywhere on the component
  const handlePaste = (e) => {
    const items = e.clipboardData?.items;
    if (!items) return;

    for (let i = 0; i < items.length; i++) {
      if (items[i].type.indexOf('image') !== -1) {
        const file = items[i].getAsFile();
        if (file) {
          processImageFile(file);
          e.preventDefault();
          break;
        }
      }
    }
  };

  // Handle drag and drop
  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) processImageFile(file);
  };

  // Send / Add message to conversation
  const handleSendMessage = () => {
    if (!inputText.trim() && !pendingImage) return;

    const messageText = inputText.trim() || (pendingImage ? `[Shared Image: ${pendingImage.name}]` : '');
    const newMsgId = `msg-${Date.now()}`;

    const newMsg = {
      id: newMsgId,
      sender: inputSenderType,
      senderName: inputSenderType === 'contact' ? senderName : 'You',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isForwarded: inputSenderType === 'contact' ? inputIsForwarded : false,
      text: messageText,
      image: pendingImage ? pendingImage.url : null,
      imageCaption: pendingImage ? pendingImage.name : null
    };

    setMessages(prev => [...prev, newMsg]);
    setSelectedMessageId(newMsgId);
    setInputText('');
    setPendingImage(null);
    setOcrError(null);
  };

  // Delete message
  const handleDeleteMessage = (id, e) => {
    e.stopPropagation();
    setMessages(prev => prev.filter(m => m.id !== id));
    if (selectedMessageId === id) {
      setSelectedMessageId(messages[0]?.id || null);
    }
  };

  // Country Code Risk Inspector
  const getCountryCodeBadge = (phone) => {
    if (!phone) return null;
    if (phone.includes('+92')) {
      return { label: 'High Risk: Pakistan Prefix (+92)', color: 'bg-red-950 text-red-400 border-red-500/50' };
    }
    if (phone.includes('+84')) {
      return { label: 'High Risk: Vietnam Prefix (+84)', color: 'bg-red-950 text-red-400 border-red-500/50' };
    }
    if (phone.includes('+62')) {
      return { label: 'High Risk: Indonesia Prefix (+62)', color: 'bg-amber-950 text-amber-400 border-amber-500/50' };
    }
    if (phone.includes('+234')) {
      return { label: 'High Risk: Nigeria Prefix (+234)', color: 'bg-red-950 text-red-400 border-red-500/50' };
    }
    if (phone.includes('+91')) {
      return { label: 'Domestic: India (+91)', color: 'bg-slate-800 text-slate-300 border-slate-700' };
    }
    return { label: 'International Number', color: 'bg-amber-950 text-amber-400 border-amber-500/50' };
  };

  const countryBadge = getCountryCodeBadge(senderPhone);

  // Generate WhatsApp Share URL & direct Share-to-Scan Link
  const shareToScanUrl = `${publicBaseUrl}/?scan=${encodeURIComponent(fullConversationText.slice(0, 300))}&tab=whatsapp`;

  const whatsappShareMessage = isScamVerdict
    ? `🚨 *SCAMLENS FRAUD ALERT!* 🚨\n\n⚠️ *Checked WhatsApp Conversation on ScamLens:*\nSender: ${senderName} (${senderPhone})\n"${fullConversationText.slice(0, 100)}..."\n\n🛑 *Verdict:* DANGEROUS SCAM (${overallAnalysis.threatScore}/100)\n🔊 *Voice Audio Verdict:* Verified threat trap. Do not pay or share OTP!\n\n🛡️ *Verify any suspicious message or number for free:*\n👉 ${shareToScanUrl}`
    : `✅ *SCAMLENS VERIFICATION PASSED* ✅\n\n💬 *Sender:* ${senderName}\n"${fullConversationText.slice(0, 100)}..."\n\n🟢 *Verdict:* SAFE (Threat Score: ${overallAnalysis.threatScore}/100)\n🔊 *Safe to proceed with contact.*\n\nScan any message free:\n👉 ${shareToScanUrl}`;

  const handleShareToWhatsApp = () => {
    const targetUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(whatsappShareMessage)}`;
    window.open(targetUrl, '_blank');
  };

  const handleCopyShareLink = () => {
    navigator.clipboard.writeText(shareToScanUrl);
    setCopiedShareLink(true);
    setTimeout(() => setCopiedShareLink(false), 2000);
  };

  const handleCopyShareText = () => {
    navigator.clipboard.writeText(whatsappShareMessage);
    setCopiedShareText(true);
    setTimeout(() => setCopiedShareText(false), 2000);
  };

  return (
    <div 
      className="space-y-6 max-w-6xl mx-auto pb-16"
      onPaste={handlePaste}
    >
      
      {/* Top Banner & Header */}
      <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-emerald-950/70 via-slate-900 to-emerald-950/40 border border-emerald-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
              <MessageSquare className="w-5 h-5" />
            </span>
            <h2 className="text-lg sm:text-xl font-extrabold text-white">
              WhatsApp Scam Studio & Interactive Verifier
            </h2>
            <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
              LIVE RADAR
            </span>
          </div>
          <p className="text-xs text-slate-300">
            Put your own WhatsApp chat messages and images, upload screenshots, or test real scam presets with live multilingual voice verdicts.
          </p>
        </div>

        {/* 1-Click WhatsApp Share to Scan Action */}
        <div className="flex items-center space-x-2 shrink-0 w-full sm:w-auto">
          <button
            onClick={handleShareToWhatsApp}
            className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-950/50 flex items-center justify-center space-x-2 transition-all transform active:scale-95"
            title="Open WhatsApp to share scam alert"
          >
            <Share2 className="w-4 h-4" />
            <span>Share Alert to WhatsApp</span>
          </button>
        </div>
      </div>

      {/* Multilingual Voice Alert Bar (Synced to live threat status) */}
      <VoiceAlertBar 
        isScam={isScamVerdict} 
        threatScore={overallAnalysis.threatScore}
        autoPlay={false}
      />

      {/* 1-Click Demo Presets + Custom New Chat Button */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>Interactive Demo Models or Create Your Own:</span>
          </span>
          <span className="text-[11px] text-slate-500 hidden sm:inline">
            Drag & drop images anywhere or press Ctrl+V to paste
          </span>
        </div>

        <div className="flex flex-wrap gap-2">
          {WHATSAPP_SCAMS.map((scam) => (
            <button
              key={scam.id}
              onClick={() => handleSelectPreset(scam)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all border flex items-center space-x-1.5 ${
                activeScamPresetId === scam.id
                  ? (scam.isScam 
                      ? 'bg-rose-600/30 text-rose-300 border-rose-500/60 shadow-md shadow-rose-950/40' 
                      : 'bg-emerald-600/30 text-emerald-300 border-emerald-500/60 shadow-md shadow-emerald-950/40')
                  : 'bg-slate-900/80 text-slate-400 hover:text-slate-200 border-slate-800'
              }`}
            >
              <span>{scam.isScam ? '🔴' : '🟢'}</span>
              <span>{scam.title}</span>
            </button>
          ))}

          {/* Blank Custom Chat Creator */}
          <button
            onClick={handleStartBlankChat}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border flex items-center space-x-1.5 ${
              activeScamPresetId === 'custom'
                ? 'bg-emerald-600 text-white border-emerald-500 shadow-md'
                : 'bg-slate-950 text-emerald-400 hover:bg-emerald-950/40 border-emerald-500/40'
            }`}
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ Blank Custom Chat</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Interactive WhatsApp Chat Simulator (7 cols) + Threat Inspector (5 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: Interactive WhatsApp Phone View (7 cols) */}
        <div 
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={`lg:col-span-7 bg-[#0b141a] rounded-2xl border transition-all shadow-2xl overflow-hidden flex flex-col ${
            isDragOver 
              ? 'border-emerald-400 ring-2 ring-emerald-400/50' 
              : 'border-slate-800'
          }`}
        >
          
          {/* WhatsApp Header: Contact Details & Inline Editable Profile */}
          <div className="bg-[#1f2c34] px-4 py-3 border-b border-slate-800 flex items-center justify-between text-white">
            
            <div className="flex items-center space-x-3 min-w-0 flex-1 mr-2">
              <div className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-sm text-emerald-400 shrink-0 shadow">
                {senderName.charAt(0) || '?'}
              </div>
              
              <div className="min-w-0 flex-1">
                <div className="flex items-center space-x-1.5">
                  <input
                    type="text"
                    value={senderName}
                    onChange={(e) => setSenderName(e.target.value)}
                    placeholder="Sender Name..."
                    className="font-bold text-sm text-slate-100 bg-transparent border-b border-transparent hover:border-slate-600 focus:border-emerald-500 focus:outline-none truncate w-full max-w-[200px]"
                    title="Click to edit contact name"
                  />
                  {countryBadge && (
                    <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold border shrink-0 ${countryBadge.color}`}>
                      {countryBadge.label}
                    </span>
                  )}
                </div>

                <div className="flex items-center space-x-2 text-[11px] text-slate-400 font-mono">
                  <input
                    type="text"
                    value={senderPhone}
                    onChange={(e) => setSenderPhone(e.target.value)}
                    placeholder="Phone number..."
                    className="bg-transparent text-slate-400 hover:text-slate-200 border-b border-transparent hover:border-slate-600 focus:border-emerald-500 focus:outline-none w-36 truncate"
                    title="Click to edit contact phone number"
                  />
                </div>
              </div>
            </div>

            {/* Quick Actions in WhatsApp Header */}
            <div className="flex items-center space-x-2 text-slate-300">
              <button
                onClick={() => setMessages([])}
                className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                title="Clear all messages in chat"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>

          </div>

          {/* WhatsApp Chat Canvas */}
          <div className="p-3 sm:p-4 bg-[#0b141a] min-h-[360px] max-h-[460px] overflow-y-auto space-y-3.5 relative scrollbar-thin scrollbar-thumb-slate-800">
            
            {/* Subtle background doodle texture */}
            <div className="absolute inset-0 opacity-5 pointer-events-none bg-[radial-gradient(#25d366_1px,transparent_1px)] [background-size:16px_16px]"></div>

            {/* Empty Chat State */}
            {messages.length === 0 && (
              <div className="flex flex-col items-center justify-center h-52 text-center p-6 space-y-2 text-slate-400">
                <MessageSquare className="w-8 h-8 text-slate-600" />
                <p className="text-xs font-semibold text-slate-300">No messages in this chat yet</p>
                <p className="text-[11px] text-slate-500 max-w-xs">
                  Type a suspicious message below, upload a screenshot or image, or drag and drop a file to start verifying.
                </p>
              </div>
            )}

            {/* Render Conversation Messages */}
            {messages.map((msg) => {
              const isContact = msg.sender === 'contact';
              const isSelected = selectedMessageId === msg.id;
              const msgAnalysis = isContact ? analyzeMessageNLP(msg.text) : null;
              const hasScamTrigger = msgAnalysis && msgAnalysis.threatScore >= 40;

              return (
                <div
                  key={msg.id}
                  onClick={() => setSelectedMessageId(msg.id)}
                  className={`flex flex-col group cursor-pointer transition-all ${
                    isContact ? 'items-start' : 'items-end'
                  }`}
                >
                  
                  {/* Message Bubble */}
                  <div className={`relative max-w-[90%] sm:max-w-[82%] rounded-2xl p-3 sm:p-3.5 shadow-md border transition-all ${
                    isContact
                      ? isSelected
                        ? 'bg-[#1f2c34] border-emerald-500 ring-2 ring-emerald-500/30 rounded-tl-sm text-slate-100'
                        : 'bg-[#1f2c34] border-slate-750 hover:border-slate-600 rounded-tl-sm text-slate-100'
                      : 'bg-[#005c4b] border-[#02735e] rounded-tr-sm text-white'
                  }`}>
                    
                    {/* Forwarded Header */}
                    {msg.isForwarded && (
                      <div className="flex items-center space-x-1 text-slate-400 text-[10px] italic border-b border-slate-700/50 pb-1 mb-1.5">
                        <Share2 className="w-3 h-3 text-slate-400 rotate-180" />
                        <span>Forwarded many times</span>
                      </div>
                    )}

                    {/* Sender Label for Incoming */}
                    {isContact && (
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="text-[11px] font-bold text-emerald-400 truncate">
                          {msg.senderName}
                        </span>
                        
                        {/* Threat Indicator Chip */}
                        {hasScamTrigger ? (
                          <span className="px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-400 border border-rose-500/40 text-[9px] font-black uppercase tracking-wider shrink-0 flex items-center space-x-1">
                            <AlertOctagon className="w-2.5 h-2.5" />
                            <span>Scam: {msgAnalysis.threatScore}</span>
                          </span>
                        ) : (
                          <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[9px] font-bold uppercase tracking-wider shrink-0">
                            Safe
                          </span>
                        )}
                      </div>
                    )}

                    {/* Image Attachment (if message contains an image) */}
                    {msg.image && (
                      <div className="mb-2 rounded-xl overflow-hidden border border-slate-700/80 bg-black/40 relative group/img">
                        <img 
                          src={msg.image} 
                          alt="WhatsApp Image" 
                          className="w-full max-h-48 object-cover rounded-lg"
                        />
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setLightboxImage(msg.image);
                          }}
                          className="absolute bottom-2 right-2 p-1.5 rounded-lg bg-black/70 hover:bg-black text-white text-xs flex items-center space-x-1 transition-all opacity-90 hover:opacity-100"
                          title="View High-Resolution Image"
                        >
                          <Maximize2 className="w-3 h-3" />
                          <span className="text-[10px]">Zoom</span>
                        </button>
                      </div>
                    )}

                    {/* Message Text Content */}
                    <p className="text-xs sm:text-[13px] leading-relaxed whitespace-pre-wrap break-words font-sans">
                      {msg.text}
                    </p>

                    {/* Footer: Time & Status */}
                    <div className="flex items-center justify-end space-x-1.5 text-[10px] text-slate-400 pt-1 mt-0.5">
                      <span>{msg.time || '10:45 AM'}</span>
                      {isContact ? (
                        <span className="text-cyan-400 font-bold">✓✓</span>
                      ) : (
                        <CheckCheck className="w-3.5 h-3.5 text-cyan-300" />
                      )}
                      
                      {/* Delete Button */}
                      <button
                        onClick={(e) => handleDeleteMessage(msg.id, e)}
                        className="opacity-0 group-hover:opacity-100 p-0.5 rounded text-slate-500 hover:text-rose-400 transition-opacity ml-1"
                        title="Delete this message"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>

                  </div>

                </div>
              );
            })}

            <div ref={chatBottomRef} />
          </div>

          {/* Pending Image Upload Preview Bar (if user selected an image to attach) */}
          {pendingImage && (
            <div className="p-2.5 bg-[#182229] border-t border-slate-800 flex items-center justify-between gap-3 text-xs">
              <div className="flex items-center space-x-2.5 min-w-0">
                <div className="w-10 h-10 rounded-lg overflow-hidden border border-slate-700 shrink-0 bg-black">
                  <img src={pendingImage.url} alt="Pending Preview" className="w-full h-full object-cover" />
                </div>
                <div className="min-w-0 text-[11px]">
                  <span className="text-emerald-400 font-semibold truncate block">{pendingImage.name}</span>
                  <span className="text-slate-400 text-[10px]">{pendingImage.size} • Ready to send</span>
                </div>
              </div>

              <div className="flex items-center space-x-2 shrink-0">
                {ocrLoading && (
                  <div className="flex items-center space-x-1.5 text-[10px] text-amber-300 font-semibold">
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>OCR ({ocrProgress}%)...</span>
                  </div>
                )}
                <button
                  onClick={() => setPendingImage(null)}
                  className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-700"
                  title="Remove image"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {ocrError && (
            <div className="px-3 py-1.5 bg-amber-950/60 border-t border-amber-500/30 text-[11px] text-amber-300 flex items-center space-x-1.5">
              <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
              <span>{ocrError}</span>
            </div>
          )}

          {/* Interactive WhatsApp Input Console */}
          <div className="bg-[#1f2c34] p-2.5 sm:p-3 border-t border-slate-800 space-y-2">
            
            {/* Input Controls Bar (Sender toggle & Forwarded tag) */}
            <div className="flex items-center justify-between text-xs px-1">
              
              {/* Sender Role Switcher */}
              <div className="flex items-center space-x-1.5">
                <span className="text-[11px] text-slate-400 font-semibold">Message as:</span>
                <button
                  type="button"
                  onClick={() => setInputSenderType('contact')}
                  className={`px-2 py-0.5 rounded-md text-[11px] font-bold transition-all ${
                    inputSenderType === 'contact'
                      ? 'bg-rose-600/30 text-rose-300 border border-rose-500/50'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  🔴 Incoming (Contact)
                </button>
                <button
                  type="button"
                  onClick={() => setInputSenderType('me')}
                  className={`px-2 py-0.5 rounded-md text-[11px] font-bold transition-all ${
                    inputSenderType === 'me'
                      ? 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/50'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  🟢 Outgoing (Me)
                </button>
              </div>

              {/* Forwarded Tag Checkbox */}
              {inputSenderType === 'contact' && (
                <label className="flex items-center space-x-1.5 text-[11px] text-slate-400 hover:text-slate-200 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={inputIsForwarded}
                    onChange={(e) => setInputIsForwarded(e.target.checked)}
                    className="rounded bg-slate-900 border-slate-700 text-emerald-500 focus:ring-0 cursor-pointer"
                  />
                  <span>Mark Forwarded</span>
                </label>
              )}

            </div>

            {/* Text Input Row with Attach & Send Buttons */}
            <div className="flex items-center gap-2">
              
              {/* File Attachment Button */}
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={ocrLoading}
                className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors shrink-0"
                title="Upload Chat Screenshot or Image to Scan"
              >
                <Paperclip className="w-4 h-4" />
              </button>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileInputChange}
                className="hidden"
              />

              {/* Text Input */}
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                placeholder={
                  pendingImage 
                    ? "Add an optional note to this image and press Enter..." 
                    : "Type or paste a WhatsApp chat message (press Enter to add)..."
                }
                className="flex-1 bg-[#111b21] rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-slate-100 placeholder-slate-500 border border-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />

              {/* Send Button */}
              <button
                type="button"
                onClick={handleSendMessage}
                disabled={!inputText.trim() && !pendingImage}
                className="p-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-bold transition-all shrink-0 shadow-lg shadow-emerald-950/40"
                title="Add message to chat"
              >
                <Send className="w-4 h-4" />
              </button>

            </div>

          </div>

        </div>

        {/* Right Column: Threat Radar, Red Flags & Share-to-Scan Dispatcher (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          
          {/* Focused Message / Overall Conversation Verdict Card */}
          <div className={`p-4 sm:p-5 rounded-2xl border shadow-xl ${
            isScamVerdict 
              ? 'bg-slate-900 border-rose-500/40 shadow-rose-950/20' 
              : 'bg-slate-900 border-emerald-500/40 shadow-emerald-950/20'
          }`}>
            
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                WhatsApp Threat Index
              </span>
              <span className={`text-xs font-black px-2.5 py-1 rounded-full border ${
                isScamVerdict 
                  ? 'bg-rose-500/20 text-rose-400 border-rose-500/40' 
                  : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
              }`}>
                {isScamVerdict ? 'CRITICAL SCAM DETECTED' : 'SAFE / NO THREAT'}
              </span>
            </div>

            <div className="flex items-baseline space-x-2 mb-2">
              <span className={`text-4xl font-extrabold tracking-tight ${
                isScamVerdict ? 'text-rose-500' : 'text-emerald-400'
              }`}>
                {overallAnalysis.threatScore}
              </span>
              <span className="text-sm font-semibold text-slate-500">/ 100 Threat Index</span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed mb-3">
              {isScamVerdict
                ? `ScamLens analyzed ${messages.filter(m => m.sender === 'contact').length} incoming message(s) from "${senderName}". Manipulative psychological traps and coercive demands were detected.`
                : `No coercion, digital arrest threats, advance fee lottery, or suspicious APK links detected.`}
            </p>

            {/* Identified Red Flags List */}
            <div className="space-y-2 mt-3 pt-3 border-t border-slate-800 text-xs">
              <span className="font-semibold text-slate-300 block">Identified Manipulative Red Flags:</span>
              
              {(overallAnalysis.highlights && overallAnalysis.highlights.length > 0) ? (
                <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1 scrollbar-thin">
                  {overallAnalysis.highlights.map((trig, idx) => (
                    <div key={idx} className="p-2 rounded-lg bg-slate-950/80 border border-slate-800 flex items-start space-x-2">
                      <AlertOctagon className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold text-rose-300 block text-[11px]">{trig.categoryLabel || trig.category} Trap</span>
                        <span className="text-[11px] text-slate-300 font-mono">"{trig.text}"</span>
                        {trig.explanation && (
                          <p className="text-[10px] text-slate-400 mt-0.5">{trig.explanation}</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-[11px] text-slate-400 italic">
                  No coercive urgency, impersonation, or suspicious payment links detected.
                </p>
              )}
            </div>

            {/* Quick Link to Emergency 1930 */}
            {isScamVerdict && (
              <div className="mt-3 pt-3 border-t border-slate-800 flex items-center justify-between">
                <span className="text-[11px] text-slate-400">Need immediate help?</span>
                <a
                  href="tel:1930"
                  className="px-3 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center space-x-1.5 shadow"
                >
                  <PhoneCall className="w-3 h-3" />
                  <span>Call 1930 Helpline</span>
                </a>
              </div>
            )}

          </div>

          {/* Share-to-Scan Link & Dispatcher Card */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
            <div className="flex items-center space-x-2 text-slate-200">
              <Share2 className="w-4 h-4 text-emerald-400" />
              <h4 className="text-xs font-bold uppercase tracking-wider">
                WhatsApp "Share to Scan" Link
              </h4>
            </div>

            <p className="text-[11px] text-slate-300 leading-relaxed">
              Send this link to friends or family on WhatsApp. When clicked, it opens ScamLens, loads this exact chat, and plays the voice alert!
            </p>

            <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2 font-mono text-[11px]">
              <div className="flex items-center justify-between text-emerald-300 truncate">
                <span className="truncate pr-2">{shareToScanUrl}</span>
                <button
                  onClick={handleCopyShareLink}
                  className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors shrink-0"
                  title="Copy Link"
                >
                  {copiedShareLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>

              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
                <button
                  onClick={handleCopyShareText}
                  className="w-full py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center space-x-1.5 transition-colors"
                >
                  {copiedShareText ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>Copy Complete Fraud Warning Message</span>
                </button>
              </div>
            </div>

            {/* Quick Share to WhatsApp CTA */}
            <button
              onClick={handleShareToWhatsApp}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 font-bold text-xs text-white shadow-lg flex items-center justify-center space-x-2 transition-all transform active:scale-95"
            >
              <MessageSquare className="w-4 h-4 fill-current" />
              <span>Forward Alert to WhatsApp Contact / Group</span>
            </button>
          </div>

        </div>

      </div>

      {/* Lightbox Modal for Full-Screen Image Viewing */}
      {lightboxImage && (
        <div 
          onClick={() => setLightboxImage(null)}
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in"
        >
          <div 
            onClick={(e) => e.stopPropagation()}
            className="relative max-w-2xl max-h-[85vh] bg-slate-900 rounded-2xl border border-slate-700 overflow-hidden shadow-2xl"
          >
            <div className="p-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between text-xs text-slate-300">
              <span className="font-bold flex items-center space-x-1.5">
                <Eye className="w-3.5 h-3.5 text-emerald-400" />
                <span>Full Screenshot & Document Inspector</span>
              </span>
              <button
                onClick={() => setLightboxImage(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-3 overflow-auto max-h-[75vh]">
              <img src={lightboxImage} alt="Expanded Screenshot" className="max-w-full rounded-lg object-contain mx-auto" />
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
