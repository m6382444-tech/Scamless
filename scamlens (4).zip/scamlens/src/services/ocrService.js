// Client-side OCR service using Tesseract.js with graceful fallback

import Tesseract from 'tesseract.js';

export async function extractTextFromImage(fileOrUrl, onProgress) {
  try {
    const result = await Tesseract.recognize(
      fileOrUrl,
      'eng',
      {
        logger: (m) => {
          if (onProgress && m.status === 'recognizing text' && m.progress) {
            onProgress(Math.round(m.progress * 100));
          }
        }
      }
    );

    const text = result?.data?.text?.trim();
    if (text && text.length > 5) {
      return {
        success: true,
        text,
        confidence: result?.data?.confidence || 85
      };
    }
  } catch (err) {
    console.warn("Tesseract OCR fallback to client parser:", err);
  }

  // Graceful fallback: return message suggesting typing or standard text extraction
  return {
    success: false,
    text: "",
    error: "Could not read clear text from image. Please ensure text is legible."
  };
}
