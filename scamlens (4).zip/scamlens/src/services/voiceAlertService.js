// ScamLens Multilingual Voice Verifier & Audio Shield Engine
// Powered by Web Speech API & Web Audio Synthesis

export const SUPPORTED_LANGUAGES = [
  { code: 'en', name: 'English (India/Global)', flag: '🇮🇳', bcp47: 'en-IN' },
  { code: 'hi', name: 'Hindi (हिंदी)', flag: '🇮🇳', bcp47: 'hi-IN' },
  { code: 'hinglish', name: 'Hinglish (Hindi-English)', flag: '🇮🇳', bcp47: 'en-IN' },
  { code: 'ta', name: 'Tamil (தமிழ்)', flag: '🇮🇳', bcp47: 'ta-IN' },
  { code: 'te', name: 'Telugu (తెలుగు)', flag: '🇮🇳', bcp47: 'te-IN' },
  { code: 'kn', name: 'Kannada (ಕನ್ನಡ)', flag: '🇮🇳', bcp47: 'kn-IN' },
  { code: 'bn', name: 'Bengali (বাংলা)', flag: '🇮🇳', bcp47: 'bn-IN' },
  { code: 'mr', name: 'Marathi (मराठी)', flag: '🇮🇳', bcp47: 'mr-IN' }
];

export const VOICE_TONES = [
  { id: 'pro', label: 'Shield Pro', description: 'Authoritative, clear & law-enforcement alert' },
  { id: 'street', label: 'Street Alert', description: 'Direct, urgent & raw scam punchline' }
];

export const VOICE_VERDICTS = {
  scam: {
    pro: {
      en: "Critical Alert! This is a dangerous scam. Do not proceed, do not send any money, and do not share any OTP or passwords. You are being targeted by cyber fraudsters.",
      hi: "सावधान! यह एक गंभीर और खतरनाक स्कैम है। आगे बिल्कुल न बढ़ें, कोई भी ओटीपी या पैसे न भेजें। आप साइबर अपराधियों के निशाने पर हैं।",
      hinglish: "Savdhaan! Yeh ek khatarnak scam hai! Aage bilkul mat badhein, koi bhi OTP ya payment na karein. Yeh 100% fraud hai!",
      ta: "ஆபத்து எச்சரிக்கை! இது ஒரு ஆபத்தான மோசடி! தயவுசெய்து தொடர வேண்டாம், எந்த ஓடிபி அல்லது பணத்தையும் அனுப்ப வேண்டாம். நீங்கள் குறிவைக்கப்படுகிறீர்கள்.",
      te: "ప్రమాద హెచ్చరిక! ఇది ప్రమాదకరమైన మోసం! ముందుకు సాగవద్దు, ఎలాంటి OTP లేదా డబ్బును పంపవద్దు. మీరు మోసగాళ్ల బారిన పడుతున్నారు.",
      kn: "ಎಚ್ಚರಿಕೆ! ಇದು ಅತ್ಯಂತ ಅಪಾಯಕಾರಿ ವಂಚನೆ! ಮುಂದುವರಿಯಬೇಡಿ, ಯಾವುದೇ ಒಟಿಪಿ ಅಥವಾ ಹಣವನ್ನು ಕಳುಹಿಸಬೇಡಿ.",
      bn: "বিপদ সতর্কতা! এটি একটি বিপজ্জনক প্রতারণা! এগিয়ে যাবেন না, কোনো ওটিপি বা টাকা পাঠাবেন না। আপনি প্রতারকদের নিশানায় রয়েছেন।",
      mr: "सावधान! हा एक अत्यंत धोकादायक घोटाळा आहे. पुढे जाऊ नका, कोणताही ओटीपी किंवा पैसे पाठवू नका. तुम्ही सायबर गुन्हेगारांच्या निशाण्यावर आहात."
    },
    street: {
      en: "Warning! This is a scam, you just got trapped if you believed this! Stop immediately, block this contact, and do not send a single rupee.",
      hi: "चेतावनी! यह एक पक्का स्कैम है, आप बुरी तरह फंसने वाले थे! तुरंत रुकें, इस नंबर को ब्लॉक करें और कोई पैसा न दें।",
      hinglish: "Alert! Yeh scam hai, aap phasne wale the! Turant stop karo, contact ko block karo aur ek rupya bhi mat bhejo!",
      ta: "எச்சரிக்கை! இது அப்பட்டமான மோசடி, சிக்கிக் கொள்ளாதீர்கள்! உடனே இந்த தொடர்பை தடுத்து நிறுத்துங்கள்.",
      te: "హెచ్చరిక! ఇది పక్కా మోసం, మీరు మోసపోబోతున్నారు! వెంటనే ఆగిపోండి, ఈ నంబర్‌ను బ్లాక్ చేయండి.",
      kn: "ಎಚ್ಚರಿಕೆ! ಇದು ನೇರ ಮೋಸ, ತಕ್ಷಣ ಈ ಸಂಪರ್ಕವನ್ನು ನಿರ್ಬಂಧಿಸಿ ಮತ್ತು ಯಾವುದೇ ಹಣ ನೀಡಬೇಡಿ.",
      bn: "সতর্কতা! এটি একটি খাঁটি প্রতারণা, আপনি ফাঁদে পড়তে যাচ্ছিলেন! অবিলম্বে এই নম্বরটি ব্লক করুন।",
      mr: "सावधान! हा एक उघड घोटाळा आहे, तुम्ही फसवले जाणार होतात! त्वरित थांबा आणि हा नंबर ब्लॉक करा."
    }
  },
  safe: {
    pro: {
      en: "Verification Passed: You are safe to proceed further with your work with this contact. No threat signals were detected, this is not a scam.",
      hi: "सत्यापन सफल: आप इस संपर्क के साथ अपने काम को सुरक्षित रूप से आगे बढ़ा सकते हैं। कोई खतरा नहीं मिला, यह स्कैम नहीं है।",
      hinglish: "Verification Passed: Aap iss contact ke sath bina kisi dar safe aage badh sakte hain. Koi threat nahi mila, yeh scam nahi hai.",
      ta: "சரிபார்ப்பு முடிந்தது: இந்தத் தொடர்புடன் உங்கள் பணியைத் தொடர நீங்கள் பாதுகாப்பாக உள்ளீர்கள். எந்த அச்சுறுத்தலும் கண்டறியப்படவில்லை, இது மோசடி அல்ல.",
      te: "ధృవీకరణ పూర్తయింది: మీరు ఈ పరిచయంతో మీ పనిని సురక్షితంగా కొనసాగించవచ్చు. ఎలాంటి ముప్పు లేదు, ఇది మోసం కాదు.",
      kn: "ಪರಿಶೀಲನೆ ಪೂರ್ಣಗೊಂಡಿದೆ: ಈ ಸಂಪರ್ಕದೊಂದಿಗೆ ನೀವು ಸುರಕ್ಷಿತವಾಗಿ ಕೆಲಸವನ್ನು ಮುಂದುವರಿಸಬಹುದು. ಇದು ವಂಚನೆಯಲ್ಲ.",
      bn: "যাচাইকরণ সফল: আপনি নিরাপদে এই যোগাযোগের সাথে কাজ চালিয়ে যেতে পারেন। কোনো হুমকি নেই, এটি প্রতারণা নয়।",
      mr: "सत्यापन यशस्वी: आपण या संपर्कासह सुरक्षितपणे काम सुरू ठेवू शकता. कोणताही धोका आढळला नाही, हा घोटाळा नाही."
    },
    street: {
      en: "All Clear: You're safe to proceed further with your work with the contact. This is not a scam.",
      hi: "सब सुरक्षित है: आप इस संपर्क के साथ अपना काम बेफिक्र होकर कर सकते हैं, यह कोई स्कैम नहीं है।",
      hinglish: "All Clear: Aap safe hain! Iss contact ke sath kaam aage badha sakte hain, yeh scam nahi hai.",
      ta: "அனைத்தும் பாதுகாப்பானது: நீங்கள் இந்தத் தொடர்புடன் தொடரலாம், இது மோசடி அல்ல.",
      te: "అంతా సురక్షితం: మీరు ఈ పరిచయంతో ముందుకు వెళ్లవచ్చు, ఇది మోసం కాదు.",
      kn: "ಎಲ್ಲವೂ ಸುರಕ್ಷಿತ: ನೀವು ಕೆಲಸ ಮುಂದುವರಿಸಬಹುದು, ಇದು ವಂಚನೆಯಲ್ಲ.",
      bn: "সব নিরাপদ: আপনি এই যোগাযোগের সাথে কাজ এগিয়ে নিতে পারেন, এটি কোনো প্রতারণা নয়।",
      mr: "सर्व सुरक्षित: आपण काम पुढे सुरू करू शकता, हा घोटाळा नाही."
    }
  }
};

/**
 * Play synthesizer audio chime (Siren for Scam, Harmonic Chime for Safe)
 */
export function playSynthesizedChime(isScam) {
  try {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return;
    const ctx = new AudioContext();
    if (ctx.state === 'suspended') {
      ctx.resume();
    }

    if (isScam) {
      // Rapid dual-tone warning siren
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      
      const now = ctx.currentTime;
      osc.frequency.setValueAtTime(880, now);
      osc.frequency.linearRampToValueAtTime(440, now + 0.12);
      osc.frequency.linearRampToValueAtTime(880, now + 0.24);
      osc.frequency.linearRampToValueAtTime(440, now + 0.36);
      osc.frequency.linearRampToValueAtTime(880, now + 0.48);
      osc.frequency.linearRampToValueAtTime(300, now + 0.65);

      gain.gain.setValueAtTime(0.3, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.7);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.7);
    } else {
      // Gentle uplifting harmonic major triad (C5 - E5 - G5)
      const now = ctx.currentTime;
      [523.25, 659.25, 783.99].forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * 0.1);

        gain.gain.setValueAtTime(0.001, now);
        gain.gain.setValueAtTime(0.2, now + idx * 0.1);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.1 + 0.5);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + idx * 0.1);
        osc.stop(now + idx * 0.1 + 0.5);
      });
    }
  } catch (err) {
    console.warn("Synthesizer chime failed:", err);
  }
}

/**
 * Speak verdict using Web Speech API with language and tone selection
 */
export function speakVerdict({
  isScam = true,
  language = 'en',
  tone = 'pro',
  onStart = () => {},
  onEnd = () => {},
  onError = () => {}
} = {}) {
  // Always trigger immediate audio cue
  playSynthesizedChime(isScam);

  if (!('speechSynthesis' in window)) {
    console.warn("SpeechSynthesis not supported on this browser");
    onError(new Error("SpeechSynthesis not supported"));
    return;
  }

  // Cancel any ongoing speech
  window.speechSynthesis.cancel();

  // Pick appropriate script
  const statusKey = isScam ? 'scam' : 'safe';
  const toneObj = VOICE_VERDICTS[statusKey][tone] || VOICE_VERDICTS[statusKey].pro;
  const scriptText = toneObj[language] || toneObj.en;

  const utterance = new SpeechSynthesisUtterance(scriptText);
  utterance.rate = isScam ? 1.05 : 0.95; // Urgent if scam, calm if safe
  utterance.pitch = isScam ? 1.1 : 1.0;

  // Language mapping
  const langConfig = SUPPORTED_LANGUAGES.find(l => l.code === language) || SUPPORTED_LANGUAGES[0];
  utterance.lang = langConfig.bcp47;

  // Attempt to select optimal regional voice
  const voices = window.speechSynthesis.getVoices();
  if (voices && voices.length > 0) {
    const targetLangCode = langConfig.bcp47.toLowerCase();
    const matchedVoice = voices.find(v => v.lang.toLowerCase() === targetLangCode) ||
      voices.find(v => v.lang.toLowerCase().startsWith(language)) ||
      voices.find(v => v.lang.toLowerCase().includes('in')) ||
      voices[0];
    
    if (matchedVoice) {
      utterance.voice = matchedVoice;
    }
  }

  utterance.onstart = () => {
    onStart();
  };

  utterance.onend = () => {
    onEnd();
  };

  utterance.onerror = (e) => {
    console.warn("Speech synthesis utterance error:", e);
    onError(e);
  };

  // Speak
  window.speechSynthesis.speak(utterance);
}

/**
 * Stop any current speech playback
 */
export function stopVoice() {
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}

/**
 * Get script text directly without speaking (for UI preview or subtitle)
 */
export function getVerdictScript(isScam, language = 'en', tone = 'pro') {
  const statusKey = isScam ? 'scam' : 'safe';
  const toneObj = VOICE_VERDICTS[statusKey][tone] || VOICE_VERDICTS[statusKey].pro;
  return toneObj[language] || toneObj.en;
}
