import React from 'react';
import { AlertOctagon, ShieldAlert, CheckCircle, AlertTriangle, Shield } from 'lucide-react';

export default function ScamScoreMeter({ analysis }) {
  if (!analysis) return null;

  const score = analysis.threatScore || 0;

  let gaugeColor = 'from-emerald-500 to-green-600';
  let badgeColor = 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
  let textColor = 'text-emerald-400';
  let Icon = Shield;

  if (score >= 80) {
    gaugeColor = 'from-rose-600 via-red-600 to-red-500';
    badgeColor = 'bg-red-500/20 text-red-400 border-red-500/40 animate-pulse';
    textColor = 'text-red-500';
    Icon = AlertOctagon;
  } else if (score >= 50) {
    gaugeColor = 'from-amber-600 to-orange-500';
    badgeColor = 'bg-amber-500/20 text-amber-400 border-amber-500/40';
    textColor = 'text-amber-400';
    Icon = AlertTriangle;
  } else if (score >= 20) {
    gaugeColor = 'from-yellow-600 to-amber-500';
    badgeColor = 'bg-yellow-500/20 text-yellow-400 border-yellow-500/40';
    textColor = 'text-yellow-400';
    Icon = ShieldAlert;
  }

  const breakdown = analysis.categoryBreakdown || {};

  return (
    <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-5">
      {/* Top Threat Rating Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 border ${badgeColor}`}>
            <Icon className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className={`text-xs font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full border ${badgeColor}`}>
                {analysis.threatLevel}
              </span>
            </div>
            <h3 className="text-lg sm:text-xl font-bold text-white mt-1">
              ScamLens Threat Rating
            </h3>
          </div>
        </div>

        {/* Score Number */}
        <div className="text-right sm:text-right">
          <div className="flex items-baseline space-x-1">
            <span className={`text-4xl sm:text-5xl font-black font-mono tracking-tight ${textColor}`}>
              {score}
            </span>
            <span className="text-sm font-bold text-slate-500 font-mono">/ 100</span>
          </div>
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
            Composite Threat Index
          </span>
        </div>
      </div>

      {/* Progress Bar Gauge */}
      <div className="w-full bg-slate-950 h-3.5 rounded-full overflow-hidden p-0.5 border border-slate-800">
        <div
          className={`h-full rounded-full bg-gradient-to-r ${gaugeColor} transition-all duration-700`}
          style={{ width: `${Math.max(4, score)}%` }}
        ></div>
      </div>

      {/* Trigger Count Pills */}
      <div className="flex flex-wrap gap-2 text-xs">
        {breakdown.urgency > 0 && (
          <span className="px-2.5 py-1 rounded-lg bg-rose-500/15 border border-rose-500/30 text-rose-300 font-medium">
            🔴 {breakdown.urgency} Urgency {breakdown.urgency > 1 ? 'Tactics' : 'Tactic'}
          </span>
        )}
        {breakdown.suspicious_link > 0 && (
          <span className="px-2.5 py-1 rounded-lg bg-orange-500/15 border border-orange-500/30 text-orange-300 font-medium">
            🟠 {breakdown.suspicious_link} Suspicious {breakdown.suspicious_link > 1 ? 'Links' : 'Link'}
          </span>
        )}
        {breakdown.fake_authority > 0 && (
          <span className="px-2.5 py-1 rounded-lg bg-yellow-500/15 border border-yellow-500/30 text-yellow-300 font-medium">
            🟡 {breakdown.fake_authority} Authority {breakdown.fake_authority > 1 ? 'Claims' : 'Claim'}
          </span>
        )}
        {breakdown.financial_trap > 0 && (
          <span className="px-2.5 py-1 rounded-lg bg-purple-500/15 border border-purple-500/30 text-purple-300 font-medium">
            🟣 {breakdown.financial_trap} Credential / Fee {breakdown.financial_trap > 1 ? 'Traps' : 'Trap'}
          </span>
        )}
        {breakdown.fear_intimidation > 0 && (
          <span className="px-2.5 py-1 rounded-lg bg-sky-500/15 border border-sky-500/30 text-sky-300 font-medium">
            🔵 {breakdown.fear_intimidation} Legal / Arrest {breakdown.fear_intimidation > 1 ? 'Threats' : 'Threat'}
          </span>
        )}
        {breakdown.greed_bait > 0 && (
          <span className="px-2.5 py-1 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-medium">
            🟢 {breakdown.greed_bait} Greed {breakdown.greed_bait > 1 ? 'Baits' : 'Bait'}
          </span>
        )}
      </div>

      {/* Verdict Summary Text */}
      <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs sm:text-sm text-slate-300 leading-relaxed">
        <strong className="block text-white font-semibold mb-1">Expert AI & NLP Verdict:</strong>
        {analysis.verdictSummary}
      </div>
    </div>
  );
}
