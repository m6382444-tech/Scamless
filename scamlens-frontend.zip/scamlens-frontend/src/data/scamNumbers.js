// Comprehensive Database of Known Scam Callers & Intelligence Heuristics with GPS Location
export const SCAM_CALLER_DATABASE = [
  {
    number: "+91 98765 43210",
    normalized: "9876543210",
    callerName: "Electricity Officer Mr. Sharma (SPOOFED)",
    carrier: "Virtual / Leased PRI Gateway",
    circle: "Mumbai / Maharashtra",
    location: "Mumbai, Maharashtra, India",
    coordinates: { lat: 19.0760, lng: 72.8777 },
    reportCount: 384,
    threatScore: 98,
    threatLevel: "Critical Scam",
    category: "Electricity Disconnection Threat",
    status: "Active Threat - High Volume",
    lastReported: "10 minutes ago",
    reportedOn: ["Chakshu (Sanchar Saathi)", "Cybercrime 1930 Portal", "Truecaller Community"],
    tags: ["Power Cutoff Scam", "Extortion", "Payment Gateway Harvesting"],
    scriptSummary: "Caller claims electricity will be severed at 9:30 PM due to unpaid balance; urges installing QuickSupport/AnyDesk or paying immediately on phishing link.",
    incomingSimulation: {
      callerDisplay: "⚡ Electricity Dept Officer",
      subText: "Suspected Fraud • 384 Reports",
      ringtoneNote: "Urgent alarm tone",
      audioTranscript: [
        { speaker: "Scammer", time: "00:01", text: "Hello! This is Officer Sharma from Central Electricity Discom head office. Are you listening?" },
        { speaker: "Scammer", time: "00:05", text: "Your previous month bill update failed in our server. Your power line is scheduled for automatic disconnect at 9:30 PM tonight!" },
        { speaker: "Scammer", time: "00:11", text: "If you don't want darkness tonight, immediately open the SMS I sent and pay ₹10 verification fee, or install our remote support app right now!" }
      ]
    }
  },
  {
    number: "+92 300 1234567",
    normalized: "923001234567",
    callerName: "CBI Cyber Branch / Officer R.K. Yadav (SPOOFED)",
    carrier: "Jazz Telecom (Pakistan / Foreign VOIP)",
    circle: "International Origin (+92 Pakistan)",
    location: "Lahore, Punjab, Pakistan",
    coordinates: { lat: 31.5204, lng: 74.3587 },
    reportCount: 1420,
    threatScore: 99,
    threatLevel: "Critical Threat",
    category: "Digital Arrest / Police Impersonation",
    status: "High Priority Cybercrime Syndicate",
    lastReported: "3 minutes ago",
    reportedOn: ["Ministry of Home Affairs I4C", "Chakshu Portal", "National 1930 Helpline"],
    tags: ["Digital Arrest", "CBI Impersonation", "Narcotics Blackmail", "Extortion"],
    scriptSummary: "Caller wears fake police uniform on Skype/WhatsApp, claims victim's Aadhaar is linked to money laundering and narcotics; threatens arrest unless money is wired to 'government verification escrow'.",
    incomingSimulation: {
      callerDisplay: "🚨 CBI Cyber Crime Division",
      subText: "WARNING: International Foreign VOIP (+92)",
      ringtoneNote: "Siren sound / Red Alert",
      audioTranscript: [
        { speaker: "Scammer", time: "00:01", text: "I am Inspector R.K. Yadav from CBI Headquarters New Delhi. Turn on your video camera immediately!" },
        { speaker: "Scammer", time: "00:07", text: "Your Aadhaar card was found at a narcotics crime scene in Mumbai Airport. You are under official Digital Arrest!" },
        { speaker: "Scammer", time: "00:13", text: "Do NOT cut this call, do not speak to your family! You must transfer your savings to the RBI verification account immediately!" }
      ]
    }
  },
  {
    number: "+91 87654 32109",
    normalized: "8765432109",
    callerName: "SBI YONO Verification Desk (SPOOFED)",
    carrier: "Airtel Virtual PBX",
    circle: "Noida / Delhi NCR",
    location: "Noida Cyber Hub, Uttar Pradesh, India",
    coordinates: { lat: 28.5355, lng: 77.3910 },
    reportCount: 512,
    threatScore: 95,
    threatLevel: "Critical Scam",
    category: "Banking KYC Suspension",
    status: "Active Automated IVR Phishing",
    lastReported: "25 minutes ago",
    reportedOn: ["SBI Security Team", "Chakshu", "Cybercrime 1930"],
    tags: ["YONO Phishing", "Bank Impersonation", "OTP Theft"],
    scriptSummary: "Robocall notifying account suspension within 2 hours, pressing user to press 1 to connect with fake KYC executive who demands net banking password and OTP.",
    incomingSimulation: {
      callerDisplay: "🏦 State Bank of India YONO Desk",
      subText: "Reported Banking Phishing • High Risk",
      ringtoneNote: "Standard Bell + Alarm Overlay",
      audioTranscript: [
        { speaker: "IVR Robot", time: "00:01", text: "Attention SBI Customer. Your YONO internet banking has been suspended due to expired PAN KYC." },
        { speaker: "Scammer", time: "00:06", text: "Sir, I am connecting you to customer desk. Please share the 6-digit OTP sent to your registered mobile to avoid ₹5,00,000 account freeze." }
      ]
    }
  },
  {
    number: "+91 93110 54321",
    normalized: "9311054321",
    callerName: "Delhi Cyber Police Station Notice (SPOOFED)",
    carrier: "Reliance Jio Leased PRI",
    circle: "New Delhi / NCR",
    location: "New Delhi, Delhi NCR, India",
    coordinates: { lat: 28.6139, lng: 77.2090 },
    reportCount: 890,
    threatScore: 97,
    threatLevel: "Critical Scam",
    category: "Digital Arrest / Police Extortion",
    status: "Active Impersonation Ring",
    lastReported: "8 minutes ago",
    reportedOn: ["Delhi Police IFSO", "Chakshu", "1930 Helpline"],
    tags: ["Police Impersonator", "Illegal SIM", "Video Interrogation"],
    scriptSummary: "Threatens victim that 14 illegal SIM cards were issued under their Aadhaar in Delhi; orders victim to remain in room on video call.",
    incomingSimulation: {
      callerDisplay: "🚔 Delhi Police Cyber Wing",
      subText: "890 Reports • Confirmed Extortion Ring",
      ringtoneNote: "Urgent Siren",
      audioTranscript: [
        { speaker: "Scammer", time: "00:01", text: "This is Sub-Inspector Verma from Delhi Cyber Police. Your Aadhaar was used in illegal terrorist communication." },
        { speaker: "Scammer", time: "00:06", text: "Do not disconnect! If you disconnect, police patrol van will reach your house in 15 minutes." }
      ]
    }
  },
  {
    number: "+84 92 817 4021",
    normalized: "84928174021",
    callerName: "Priya Sharma (Apex Global HR Tasks)",
    carrier: "Viettel Mobile (Vietnam)",
    circle: "Southeast Asia Gateway (+84)",
    location: "Ho Chi Minh City, Vietnam",
    coordinates: { lat: 10.8231, lng: 106.6297 },
    reportCount: 642,
    threatScore: 94,
    threatLevel: "High Risk Scam",
    category: "Part-Time Task & Telegram Job Scam",
    status: "Active Recruitment Funnel",
    lastReported: "14 minutes ago",
    reportedOn: ["Chakshu", "Truecaller Community"],
    tags: ["Task Scam", "YouTube Like Fraud", "Prepaid VIP Trap"],
    scriptSummary: "Promises ₹3,500 daily for liking YouTube videos. Pays ₹150 trial bonus, then demands ₹20,000 prepaid investment to withdraw earnings.",
    incomingSimulation: {
      callerDisplay: "💼 Apex Global Media HR",
      subText: "Foreign Recruiter • 642 Spam Reports",
      ringtoneNote: "Standard Bell",
      audioTranscript: [
        { speaker: "Scammer", time: "00:01", text: "Hello! You have been selected for home-based part time work earning up to ₹8,000 per day." }
      ]
    }
  },
  {
    number: "+91 91234 56789",
    normalized: "9123456789",
    callerName: "India Post Delivery Hub (SPOOFED)",
    carrier: "Vodafone Idea Prepaid",
    circle: "Kolkata / West Bengal",
    location: "Kolkata, West Bengal, India",
    coordinates: { lat: 22.5726, lng: 88.3639 },
    reportCount: 189,
    threatScore: 89,
    threatLevel: "High Risk Scam",
    category: "Courier / Smishing Verification",
    status: "Active Smishing Dispatcher",
    lastReported: "42 minutes ago",
    reportedOn: ["Chakshu", "India Post Grievances"],
    tags: ["India Post Spoof", "Address Update", "Card Phishing"],
    scriptSummary: "Automated voice claiming package returned; instructs victim to verify address on fake India Post domain.",
    incomingSimulation: {
      callerDisplay: "📦 India Post Speed Post Desk",
      subText: "Spoofed Courier Dispatcher",
      ringtoneNote: "Standard Bell",
      audioTranscript: [
        { speaker: "Scammer", time: "00:01", text: "Speed Post delivery failed for parcel ending in 41IN. House number missing." },
        { speaker: "Scammer", time: "00:05", text: "Please pay ₹25 token fee on the SMS link sent to your phone within 2 hours or parcel will be incinerated." }
      ]
    }
  }
];

// Major Indian Telecom Circles & Regional Geolocation Metadata
const INDIAN_TELECOM_CIRCLES = [
  { prefix: ['981', '987', '991', '931', '971'], circle: 'Delhi NCR', city: 'New Delhi, Delhi NCR', lat: 28.6139, lng: 77.2090, carrier: 'Airtel / Jio' },
  { prefix: ['982', '989', '992', '932', '972'], circle: 'Mumbai Metro', city: 'Mumbai, Maharashtra', lat: 19.0760, lng: 72.8777, carrier: 'Vodafone Idea / Jio' },
  { prefix: ['984', '994', '934', '944', '974'], circle: 'Karnataka', city: 'Bengaluru, Karnataka', lat: 12.9716, lng: 77.5946, carrier: 'Airtel / BSNL' },
  { prefix: ['983', '993', '933', '943'], circle: 'West Bengal / Kolkata', city: 'Kolkata, West Bengal', lat: 22.5726, lng: 88.3639, carrier: 'Airtel / Jio' },
  { prefix: ['988', '998', '938', '948'], circle: 'Tamil Nadu / Chennai', city: 'Chennai, Tamil Nadu', lat: 13.0827, lng: 80.2707, carrier: 'Airtel / Vi' },
  { prefix: ['986', '996', '936'], circle: 'Andhra Pradesh & Telangana', city: 'Hyderabad, Telangana', lat: 17.3850, lng: 78.4867, carrier: 'Airtel / Jio' },
  { prefix: ['985', '995', '935'], circle: 'Punjab', city: 'Chandigarh / Ludhiana', lat: 30.7333, lng: 76.7794, carrier: 'Jio / Airtel' },
  { prefix: ['980', '990', '940'], circle: 'Haryana & Mewat Cluster', city: 'Nuh / Gurugram, Haryana', lat: 28.1189, lng: 76.9989, carrier: 'Prepaid SIM Gateway', isHighRiskHub: true },
  { prefix: ['979', '969', '959'], circle: 'Jharkhand (Jamtara Cluster)', city: 'Jamtara / Ranchi, Jharkhand', lat: 24.2144, lng: 86.6433, carrier: 'Prepaid Multi-SIM', isHighRiskHub: true },
  { prefix: ['978', '968', '958'], circle: 'Rajasthan', city: 'Jaipur, Rajasthan', lat: 26.9124, lng: 75.7873, carrier: 'Airtel / Vi' }
];

// Helper to evaluate phone numbers and extract GPS Location & Registered Name
export function evaluatePhoneNumber(rawNumber) {
  if (!rawNumber) return null;
  
  const cleaned = rawNumber.replace(/[\s\-\(\)\.]/g, '');
  const digitsOnly = cleaned.replace(/^\+/, '');
  
  // 1. Direct match in confirmed database
  const match = SCAM_CALLER_DATABASE.find(item => {
    return cleaned.includes(item.normalized) || item.normalized.includes(digitsOnly);
  });
  
  if (match) {
    return {
      isScam: true,
      riskScore: match.threatScore,
      threatLevel: match.threatLevel,
      category: match.category,
      callerName: match.callerName,
      reportCount: match.reportCount,
      carrier: match.carrier,
      circle: match.circle,
      location: match.location || "Reported Cybercrime Center",
      coordinates: match.coordinates || { lat: 28.6139, lng: 77.2090 },
      reasons: [
        `Direct match in National Cybercrime / Chakshu blacklist (${match.reportCount} confirmed complaints)`,
        `Associated with known '${match.category}' syndicates`,
        match.scriptSummary
      ],
      details: match
    };
  }
  
  // 2. Intelligent heuristics for ANY custom phone number entered by the user
  const reasons = [];
  let riskScore = 15;
  let threatLevel = "Low Risk / Unflagged";
  let category = "Unflagged Caller";
  let callerName = "Unregistered / Unknown Mobile Subscriber";
  let reportCount = 0;
  let carrier = "Domestic Cellular Operator";
  let circle = "India Standard Circle";
  let location = "New Delhi, India";
  let coordinates = { lat: 28.6139, lng: 77.2090 };

  // A. Check International Extortion Codes
  if (cleaned.startsWith("+92") || digitsOnly.startsWith("92")) {
    riskScore = 98;
    threatLevel = "Critical Threat";
    category = "International Impersonation / Digital Arrest Risk";
    callerName = "Suspected Foreign Cyber Syndicate (+92)";
    carrier = "Jazz Telecom / Foreign VOIP";
    circle = "Pakistan International";
    location = "Lahore, Punjab, Pakistan";
    coordinates = { lat: 31.5204, lng: 74.3587 };
    reportCount = 1420;
    reasons.push("Originates from Pakistan (+92 country code). Indian government agencies and banks NEVER use Pakistani telecom networks.");
    reasons.push("Frequently exploited in WhatsApp lottery (KBC) and fake CBI/police digital arrest threats.");
  } else if (cleaned.startsWith("+84") || digitsOnly.startsWith("84")) {
    riskScore = 94;
    threatLevel = "High Risk Scam";
    category = "Part-Time Task Scam Gateway";
    callerName = "Foreign Recruiter Desk (+84)";
    carrier = "Viettel Mobile (Vietnam)";
    circle = "Vietnam International";
    location = "Ho Chi Minh City, Vietnam";
    coordinates = { lat: 10.8231, lng: 106.6297 };
    reportCount = 680;
    reasons.push("Frequently linked to unsolicited WhatsApp Telegram part-time job and YouTube liking task scams.");
  } else if (cleaned.startsWith("+234") || digitsOnly.startsWith("234")) {
    riskScore = 95;
    threatLevel = "High Risk";
    category = "International Advance-Fee / Customs Scam";
    callerName = "West African Gateway (+234)";
    carrier = "MTN / Airtel Nigeria";
    circle = "Nigeria International";
    location = "Lagos, Nigeria";
    coordinates = { lat: 6.5244, lng: 3.3792 };
    reportCount = 520;
    reasons.push("Originates from Nigeria (+234 country code). Known for customs lottery, parcel gift, and crypto recovery scams.");
  } else if (cleaned.startsWith("+1") || digitsOnly.startsWith("1")) {
    riskScore = 78;
    threatLevel = "Suspicious VOIP";
    category = "Virtual VOIP Gateway";
    callerName = "US/Canada Virtual Gateway (+1)";
    carrier = "Twilio / Bandwidth VOIP";
    circle = "North America Virtual";
    location = "San Francisco, CA, USA";
    coordinates = { lat: 37.7749, lng: -122.4194 };
    reportCount = 210;
    reasons.push("US/Canada number often provisioned via free VOIP apps by overseas scammers posing as recruiters.");
  } else if (cleaned.startsWith("+91") || digitsOnly.length === 10) {
    // B. Indian Mobile Numbers Heuristics
    const tenDigits = digitsOnly.slice(-10);
    const prefix3 = tenDigits.slice(0, 3);
    const matchedCircle = INDIAN_TELECOM_CIRCLES.find(c => c.prefix.some(p => prefix3.startsWith(p.slice(0, 2))));

    if (matchedCircle) {
      circle = matchedCircle.circle;
      location = matchedCircle.city;
      coordinates = { lat: matchedCircle.lat, lng: matchedCircle.lng };
      carrier = matchedCircle.carrier;

      if (matchedCircle.isHighRiskHub) {
        riskScore = 85;
        threatLevel = "High Risk Cyber Hub";
        category = "Mewat/Jamtara Extortion Cluster";
        callerName = "Suspicious Prepaid SIM (High-Crime Cluster)";
        reasons.push(`Geolocated to ${matchedCircle.city}, a region flagged by Indian Cyber Crime Coordination Centre (I4C).`);
      } else {
        callerName = `Mobile Subscriber (${matchedCircle.circle})`;
        threatLevel = "Domestic Mobile Number";
      }
    } else {
      circle = "National Telecom Gateway";
      location = "New Delhi, India";
      coordinates = { lat: 28.6139, lng: 77.2090 };
      callerName = "Indian Mobile Subscriber";
      carrier = "Reliance Jio / Airtel / Vi";
    }
  } else {
    callerName = "International Caller";
    location = "Global International Gateway";
    coordinates = { lat: 20.5937, lng: 78.9629 };
  }

  return {
    isScam: riskScore >= 40,
    riskScore,
    threatLevel,
    category,
    callerName,
    reportCount,
    carrier,
    circle,
    location,
    coordinates,
    reasons
  };
}
