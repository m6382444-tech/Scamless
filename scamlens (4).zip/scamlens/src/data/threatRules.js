// Comprehensive Rules and patterns for detecting manipulation tactics and cyber threats

export const THREAT_PATTERNS = [
  // 1. URGENCY TACTICS (RED)
  {
    category: "urgency",
    trickKey: "urgency",
    regex: /\b(within \d+ (?:hours?|hrs?|mins?|minutes?|days?)|tonight at \d+(?::\d+)?\s*(?:pm|am)?|in \d+ (?:hours?|hrs?|mins?|minutes?)|immediately|immediate|urgently?|hurry|asap|without delay|act now|only \d+ (?:vacancies|slots|left)|expire[sd]? (?:today|tonight|in \d+|soon)|expires? in \d+ (?:hours?|minutes?)|within 24 hours?|within 48 hours?|today only|last chance|final warning|final notice|action required|scheduled for (?:automatic )?disconnect(?:ion)?|permanently (?:deactivated|blocked|suspended|closed)|avoid (?:permanent )?(?:deactivation|penalty|disconnection|arrest|blocking)|warrant of arrest will be executed|within \d+ (?:minutes?|hours?))\b/gi,
    severity: "High",
    label: "Urgency Tactic"
  },
  
  // 2. SUSPICIOUS LINKS & SHORTENERS (ORANGE)
  {
    category: "suspicious_link",
    trickKey: "suspicious_link",
    regex: /(?:https?:\/\/)?(?:www\.)?(?:bit\.ly\/[a-zA-Z0-9_\-]+|tinyurl\.com\/[a-zA-Z0-9_\-]+|t\.co\/[a-zA-Z0-9_\-]+|is\.gd\/[a-zA-Z0-9_\-]+|cutt\.ly\/[a-zA-Z0-9_\-]+|rb\.gy\/[a-zA-Z0-9_\-]+|goo\.gl\/[a-zA-Z0-9_\-]+|t\.me\/[a-zA-Z0-9_\-]+|wa\.me\/[0-9]+|[a-zA-Z0-9\-]+(?:-update|-verify|-kyc|-support|-track|-portal|-bill|-pay|-reward|-court|-echallan|-login|-secure|-service)\.[a-zA-Z0-9\-.]+(?:\/[^\s]*)?|[a-zA-Z0-9\-.]+\.(?:top|cc|buzz|xyz|tk|cf|ga|ml|work|live|icu|vip|rest|app|online|site|club|space|fun|website|store|click|link)(?:\/[^\s]*)?|\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(?::\d+)?(?:\/[^\s]*)?|[a-zA-Z0-9\-.]+\.(?:apk|exe|bat|scr)\b)/gi,
    severity: "Critical",
    label: "Suspicious Link / Payload"
  },

  // 3. FAKE AUTHORITY CLAIMS (YELLOW)
  {
    category: "fake_authority",
    trickKey: "fake_authority",
    regex: /\b(Central Bureau of Investigation|CBI|Police|Delhi Police|Mumbai Police|Cyber Cell|Delhi Cyber Cell|Crime Branch|CID|Enforcement Directorate|ED|Income Tax|Customs|Narcotics|NCB|Interpol|Telecom Regulatory Authority of India|TRAI|DoT|Department of Telecom|Sanchar Saathi|State Bank of India|SBI|YONO|HDFC|HDFC Bank|ICICI|ICICI Bank|Axis Bank|Punjab National Bank|PNB|Kotak|Paytm|PhonePe|Google Pay|India Post|Speed Post|Postal Department|Blue Dart|DTDC|FedEx|Electricity (?:Dept|Department|Office|Officer|Board)|Discom|Mahavitaran|MSEDCL|BSES|Tata Power|UPPCL|Virtual Court|Supreme Court|High Court|Inspector [A-Za-z\.]+|Mr\. [A-Za-z\.]+|Officer [A-Za-z\.]+|Manager [A-Za-z\.]+|HR Manager [A-Za-z\.]+|Reliance Jio|KBC Head Office|Customs Officer|Customer Care|Customer Support|Executive [A-Za-z\.]+)\b/gi,
    severity: "High",
    label: "Authority Impersonation"
  },

  // 4. FINANCIAL & CREDENTIAL TRAPS (PURPLE)
  {
    category: "financial_trap",
    trickKey: "financial_trap",
    regex: /\b(pay (?:₹|rs\.?|inr)?\s*[\d,]+|redelivery fee|token fee|clearance fee|processing fee|penalty fee|security deposit|refundable tax|₹25|₹10|₹50|₹100|₹12,500|₹32,000|(?:update|verify|submit|link)\s+(?:your\s+)?(?:pan|aadhaar|aadhar|kyc|bank account|card details|credentials)|pending kyc|kyc verification|kyc suspended|kyc update|pan link|aadhaar link|Aadhaar & PAN|PAN and Aadhaar|(?:enter|share|provide|send)\s+(?:your\s+)?(?:card number|cvv|otp|one time password|pin|password|6-digit otp)|refundable processing tax|prepaid merchant recharge|recharge task|deposit ₹[\d,]+)\b/gi,
    severity: "Critical",
    label: "Financial / Credential Trap"
  },

  // 5. INTIMIDATION & COERCION (BLUE)
  {
    category: "fear_intimidation",
    trickKey: "fear_intimidation",
    regex: /\b(DIGITAL ARREST|digital house arrest|criminal case|FIR #?\d+|non-bailable (?:court )?warrant|warrant of arrest|arrest warrant|money laundering|narcotics trafficking|illegal SIM cards?|contraband parcel|seized by customs|police investigation|surrender at court|court warrant issued|account has been blocked|account (?:is|will be) blocked|power will be disconnected|service will be stopped|permanently returned to sender)\b/gi,
    severity: "Critical",
    label: "Intimidation / Coercion"
  },

  // 6. GREED BAIT & EASY MONEY (EMERALD)
  {
    category: "greed_bait",
    trickKey: "greed_bait",
    regex: /\b(Earn (?:₹|rs\.?|inr)?\s*[\d,]+(?:\s*to\s*(?:₹|rs\.?|inr)?\s*[\d,]+)?\s*(?:daily|per day|monthly)?|won (?:₹|rs\.?|inr)?\s*[\d,]+|\d+\s*(?:lakh|crore)s? Rupees|Lucky Draw|₹500 joining bonus|welcome bonus|free gift card|part-time job|work from home|liking (?:youtube )?videos|rating (?:hotels|google maps)|No investment required|accumulated Credit Card Reward Points|cash prize|claim your lottery)\b/gi,
    severity: "High",
    label: "Greed / Task Bait"
  }
];

// Helper to extract clean URLs from raw text
export function extractUrlsFromText(text) {
  if (!text) return [];
  const urlRegex = /(?:https?:\/\/)?(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?::\d+)?(?:\/[^\s)]*)?/gi;
  const matches = text.match(urlRegex) || [];
  
  return matches.map(url => {
    let clean = url.trim().replace(/[.,;:)\]]+$/, '');
    if (!clean.startsWith('http://') && !clean.startsWith('https://')) {
      clean = 'https://' + clean;
    }
    return clean;
  }).filter(url => {
    try {
      const parsed = new URL(url);
      return parsed.hostname.includes('.') && parsed.hostname.length > 3;
    } catch {
      return false;
    }
  });
}

// Extract phone numbers from text
export function extractPhonesFromText(text) {
  if (!text) return [];
  const phoneRegex = /(?:\+?\d{1,3}[-.\s]?)?\(?\d{3,4}\)?[-.\s]?\d{3}[-.\s]?\d{4}|\b[6-9]\d{9}\b|\+[0-9]{10,14}/g;
  const matches = text.match(phoneRegex) || [];
  return [...new Set(matches.map(p => p.trim()))];
}
