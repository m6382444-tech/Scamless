import React, { useState, useEffect, useRef } from 'react';
import { 
  MessageSquare, Share2, Copy, Check, ShieldAlert, ShieldCheck, AlertTriangle, 
  Upload, Camera, Sparkles, ExternalLink, RefreshCw, PhoneCall, Globe, CheckCircle2,
  AlertOctagon, UserX, Info, Send, Paperclip, Image as ImageIcon, Trash2, Plus,
  Maximize2, X, Eye, ArrowRight, CornerDownRight, CheckCheck, MapPin, Navigation,
  Compass, Radio, Crosshair, Phone, Shield
} from 'lucide-react';
import { WHATSAPP_SCAMS, DEMO_IMAGES } from '../data/whatsappScams';
import { evaluatePhoneNumber } from '../data/scamNumbers';
import { analyzeMessageNLP } from '../services/nlpEngine';
import { extractTextFromImage } from '../services/ocrService';
import VoiceAlertBar from './VoiceAlertBar';

export default function WhatsAppVerifier({
  onNavigateToSandbox,
  onNavigateToCallGuardian,
  onNavigateToEmergency
}) {
  // BY DEFAULT: Keep Live Interactive User Mode ON (Empty / Clean Slate, Not Demo Mode)
  const [activeScamPresetId, setActiveScamPresetId] = useState('custom');
  const [senderName, setSenderName] = useState('');
  const [senderPhone, setSenderPhone] = useState('');
  
  // Conversation thread state (Array of message objects) - Starts empty for user
  const [messages, setMessages] = useState([]);
  const [selectedMessageId, setSelectedMessageId] = useState(null);

  // New message composition state
  const [inputText, setInputText] = useState('');
  const [inputSenderType, setInputSenderType] = useState('contact'); // 'contact' (incoming) or 'me' (outgoing)
  const [inputIsForwarded, setInputIsForwarded] = useState(false);
  const [pendingImage, setPendingImage] = useState(null); // { url, file, name, size }

  // Phone Intelligence & GPS state
  const [phoneIntelligence, setPhoneIntelligence] = useState(null);
  const [isPhoneModalOpen, setIsPhoneModalOpen] = useState(false);
  const [customPhoneInput, setCustomPhoneInput] = useState('');

  // OCR Loading state
  const [ocrLoading, setOcrLoading] = useState(false);
  const [ocrProgress, setOcrProgress] = useState(0);
  const [ocrError, setOcrError] = useState(null);

  // Full-screen image preview lightbox
  const [lightboxImage, setLightboxImage] = useState(null);

  // Drag and drop state
  const [isDragOver, setIsDragOver] = useState(false);

  // Copy states
  const [copiedShareLink, setCopiedShareLink] = useState(false);
  const [copiedShareText, setCopiedShareText] = useState(false);
  const [copiedGps, setCopiedGps] = useState(false);

  // Refs
  const fileInputRef = useRef(null);
  const chatBottomRef = useRef(null);

  // Active public URL for share-to-scan
  const publicBaseUrl = "https://earning-increasing-tmp-trek.trycloudflare.com";

  // Re-evaluate GPS and Caller Name whenever senderPhone changes
  useEffect(() => {
    if (senderPhone && senderPhone.trim().length >= 5) {
      const intel = evaluatePhoneNumber(senderPhone);
      setPhoneIntelligence(intel);
      if (!senderName || senderName === 'Suspicious Unknown Contact') {
        if (intel && intel.callerName) {
          setSenderName(intel.callerName);
        }
      }
    } else {
      setPhoneIntelligence(null);
    }
  }, [senderPhone]);

  // Auto-scroll chat when messages change
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length]);

  // Combine all incoming messages text to compute overall conversation threat score
  const fullConversationText = messages
    .filter(m => m.sender === 'contact')
    .map(m => m.text)
    .join('\n\n');

  const overallAnalysis = analyzeMessageNLP(fullConversationText || inputText || 'Hello');

  const isScamVerdict = overallAnalysis.threatScore >= 40 || (phoneIntelligence?.riskScore >= 40);

  // Handle Preset Selection (Optional Demo Mode)
  const handleSelectPreset = (scam) => {
    setActiveScamPresetId(scam.id);
    setSenderName(scam.senderName);
    setSenderPhone(scam.senderPhone);
    setMessages(scam.messages);
    setSelectedMessageId(scam.messages[0]?.id || null);
    setInputText('');
    setPendingImage(null);
    setOcrError(null);
  };

  // Reset to Blank Interactive Custom Mode
  const handleStartBlankChat = () => {
    setActiveScamPresetId('custom');
    setSenderName('');
    setSenderPhone('');
    setMessages([]);
    setSelectedMessageId(null);
    setInputText('');
    setPendingImage(null);
    setOcrError(null);
    setPhoneIntelligence(null);
  };

  // Lookup custom phone number
  const handleLookupCustomPhone = (num) => {
    const target = num || customPhoneInput;
    if (!target) return;
    setSenderPhone(target);
    const intel = evaluatePhoneNumber(target);
    setPhoneIntelligence(intel);
    if (intel && intel.callerName) {
      setSenderName(intel.callerName);
    }
    setIsPhoneModalOpen(false);
  };

  // Process image file (from upload, drag-and-drop, or clipboard paste)
  const processImageFile = async (file) => {
    if (!file || !file.type.startsWith('image/')) {
      setOcrError("Please upload a valid image file (PNG, JPG, WEBP).");
      return;
    }

    setOcrLoading(true);
    setOcrProgress(15);
    setOcrError(null);

    const imageUrl = URL.createObjectURL(file);
    setPendingImage({
      url: imageUrl,
      name: file.name || 'Pasted_Screenshot.png',
      size: (file.size / 1024).toFixed(1) + ' KB'
    });

    try {
      const ocrResult = await extractTextFromImage(file, (progress) => {
        setOcrProgress(progress);
      });

      if (ocrResult?.success && ocrResult?.text) {
        setInputText(prev => prev ? `${prev}\n${ocrResult.text}` : ocrResult.text);
      } else {
        setInputText(prev => prev || "Extracted Screenshot (Inspect highlighted red flags)");
      }
    } catch (err) {
      console.warn("OCR extraction notice:", err);
      setOcrError("Image attached! You can add message text or click Send to inspect it.");
    } finally {
      setOcrLoading(false);
      setOcrProgress(0);
    }
  };

  // Handle file input change
  const handleFileInputChange = (e) => {
    const file = e.target.files?.[0];
    if (file) processImageFile(file);
  };

  // Handle clipboard paste (Ctrl+V) anywhere on the component
  const handlePaste = (e) => {
    const items = e.clipboardData?.items;
    if (!items) return;

    for (let i = 0; i < items.length; i++) {
      if (items[i].type.indexOf('image') !== -1) {
        const file = items[i].getAsFile();
        if (file) {
          processImageFile(file);
          e.preventDefault();
          break;
        }
      }
    }
  };

  // Handle drag and drop
  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) processImageFile(file);
  };

  // Send / Add message to conversation
  const handleSendMessage = () => {
    if (!inputText.trim() && !pendingImage) return;

    const messageText = inputText.trim() || (pendingImage ? `[Shared Image: ${pendingImage.name}]` : '');
    const newMsgId = `msg-${Date.now()}`;

    const newMsg = {
      id: newMsgId,
      sender: inputSenderType,
      senderName: inputSenderType === 'contact' ? (senderName || 'Contact') : 'You',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isForwarded: inputSenderType === 'contact' ? inputIsForwarded : false,
      text: messageText,
      image: pendingImage ? pendingImage.url : null,
      imageCaption: pendingImage ? pendingImage.name : null
    };

    setMessages(prev => [...prev, newMsg]);
    setSelectedMessageId(newMsgId);
    setInputText('');
    setPendingImage(null);
    setOcrError(null);
  };

  // Delete message
  const handleDeleteMessage = (id, e) => {
    e.stopPropagation();
    setMessages(prev => prev.filter(m => m.id !== id));
    if (selectedMessageId === id) {
      setSelectedMessageId(messages[0]?.id || null);
    }
  };

  // Copy GPS Coordinates
  const handleCopyGps = () => {
    if (!phoneIntelligence?.coordinates) return;
    const text = `${phoneIntelligence.coordinates.lat}, ${phoneIntelligence.coordinates.lng}`;
    navigator.clipboard.writeText(text);
    setCopiedGps(true);
    setTimeout(() => setCopiedGps(false), 2000);
  };

  // Generate WhatsApp Share URL & direct Share-to-Scan Link
  const shareToScanUrl = `${publicBaseUrl}/?scan=${encodeURIComponent(fullConversationText.slice(0, 300) || inputText)}&tab=whatsapp`;

  const whatsappShareMessage = isScamVerdict
    ? `🚨 *SCAMLENS FRAUD ALERT!* 🚨\n\n⚠️ *Checked on ScamLens:*\nSender: ${senderName || 'Unknown'} (${senderPhone || 'No Number'})\nGPS: ${phoneIntelligence?.location || 'Unknown'}\n"${(fullConversationText || inputText).slice(0, 100)}..."\n\n🛑 *Verdict:* DANGEROUS SCAM (${overallAnalysis.threatScore}/100)\n🔊 *Voice Audio Verdict:* Verified threat trap. Do not pay or share OTP!\n\n🛡️ *Verify any suspicious message or number for free:*\n👉 ${shareToScanUrl}`
    : `✅ *SCAMLENS VERIFICATION PASSED* ✅\n\n💬 *Sender:* ${senderName || 'Contact'}\n"${(fullConversationText || inputText).slice(0, 100)}..."\n\n🟢 *Verdict:* SAFE (Threat Score: ${overallAnalysis.threatScore}/100)\n🔊 *Safe to proceed with contact.*\n\nScan any message free:\n👉 ${shareToScanUrl}`;

  const handleShareToWhatsApp = () => {
    const targetUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(whatsappShareMessage)}`;
    window.open(targetUrl, '_blank');
  };

  const handleCopyShareLink = () => {
    navigator.clipboard.writeText(shareToScanUrl);
    setCopiedShareLink(true);
    setTimeout(() => setCopiedShareLink(false), 2000);
  };

  const handleCopyShareText = () => {
    navigator.clipboard.writeText(whatsappShareMessage);
    setCopiedShareText(true);
    setTimeout(() => setCopiedShareText(false), 2000);
  };

  return (
    <div 
      className="space-y-6 max-w-6xl mx-auto pb-16 font-sans text-slate-100"
      onPaste={handlePaste}
    >
      
      {/* Top Banner: Easy 3-Step Guide for Everyday Users */}
      <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-emerald-950/80 via-slate-900 to-teal-950/50 border border-emerald-500/40 shadow-xl space-y-3">
        
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <span className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-sm">
                <MessageSquare className="w-5 h-5" />
              </span>
              <h2 className="text-lg sm:text-xl font-extrabold text-white tracking-tight">
                WhatsApp Scam Radar & Caller GPS Detector
              </h2>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-black uppercase tracking-wider">
                LIVE INTERACTIVE MODE
              </span>
            </div>
            <p className="text-xs sm:text-[13px] text-slate-300">
              Type or paste any message, upload a screenshot, or enter a phone number to instantly see the sender's <strong>registered name, GPS location, and fraud threat score</strong>.
            </p>
          </div>

          {/* Quick Share to WhatsApp CTA */}
          <button
            onClick={handleShareToWhatsApp}
            className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-950/50 flex items-center justify-center space-x-2 transition-all transform active:scale-95 shrink-0"
            title="Open WhatsApp to share alert"
          >
            <Share2 className="w-4 h-4" />
            <span>Share Alert to WhatsApp</span>
          </button>
        </div>

        {/* 3 Simple Action Badges (for non-tech users) */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2 border-t border-slate-800/80 text-xs">
          <div className="flex items-center space-x-2 bg-slate-950/60 p-2 rounded-xl border border-slate-800">
            <span className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center text-xs shrink-0">1</span>
            <span className="text-slate-300 text-[11px]"><strong>Type or Paste:</strong> Add message or screenshot</span>
          </div>
          <div className="flex items-center space-x-2 bg-slate-950/60 p-2 rounded-xl border border-slate-800">
            <span className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 font-bold flex items-center justify-center text-xs shrink-0">2</span>
            <span className="text-slate-300 text-[11px]"><strong>GPS & Name:</strong> Enter phone to trace location</span>
          </div>
          <div className="flex items-center space-x-2 bg-slate-950/60 p-2 rounded-xl border border-slate-800">
            <span className="w-6 h-6 rounded-lg bg-rose-500/20 text-rose-400 font-bold flex items-center justify-center text-xs shrink-0">3</span>
            <span className="text-slate-300 text-[11px]"><strong>Voice Verdict:</strong> Listen in your native language</span>
          </div>
        </div>

      </div>

      {/* Multilingual Voice Alert Bar */}
      <VoiceAlertBar 
        isScam={isScamVerdict} 
        threatScore={overallAnalysis.threatScore}
        autoPlay={false}
      />

      {/* Quick Demo Models Toggle Bar (Clean & Collapsible) */}
      <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex items-center space-x-2">
          <span className="text-slate-400 font-semibold flex items-center space-x-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Need an example?</span>
          </span>
          <div className="flex flex-wrap gap-1.5">
            {WHATSAPP_SCAMS.slice(0, 4).map((scam) => (
              <button
                key={scam.id}
                onClick={() => handleSelectPreset(scam)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold border transition-all ${
                  activeScamPresetId === scam.id
                    ? 'bg-rose-600/30 text-rose-300 border-rose-500/60 shadow'
                    : 'bg-slate-950 text-slate-400 hover:text-white border-slate-800'
                }`}
              >
                <span>{scam.isScam ? '🔴' : '🟢'}</span> {scam.title.split(' ')[0]} {scam.title.split(' ')[1]}
              </button>
            ))}
          </div>
        </div>

        {/* Clear / Reset to Clean Interactive Mode */}
        <button
          onClick={handleStartBlankChat}
          className="px-3 py-1 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 text-[11px] font-bold flex items-center space-x-1.5 transition-colors"
          title="Start fresh interactive chat"
        >
          <Plus className="w-3 h-3" />
          <span>Clear / New Custom Chat</span>
        </button>
      </div>

      {/* Main Grid: Interactive WhatsApp Studio (7 cols) + GPS & Threat Radar (5 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: Interactive WhatsApp Chat Studio (7 cols) */}
        <div 
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={`lg:col-span-7 bg-[#0b141a] rounded-2xl border transition-all shadow-2xl overflow-hidden flex flex-col ${
            isDragOver 
              ? 'border-emerald-400 ring-2 ring-emerald-400/50' 
              : 'border-slate-800'
          }`}
        >
          
          {/* WhatsApp Header: Contact Details & Inline Editable Profile */}
          <div className="bg-[#1f2c34] px-4 py-3 border-b border-slate-800 flex items-center justify-between text-white">
            
            <div className="flex items-center space-x-3 min-w-0 flex-1 mr-2">
              <div className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-sm text-emerald-400 shrink-0 shadow">
                {(senderName && senderName.charAt(0)) || '?'}
              </div>
              
              <div className="min-w-0 flex-1">
                {/* Editable Contact Name */}
                <input
                  type="text"
                  value={senderName}
                  onChange={(e) => setSenderName(e.target.value)}
                  placeholder="Enter Contact / Person Name..."
                  className="font-bold text-sm text-slate-100 bg-transparent border-b border-transparent hover:border-slate-600 focus:border-emerald-500 focus:outline-none truncate w-full max-w-[240px] placeholder-slate-500"
                  title="Click to edit contact name"
                />

                {/* Editable Phone Number + GPS Indicator */}
                <div className="flex items-center space-x-2 text-[11px] text-slate-400 font-mono">
                  <input
                    type="text"
                    value={senderPhone}
                    onChange={(e) => setSenderPhone(e.target.value)}
                    placeholder="Enter phone: +91 98765..."
                    className="bg-transparent text-emerald-400 hover:text-emerald-300 border-b border-transparent hover:border-slate-600 focus:border-emerald-500 focus:outline-none w-40 truncate placeholder-slate-500 font-bold"
                    title="Click to edit contact phone number"
                  />
                  {phoneIntelligence?.location && (
                    <span className="text-[10px] text-slate-400 truncate flex items-center space-x-1">
                      <MapPin className="w-2.5 h-2.5 text-rose-400 shrink-0" />
                      <span className="truncate">{phoneIntelligence.location.split(',')[0]}</span>
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Quick Actions in WhatsApp Header */}
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setIsPhoneModalOpen(true)}
                className="px-2.5 py-1 rounded-lg bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-300 text-xs font-semibold border border-emerald-500/40 flex items-center space-x-1.5 transition-colors"
                title="Lookup Caller Identity & GPS"
              >
                <Compass className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Trace GPS</span>
              </button>

              <button
                onClick={() => setMessages([])}
                className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                title="Clear chat messages"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>

          </div>

          {/* WhatsApp Chat Canvas */}
          <div className="p-3 sm:p-4 bg-[#0b141a] min-h-[340px] max-h-[460px] overflow-y-auto space-y-3.5 relative scrollbar-thin scrollbar-thumb-slate-800">
            
            {/* Background subtle doodle texture */}
            <div className="absolute inset-0 opacity-5 pointer-events-none bg-[radial-gradient(#25d366_1px,transparent_1px)] [background-size:16px_16px]"></div>

            {/* Empty Chat State (Clean Interactive Prompt) */}
            {messages.length === 0 && (
              <div className="flex flex-col items-center justify-center h-60 text-center p-6 space-y-3 text-slate-400">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shadow-md">
                  <MessageSquare className="w-6 h-6 animate-pulse" />
                </div>
                <div className="space-y-1">
                  <h4 className="text-sm font-bold text-white">Your WhatsApp Radar is Ready</h4>
                  <p className="text-xs text-slate-300 max-w-sm leading-relaxed">
                    Type a message below, paste a suspicious chat, or upload a screenshot (or press <kbd className="px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-[10px] font-mono">Ctrl+V</kbd>) to start verifying.
                  </p>
                </div>
                <div className="flex flex-wrap items-center justify-center gap-2 pt-1 text-[11px]">
                  <span className="px-2.5 py-1 rounded-full bg-slate-900 border border-slate-800 text-slate-400">
                    📸 Upload Screenshots
                  </span>
                  <span className="px-2.5 py-1 rounded-full bg-slate-900 border border-slate-800 text-slate-400">
                    🛰️ Trace Caller GPS
                  </span>
                  <span className="px-2.5 py-1 rounded-full bg-slate-900 border border-slate-800 text-slate-400">
                    🔊 Multilingual Audio
                  </span>
                </div>
              </div>
            )}

            {/* Render Conversation Messages */}
            {messages.map((msg) => {
              const isContact = msg.sender === 'contact';
              const isSelected = selectedMessageId === msg.id;
              const msgAnalysis = isContact ? analyzeMessageNLP(msg.text) : null;
              const hasScamTrigger = msgAnalysis && msgAnalysis.threatScore >= 40;

              return (
                <div
                  key={msg.id}
                  onClick={() => setSelectedMessageId(msg.id)}
                  className={`flex flex-col group cursor-pointer transition-all ${
                    isContact ? 'items-start' : 'items-end'
                  }`}
                >
                  
                  {/* Message Bubble */}
                  <div className={`relative max-w-[90%] sm:max-w-[82%] rounded-2xl p-3 sm:p-3.5 shadow-md border transition-all ${
                    isContact
                      ? isSelected
                        ? 'bg-[#1f2c34] border-emerald-500 ring-2 ring-emerald-500/30 rounded-tl-sm text-slate-100'
                        : 'bg-[#1f2c34] border-slate-750 hover:border-slate-600 rounded-tl-sm text-slate-100'
                      : 'bg-[#005c4b] border-[#02735e] rounded-tr-sm text-white'
                  }`}>
                    
                    {/* Forwarded Header */}
                    {msg.isForwarded && (
                      <div className="flex items-center space-x-1 text-slate-400 text-[10px] italic border-b border-slate-700/50 pb-1 mb-1.5">
                        <Share2 className="w-3 h-3 text-slate-400 rotate-180" />
                        <span>Forwarded many times</span>
                      </div>
                    )}

                    {/* Sender Label for Incoming */}
                    {isContact && (
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="text-[11px] font-bold text-emerald-400 truncate">
                          {msg.senderName || senderName || 'Unknown Contact'}
                        </span>
                        
                        {/* Threat Indicator Chip */}
                        {hasScamTrigger ? (
                          <span className="px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-400 border border-rose-500/40 text-[9px] font-black uppercase tracking-wider shrink-0 flex items-center space-x-1">
                            <AlertOctagon className="w-2.5 h-2.5" />
                            <span>Scam: {msgAnalysis.threatScore}</span>
                          </span>
                        ) : (
                          <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[9px] font-bold uppercase tracking-wider shrink-0">
                            Safe
                          </span>
                        )}
                      </div>
                    )}

                    {/* Image Attachment (if message contains an image) */}
                    {msg.image && (
                      <div className="mb-2 rounded-xl overflow-hidden border border-slate-700/80 bg-black/40 relative group/img">
                        <img 
                          src={msg.image} 
                          alt="WhatsApp Attachment" 
                          className="w-full max-h-48 object-cover rounded-lg"
                        />
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setLightboxImage(msg.image);
                          }}
                          className="absolute bottom-2 right-2 p-1.5 rounded-lg bg-black/70 hover:bg-black text-white text-xs flex items-center space-x-1 transition-all opacity-90 hover:opacity-100"
                          title="View High-Resolution Image"
                        >
                          <Maximize2 className="w-3 h-3" />
                          <span className="text-[10px]">Zoom</span>
                        </button>
                      </div>
                    )}

                    {/* Message Text Content */}
                    <p className="text-xs sm:text-[13px] leading-relaxed whitespace-pre-wrap break-words font-sans">
                      {msg.text}
                    </p>

                    {/* Footer: Time & Status */}
                    <div className="flex items-center justify-end space-x-1.5 text-[10px] text-slate-400 pt-1 mt-0.5">
                      <span>{msg.time || '10:45 AM'}</span>
                      {isContact ? (
                        <span className="text-cyan-400 font-bold">✓✓</span>
                      ) : (
                        <CheckCheck className="w-3.5 h-3.5 text-cyan-300" />
                      )}
                      
                      {/* Delete Button */}
                      <button
                        onClick={(e) => handleDeleteMessage(msg.id, e)}
                        className="opacity-0 group-hover:opacity-100 p-0.5 rounded text-slate-500 hover:text-rose-400 transition-opacity ml-1"
                        title="Delete this message"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>

                  </div>

                </div>
              );
            })}

            <div ref={chatBottomRef} />
          </div>

          {/* Pending Image Upload Preview Bar */}
          {pendingImage && (
            <div className="p-2.5 bg-[#182229] border-t border-slate-800 flex items-center justify-between gap-3 text-xs">
              <div className="flex items-center space-x-2.5 min-w-0">
                <div className="w-10 h-10 rounded-lg overflow-hidden border border-slate-700 shrink-0 bg-black">
                  <img src={pendingImage.url} alt="Pending Preview" className="w-full h-full object-cover" />
                </div>
                <div className="min-w-0 text-[11px]">
                  <span className="text-emerald-400 font-semibold truncate block">{pendingImage.name}</span>
                  <span className="text-slate-400 text-[10px]">{pendingImage.size} • Ready to send</span>
                </div>
              </div>

              <div className="flex items-center space-x-2 shrink-0">
                {ocrLoading && (
                  <div className="flex items-center space-x-1.5 text-[10px] text-amber-300 font-semibold">
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>OCR ({ocrProgress}%)...</span>
                  </div>
                )}
                <button
                  onClick={() => setPendingImage(null)}
                  className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-700"
                  title="Remove image"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {ocrError && (
            <div className="px-3 py-1.5 bg-amber-950/60 border-t border-amber-500/30 text-[11px] text-amber-300 flex items-center space-x-1.5">
              <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
              <span>{ocrError}</span>
            </div>
          )}

          {/* Interactive WhatsApp Input Console */}
          <div className="bg-[#1f2c34] p-2.5 sm:p-3 border-t border-slate-800 space-y-2">
            
            {/* Input Controls Bar (Sender toggle & Forwarded tag) */}
            <div className="flex items-center justify-between text-xs px-1">
              
              {/* Sender Role Switcher */}
              <div className="flex items-center space-x-1.5">
                <span className="text-[11px] text-slate-400 font-semibold">Message as:</span>
                <button
                  type="button"
                  onClick={() => setInputSenderType('contact')}
                  className={`px-2 py-0.5 rounded-md text-[11px] font-bold transition-all ${
                    inputSenderType === 'contact'
                      ? 'bg-rose-600/30 text-rose-300 border border-rose-500/50'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  🔴 Incoming (Contact)
                </button>
                <button
                  type="button"
                  onClick={() => setInputSenderType('me')}
                  className={`px-2 py-0.5 rounded-md text-[11px] font-bold transition-all ${
                    inputSenderType === 'me'
                      ? 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/50'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  🟢 Outgoing (Me)
                </button>
              </div>

              {/* Forwarded Tag Checkbox */}
              {inputSenderType === 'contact' && (
                <label className="flex items-center space-x-1.5 text-[11px] text-slate-400 hover:text-slate-200 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={inputIsForwarded}
                    onChange={(e) => setInputIsForwarded(e.target.checked)}
                    className="rounded bg-slate-900 border-slate-700 text-emerald-500 focus:ring-0 cursor-pointer"
                  />
                  <span>Mark Forwarded</span>
                </label>
              )}

            </div>

            {/* Text Input Row with Attach & Send Buttons */}
            <div className="flex items-center gap-2">
              
              {/* File Attachment Button */}
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={ocrLoading}
                className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors shrink-0"
                title="Upload Chat Screenshot or Image to Scan"
              >
                <Paperclip className="w-4 h-4" />
              </button>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileInputChange}
                className="hidden"
              />

              {/* Text Input */}
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                placeholder={
                  pendingImage 
                    ? "Add a note to this screenshot and press Enter..." 
                    : "Type or paste a WhatsApp chat message (press Enter to send)..."
                }
                className="flex-1 bg-[#111b21] rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-slate-100 placeholder-slate-500 border border-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />

              {/* Send Button */}
              <button
                type="button"
                onClick={handleSendMessage}
                disabled={!inputText.trim() && !pendingImage}
                className="p-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-bold transition-all shrink-0 shadow-lg shadow-emerald-950/40"
                title="Add message to chat"
              >
                <Send className="w-4 h-4" />
              </button>

            </div>

          </div>

        </div>

        {/* Right Column: GPS Location Radar & Threat Inspector (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          
          {/* CALLER IDENTITY & GPS LOCATION RADAR CARD */}
          <div className="p-4 sm:p-5 rounded-2xl bg-slate-900 border border-indigo-500/40 shadow-xl space-y-3.5 relative overflow-hidden">
            
            {/* Top Header of GPS Card */}
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <span className="p-1.5 rounded-lg bg-indigo-500/20 text-indigo-400 border border-indigo-500/40">
                  <Navigation className="w-4 h-4 animate-spin-slow" />
                </span>
                <h4 className="text-xs font-bold uppercase tracking-wider text-white">
                  Caller GPS & Identity Radar
                </h4>
              </div>

              {phoneIntelligence ? (
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-black border uppercase ${
                  phoneIntelligence.isScam 
                    ? 'bg-rose-500/20 text-rose-400 border-rose-500/40' 
                    : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                }`}>
                  {phoneIntelligence.threatLevel}
                </span>
              ) : (
                <span className="text-[10px] text-slate-400">Waiting for Number</span>
              )}
            </div>

            {/* Quick Phone Number Input */}
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Phone className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
                <input
                  type="text"
                  value={senderPhone}
                  onChange={(e) => setSenderPhone(e.target.value)}
                  placeholder="Enter caller phone number (+91 / +92)..."
                  className="w-full bg-slate-950 rounded-xl pl-9 pr-3 py-2 text-xs font-mono text-slate-100 placeholder-slate-500 border border-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-semibold"
                />
              </div>
            </div>

            {/* Live GPS Radar Display */}
            {phoneIntelligence ? (
              <div className="space-y-3 pt-1">
                
                {/* Registered Name & Telecom Circle */}
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400 text-[11px] font-medium">Identified Person / Entity:</span>
                    <span className="text-[10px] text-slate-500 font-mono">{phoneIntelligence.carrier}</span>
                  </div>
                  <h5 className="font-extrabold text-sm text-indigo-300 truncate">
                    {phoneIntelligence.callerName}
                  </h5>
                  <p className="text-[11px] text-slate-400 flex items-center space-x-1.5">
                    <MapPin className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                    <span><strong>Location:</strong> {phoneIntelligence.location}</span>
                  </p>
                </div>

                {/* Simulated Mini Satellite GPS Map View */}
                <div className="relative h-28 rounded-xl overflow-hidden border border-indigo-500/30 bg-slate-950 flex flex-col justify-between p-3">
                  
                  {/* Subtle Grid and Radar sweep animation */}
                  <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#6366f1_1px,transparent_1px)] [background-size:12px_12px]"></div>
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent"></div>

                  <div className="relative z-10 flex items-center justify-between text-[10px] text-indigo-300 font-mono">
                    <span className="flex items-center space-x-1">
                      <Radio className="w-3 h-3 text-emerald-400 animate-pulse" />
                      <span>GPS BEACON ACTIVE</span>
                    </span>
                    <span className="text-slate-400">Telecom Circle: {phoneIntelligence.circle}</span>
                  </div>

                  {/* Pulsing Target Coordinates in Center */}
                  <div className="relative z-10 flex items-center justify-center space-x-2 my-auto">
                    <Crosshair className="w-6 h-6 text-rose-500 animate-ping" />
                    <div className="text-center font-mono">
                      <span className="text-xs font-black text-white block">
                        {phoneIntelligence.coordinates.lat.toFixed(4)}° N, {phoneIntelligence.coordinates.lng.toFixed(4)}° E
                      </span>
                      <span className="text-[10px] text-indigo-400 font-semibold">
                        Geolocated via Telecom Tower Gateway
                      </span>
                    </div>
                  </div>

                  {/* Copy GPS Coordinates CTA */}
                  <div className="relative z-10 flex items-center justify-between text-[10px] pt-1">
                    <span className="text-slate-400 font-mono">Precision: ~5 km radius</span>
                    <button
                      onClick={handleCopyGps}
                      className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-indigo-300 text-[10px] font-semibold flex items-center space-x-1 transition-colors"
                    >
                      {copiedGps ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>Copy Coordinates</span>
                    </button>
                  </div>

                </div>

              </div>
            ) : (
              <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 text-center py-4 space-y-1">
                <MapPin className="w-5 h-5 text-slate-500 mx-auto" />
                <p className="text-xs font-semibold text-slate-300">Enter Phone Number to Reveal GPS Location</p>
                <p className="text-[11px] text-slate-500">
                  ScamLens identifies the registered subscriber name, carrier operator, state circle, and satellite coordinates.
                </p>
              </div>
            )}

          </div>

          {/* Threat Score & Plain English Verdict Card */}
          <div className={`p-4 sm:p-5 rounded-2xl border shadow-xl ${
            isScamVerdict 
              ? 'bg-slate-900 border-rose-500/40 shadow-rose-950/20' 
              : 'bg-slate-900 border-emerald-500/40 shadow-emerald-950/20'
          }`}>
            
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Threat Verdict
              </span>
              <span className={`text-xs font-black px-2.5 py-1 rounded-full border ${
                isScamVerdict 
                  ? 'bg-rose-500/20 text-rose-400 border-rose-500/40' 
                  : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
              }`}>
                {isScamVerdict ? 'CRITICAL SCAM DETECTED' : 'SAFE / NO TRICKS DETECTED'}
              </span>
            </div>

            <div className="flex items-baseline space-x-2 mb-2">
              <span className={`text-4xl font-extrabold tracking-tight ${
                isScamVerdict ? 'text-rose-500' : 'text-emerald-400'
              }`}>
                {overallAnalysis.threatScore}
              </span>
              <span className="text-sm font-semibold text-slate-500">/ 100 Threat Index</span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed mb-3">
              {isScamVerdict
                ? `ScamLens analyzed your input and detected manipulative psychological red flags. Do not click links, send money, or share OTPs.`
                : `All clear! No coercive urgency, extortion, fake lottery, or malicious links detected in this chat.`}
            </p>

            {/* Identified Red Flags List */}
            <div className="space-y-2 mt-3 pt-3 border-t border-slate-800 text-xs">
              <span className="font-semibold text-slate-300 block">Plain-English Red Flag Analysis:</span>
              
              {(overallAnalysis.highlights && overallAnalysis.highlights.length > 0) ? (
                <div className="space-y-1.5 max-h-44 overflow-y-auto pr-1 scrollbar-thin">
                  {overallAnalysis.highlights.map((trig, idx) => (
                    <div key={idx} className="p-2 rounded-lg bg-slate-950/80 border border-slate-800 flex items-start space-x-2">
                      <AlertOctagon className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold text-rose-300 block text-[11px]">{trig.categoryLabel || trig.category} Trap</span>
                        <span className="text-[11px] text-slate-300 font-mono">"{trig.text}"</span>
                        {trig.explanation && (
                          <p className="text-[10px] text-slate-400 mt-0.5">{trig.explanation}</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-[11px] text-slate-400 italic">
                  Clean message content. No manipulative triggers identified.
                </p>
              )}
            </div>

            {/* Emergency Dial 1930 Helpline CTA */}
            {isScamVerdict && (
              <div className="mt-3 pt-3 border-t border-slate-800 flex items-center justify-between">
                <span className="text-[11px] text-slate-400">Need immediate police helpline?</span>
                <a
                  href="tel:1930"
                  className="px-3 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center space-x-1.5 shadow"
                >
                  <PhoneCall className="w-3 h-3" />
                  <span>Call 1930 Helpline</span>
                </a>
              </div>
            )}

          </div>

          {/* Share-to-Scan Link Card */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
            <div className="flex items-center space-x-2 text-slate-200">
              <Share2 className="w-4 h-4 text-emerald-400" />
              <h4 className="text-xs font-bold uppercase tracking-wider">
                WhatsApp "Share to Scan" Link
              </h4>
            </div>

            <p className="text-[11px] text-slate-300 leading-relaxed">
              Send this link to friends or family. When clicked, it opens ScamLens, loads this exact chat, and plays the voice alert!
            </p>

            <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2 font-mono text-[11px]">
              <div className="flex items-center justify-between text-emerald-300 truncate">
                <span className="truncate pr-2">{shareToScanUrl}</span>
                <button
                  onClick={handleCopyShareLink}
                  className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors shrink-0"
                  title="Copy Link"
                >
                  {copiedShareLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>

              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
                <button
                  onClick={handleCopyShareText}
                  className="w-full py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center space-x-1.5 transition-colors"
                >
                  {copiedShareText ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>Copy Complete Fraud Warning Message</span>
                </button>
              </div>
            </div>

            <button
              onClick={handleShareToWhatsApp}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 font-bold text-xs text-white shadow-lg flex items-center justify-center space-x-2 transition-all transform active:scale-95"
            >
              <MessageSquare className="w-4 h-4 fill-current" />
              <span>Forward Alert to WhatsApp Contact / Group</span>
            </button>
          </div>

        </div>

      </div>

      {/* Lightbox Modal for Full-Screen Image Viewing */}
      {lightboxImage && (
        <div 
          onClick={() => setLightboxImage(null)}
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in"
        >
          <div 
            onClick={(e) => e.stopPropagation()}
            className="relative max-w-2xl max-h-[85vh] bg-slate-900 rounded-2xl border border-slate-700 overflow-hidden shadow-2xl"
          >
            <div className="p-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between text-xs text-slate-300">
              <span className="font-bold flex items-center space-x-1.5">
                <Eye className="w-3.5 h-3.5 text-emerald-400" />
                <span>Full Screenshot & Document Inspector</span>
              </span>
              <button
                onClick={() => setLightboxImage(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-3 overflow-auto max-h-[75vh]">
              <img src={lightboxImage} alt="Expanded Screenshot" className="max-w-full rounded-lg object-contain mx-auto" />
            </div>
          </div>
        </div>
      )}

      {/* Phone Number Lookup Dialog Modal */}
      {isPhoneModalOpen && (
        <div 
          onClick={() => setIsPhoneModalOpen(false)}
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in"
        >
          <div 
            onClick={(e) => e.stopPropagation()}
            className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center space-x-2">
                <Compass className="w-5 h-5 text-indigo-400" />
                <h4 className="text-base font-bold text-white">Trace Caller Identity & GPS</h4>
              </div>
              <button 
                onClick={() => setIsPhoneModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Enter any 10-digit mobile number or international phone with country code (e.g. <code>+91 98765 43210</code> or <code>+92 300 1234567</code>).
            </p>

            <div className="space-y-2">
              <input
                type="text"
                value={customPhoneInput}
                onChange={(e) => setCustomPhoneInput(e.target.value)}
                placeholder="e.g. +91 98765 43210"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm font-mono text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                autoFocus
              />
            </div>

            <div className="flex items-center justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setIsPhoneModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleLookupCustomPhone()}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center space-x-1.5 shadow-lg"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Lookup GPS Location</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
