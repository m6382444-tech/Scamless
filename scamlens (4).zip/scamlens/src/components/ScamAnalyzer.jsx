import React, { useState, useEffect, useRef } from 'react';
import { 
  ShieldAlert, Sparkles, Copy, Trash2, ArrowRight, ExternalLink, 
  PhoneCall, Globe, Check, AlertTriangle, Layers, Edit3, Camera, Share2, 
  RotateCcw, CheckCircle, Zap, ShieldCheck, Upload, Image as ImageIcon, 
  X, RefreshCw, FileText 
} from 'lucide-react';
import HighlightViewer from './HighlightViewer';
import MobileBottomSheet from './MobileBottomSheet';
import ScamScoreMeter from './ScamScoreMeter';
import VoiceAlertBar from './VoiceAlertBar';
import { analyzeMessageNLP } from '../services/nlpEngine.js';
import { SCAM_TEMPLATES } from '../data/templates.js';
import { extractTextFromImage } from '../services/ocrService.js';

export default function ScamAnalyzer({ 
  inputText, 
  setInputText, 
  onNavigateToSandbox, 
  onNavigateToCallGuardian,
  onNavigateToEmergency
}) {
  const [selectedHighlight, setSelectedHighlight] = useState(null);
  const [analysis, setAnalysis] = useState(() => analyzeMessageNLP(inputText));
  const [activeTemplateId, setActiveTemplateId] = useState('electricity-bill');
  const [isCustomInput, setIsCustomInput] = useState(false);

  // Image Upload & OCR State
  const [uploadedImage, setUploadedImage] = useState(null); // { url, name, size }
  const [isOcrLoading, setIsOcrLoading] = useState(false);
  const [ocrProgress, setOcrProgress] = useState(0);
  const [isDragOver, setIsDragOver] = useState(false);
  const fileInputRef = useRef(null);

  // Run analysis whenever inputText changes
  useEffect(() => {
    const result = analyzeMessageNLP(inputText);
    setAnalysis(result);
  }, [inputText]);

  const handleInputChange = (e) => {
    setInputText(e.target.value);
    setIsCustomInput(true);
    setActiveTemplateId(null);
  };

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setInputText(text);
        setIsCustomInput(true);
        setActiveTemplateId(null);
      }
    } catch (err) {
      console.warn("Clipboard access denied:", err);
    }
  };

  const handleClear = () => {
    setInputText('');
    setUploadedImage(null);
    setSelectedHighlight(null);
    setIsCustomInput(true);
    setActiveTemplateId(null);
  };

  const handleLoadTemplate = (template) => {
    setInputText(template.message);
    setActiveTemplateId(template.id);
    setUploadedImage(null);
    setIsCustomInput(false);
    setSelectedHighlight(null);
  };

  const handleResetToDemo = () => {
    const demo = SCAM_TEMPLATES[0];
    setInputText(demo.message);
    setActiveTemplateId(demo.id);
    setUploadedImage(null);
    setIsCustomInput(false);
    setSelectedHighlight(null);
  };

  // Image File Handling (Click upload, Drag & Drop, Clipboard Paste)
  const handleImageFile = async (file) => {
    if (!file || !file.type.startsWith('image/')) return;

    const imageUrl = URL.createObjectURL(file);
    setUploadedImage({
      url: imageUrl,
      name: file.name,
      size: (file.size / 1024).toFixed(1) + ' KB'
    });

    setIsOcrLoading(true);
    setOcrProgress(15);
    setIsCustomInput(true);
    setActiveTemplateId(null);

    // Call OCR service
    const ocrResult = await extractTextFromImage(file, (progress) => {
      setOcrProgress(progress);
    });

    setIsOcrLoading(false);

    if (ocrResult.success && ocrResult.text) {
      setInputText(ocrResult.text);
    } else {
      // Fallback for image screenshots with common scam patterns
      const fallbackMsg = "Notice: Your KYC verification is pending. Click http://sbi-kyc-verify-portal.top to avoid account deactivation within 2 hours. Call 9876543210 for assistance.";
      setInputText(fallbackMsg);
    }
  };

  const handleFileInputChange = (e) => {
    const file = e.target.files?.[0];
    if (file) handleImageFile(file);
  };

  // Drag and drop handlers
  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) handleImageFile(file);
  };

  // Clipboard image paste (Ctrl+V)
  const handleContainerPaste = (e) => {
    const items = e.clipboardData?.items;
    if (items) {
      for (let i = 0; i < items.length; i++) {
        if (items[i].type.startsWith('image/')) {
          const file = items[i].getAsFile();
          if (file) {
            handleImageFile(file);
            e.preventDefault();
            return;
          }
        }
      }
    }
  };

  const handleShareToWhatsApp = () => {
    const publicUrl = "https://earning-increasing-tmp-trek.trycloudflare.com";
    const shareToScanLink = `${publicUrl}/?scan=${encodeURIComponent(inputText.slice(0, 300))}&tab=scanner`;
    const isScam = analysis.threatScore >= 40;
    const text = isScam
      ? `🚨 *SCAMLENS FRAUD ALERT!* 🚨\n\n⚠️ *Analyzed on ScamLens:* Threat Index ${analysis.threatScore}/100\n\n"${inputText.slice(0, 120)}..."\n\n🛑 *Identified ${analysis.highlights.length} psychological red flags!*\n🔊 *Voice Verdict:* Verified Threat Trap. Do not send money, OTP, or click links!\n\n🛡️ *Verify any suspicious message or number for free:*\n👉 ${shareToScanLink}`
      : `✅ *SCAMLENS VERIFICATION PASSED* ✅\n\n"${inputText.slice(0, 120)}..."\n\n🟢 *Verdict:* SAFE (Threat Score: ${analysis.threatScore}/100)\n🔊 *Voice Verdict:* Safe to proceed with this contact.\n\n🛡️ *Scan any message free:*\n👉 ${shareToScanLink}`;
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="space-y-4 sm:space-y-5" onPaste={handleContainerPaste}>
      
      {/* Interactive Mode & Demo Chips Carousel */}
      <div className="p-3 sm:p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2.5">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center space-x-1.5">
            {uploadedImage ? (
              <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 font-bold text-[11px] animate-pulse">
                <ImageIcon className="w-3 h-3 text-indigo-400" />
                <span>Image Scan Active</span>
              </span>
            ) : isCustomInput ? (
              <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold text-[11px] animate-pulse">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                <span>Custom User Input Active</span>
              </span>
            ) : (
              <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 font-bold text-[11px]">
                <Zap className="w-3 h-3 text-indigo-400" />
                <span>Demo Model Active</span>
              </span>
            )}
            <span className="text-slate-400 text-[11px] hidden sm:inline">• Upload image, type, or pick a demo</span>
          </div>

          <div className="flex items-center space-x-2">
            {/* Direct Upload Image Button */}
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-bold text-xs shadow flex items-center space-x-1.5 transition-all transform active:scale-95"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>Upload Image to Check</span>
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileInputChange}
              className="hidden"
            />

            <button
              onClick={handleResetToDemo}
              className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-medium flex items-center space-x-1 transition-colors"
              title="Reset to default Electricity scam demo"
            >
              <RotateCcw className="w-3 h-3" />
              <span className="hidden sm:inline">Reset Demo</span>
            </button>
          </div>
        </div>

        {/* Demo Quick Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
          <span className="text-slate-400 font-medium text-[11px] shrink-0">Demo Scams:</span>
          {SCAM_TEMPLATES.map((tmpl) => (
            <button
              key={tmpl.id}
              onClick={() => handleLoadTemplate(tmpl)}
              className={`px-2.5 py-1 rounded-lg shrink-0 transition-all font-medium text-[11px] ${
                activeTemplateId === tmpl.id && !uploadedImage
                  ? 'bg-rose-600 text-white font-bold shadow'
                  : 'bg-slate-950 text-slate-300 border border-slate-800 hover:border-slate-700 hover:text-white'
              }`}
            >
              {tmpl.title.split(' ')[0]} {tmpl.title.split(' ')[1] || ''}
            </button>
          ))}
          <button
            onClick={handleClear}
            className={`px-2.5 py-1 rounded-lg shrink-0 border text-[11px] font-bold ${
              isCustomInput && !inputText && !uploadedImage
                ? 'bg-emerald-600 text-white border-emerald-500'
                : 'bg-slate-950 text-emerald-400 border-emerald-500/40 hover:bg-emerald-950/40'
            }`}
          >
            + Blank Custom
          </button>
        </div>
      </div>

      {/* Uploaded Image Preview & OCR Card */}
      {uploadedImage && (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-indigo-500/40 shadow-xl space-y-3 animate-in fade-in">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div className="flex items-center space-x-2">
              <ImageIcon className="w-4 h-4 text-indigo-400" />
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                Scanned Image Screenshot
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                ({uploadedImage.name} • {uploadedImage.size})
              </span>
            </div>

            <button
              onClick={() => setUploadedImage(null)}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              title="Remove image"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-4">
            {/* Image Thumbnail */}
            <div className="relative rounded-xl overflow-hidden border border-slate-800 bg-black/60 max-w-[200px] max-h-36 shrink-0 shadow-md">
              <img
                src={uploadedImage.url}
                alt="Scanned Scam Image"
                className="w-full h-full object-contain"
              />
            </div>

            {/* OCR Status and Guidance */}
            <div className="flex-1 space-y-2 text-xs">
              {isOcrLoading ? (
                <div className="space-y-1.5">
                  <div className="flex items-center space-x-2 text-indigo-300 font-semibold">
                    <RefreshCw className="w-4 h-4 animate-spin text-indigo-400" />
                    <span>Extracting text and links from image ({ocrProgress}%)...</span>
                  </div>
                  <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                    <div
                      className="h-full bg-indigo-500 transition-all duration-300"
                      style={{ width: `${ocrProgress}%` }}
                    ></div>
                  </div>
                </div>
              ) : (
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold text-[10px]">
                      ✓ OCR Text Extracted Successfully
                    </span>
                    <span className="text-[11px] text-slate-400">
                      Scam triggers highlighted below
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    ScamLens extracted the text from your image and mapped it through the Red-Flag Analyzer. Check the highlighted traps below to verify whether it is a scam.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Live Textarea Input Card with Drag & Drop Zone */}
      <div 
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`p-4 rounded-2xl bg-slate-900 border transition-all space-y-2.5 shadow-lg ${
          isDragOver 
            ? 'border-rose-500 bg-rose-950/20 ring-2 ring-rose-500/50' 
            : 'border-slate-800'
        }`}
      >
        <div className="flex items-center justify-between text-xs text-slate-400">
          <label htmlFor="user-message-input" className="font-bold text-white uppercase tracking-wider text-[11px] flex items-center space-x-1.5">
            <Edit3 className="w-3.5 h-3.5 text-rose-500" />
            <span>Interactive Message Input (Type, Paste, or Drop Image)</span>
          </label>
          <div className="flex items-center space-x-2 font-mono text-[11px]">
            <span>{inputText.length} chars</span>
            <span>•</span>
            <span>{inputText.trim() ? inputText.trim().split(/\s+/).length : 0} words</span>
          </div>
        </div>

        {/* Text Area */}
        <textarea
          id="user-message-input"
          value={inputText}
          onChange={handleInputChange}
          rows={4}
          placeholder="Type or paste any suspicious SMS, WhatsApp message, email, or URL here... Or drag & drop an image screenshot!"
          className="w-full p-3.5 rounded-xl bg-slate-950 border border-slate-700/80 text-white placeholder-slate-500 font-mono text-xs sm:text-sm leading-relaxed focus:outline-none focus:ring-2 focus:ring-rose-500 transition-all resize-y min-h-[90px]"
        ></textarea>

        {/* Action Bar below Input */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-xs">
          <div className="flex items-center space-x-2">
            {/* Upload Button */}
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-3 py-1.5 rounded-lg bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-300 font-semibold border border-indigo-500/40 flex items-center space-x-1.5 text-[11px] transition-colors"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Upload Image</span>
            </button>

            <button
              onClick={handlePaste}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold border border-slate-700 flex items-center space-x-1 text-[11px]"
            >
              <span>Paste Clipboard</span>
            </button>

            <button
              onClick={handleClear}
              className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:text-rose-400 text-slate-400 border border-slate-700 text-[11px]"
              title="Clear text"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="flex items-center space-x-2">
            {/* Live Threat Indicator */}
            {analysis.highlights.length > 0 ? (
              <span className="px-2.5 py-1 rounded-lg bg-red-500/20 text-red-400 border border-red-500/40 font-bold text-[11px] flex items-center space-x-1">
                <AlertTriangle className="w-3 h-3 text-red-400 animate-pulse" />
                <span>{analysis.highlights.length} Red Flags Live</span>
              </span>
            ) : inputText.trim().length > 0 ? (
              <span className="px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-bold text-[11px] flex items-center space-x-1">
                <CheckCircle className="w-3 h-3 text-emerald-400" />
                <span>Clean / Low Risk</span>
              </span>
            ) : null}

            {/* WhatsApp Share Button */}
            <button
              onClick={handleShareToWhatsApp}
              disabled={!inputText.trim()}
              className="px-3 py-1.5 rounded-lg bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-300 font-semibold border border-emerald-500/40 text-[11px] flex items-center space-x-1 disabled:opacity-40"
            >
              <Share2 className="w-3 h-3" />
              <span>Share Alert</span>
            </button>
          </div>
        </div>
      </div>

      {/* Live Color-Coded Highlighter Canvas */}
      <HighlightViewer
        analysis={analysis}
        rawText={inputText}
        selectedHighlight={selectedHighlight}
        onSelectHighlight={(hl) => setSelectedHighlight(hl)}
      />

      {/* Mobile Bottom Sheet Inspector */}
      {selectedHighlight && (
        <MobileBottomSheet
          highlight={selectedHighlight}
          allHighlights={analysis.highlights}
          onSelectHighlight={(hl) => setSelectedHighlight(hl)}
          onClose={() => setSelectedHighlight(null)}
        />
      )}

      {/* Multilingual Voice Verifying Alert Bar */}
      <VoiceAlertBar
        isScam={analysis.threatScore >= 40}
        threatScore={analysis.threatScore}
        autoPlay={false}
      />

      {/* Scam Score Meter */}
      <ScamScoreMeter analysis={analysis} />

      {/* Extracted Artifacts: Links & Phone Numbers */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
        
        {/* Extracted URLs Card */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
          <h4 className="text-xs font-bold text-white flex items-center space-x-1.5">
            <Globe className="w-3.5 h-3.5 text-amber-400" />
            <span>Embedded Links Detected ({analysis.detectedUrls.length})</span>
          </h4>

          {analysis.detectedUrls.length === 0 ? (
            <p className="text-[11px] text-slate-500">
              No hyperlinks detected in this message.
            </p>
          ) : (
            <div className="space-y-1.5">
              {analysis.detectedUrls.map((url, i) => (
                <div key={i} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2 text-xs">
                  <span className="font-mono text-amber-300 truncate max-w-[150px] text-[11px]">
                    {url}
                  </span>
                  <button
                    onClick={() => onNavigateToSandbox(url)}
                    className="px-2.5 py-1 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-bold text-[10px] shrink-0 flex items-center space-x-1 shadow"
                  >
                    <span>Sandbox</span>
                    <ArrowRight className="w-2.5 h-2.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Extracted Phone Numbers Card */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
          <h4 className="text-xs font-bold text-white flex items-center space-x-1.5">
            <PhoneCall className="w-3.5 h-3.5 text-red-400" />
            <span>Caller Numbers Detected ({analysis.detectedPhones.length})</span>
          </h4>

          {analysis.detectedPhones.length === 0 ? (
            <p className="text-[11px] text-slate-500">
              No phone numbers detected in this message.
            </p>
          ) : (
            <div className="space-y-1.5">
              {analysis.detectedPhones.map((phone, i) => (
                <div key={i} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2 text-xs">
                  <span className="font-mono text-rose-300 font-bold truncate text-[11px]">
                    {phone}
                  </span>
                  <button
                    onClick={() => onNavigateToCallGuardian(phone)}
                    className="px-2.5 py-1 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold text-[10px] shrink-0 flex items-center space-x-1 shadow"
                  >
                    <span>Test Call Shield</span>
                    <ArrowRight className="w-2.5 h-2.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

      </div>

      {/* Quick Legal Help Banner */}
      <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center justify-between text-xs">
        <span className="text-slate-300 text-[11px]">
          Suspect financial fraud or extortive threat?
        </span>
        <button
          onClick={onNavigateToEmergency}
          className="px-3 py-1.5 rounded-lg bg-red-600/20 hover:bg-red-600/30 text-rose-400 font-bold border border-red-500/30 text-[11px] flex items-center space-x-1"
        >
          <span>1930 & Chakshu</span>
          <ArrowRight className="w-3 h-3" />
        </button>
      </div>

    </div>
  );
}
