# ScamLens – Mobile Red-Flag Highlighter & Cyber Defense Shield

> **ScamLens** is an interactive, browser-based cyber defense web application designed to protect citizens against modern social engineering scams, smishing attacks, phishing URLs, UPI QR payment traps, and fraudulent incoming calls.

---

## 🌟 Core Modules & Capabilities

### 1. 🔍 NLP Red-Flag Highlighter & Psychological Deconstruction
* **6-Color Cognitive Trap Breakdown**:
  * 🔴 **Red**: Urgent Deadlines (*"Account blocked in 2 hours"*, *"power cut tonight at 9:30 PM"*)
  * 🟠 **Orange**: Suspicious Links (*bit.ly*, *.top*, *.buzz*, *.cc*, direct *.apk* downloads)
  * 🟡 **Yellow**: Fake Authority Claims (*"SBI YONO Admin"*, *"Electricity Officer"*, *"CBI Cyber Cell"*, *"India Post"*)
  * 🟣 **Purple**: Financial & Credential Traps (*₹25 redelivery fee*, *Aadhaar/PAN update*, *OTP demand*)
  * 🔵 **Blue**: Intimidation & Coercion (*"Digital Arrest"*, *FIR #492*, *non-bailable warrant*)
  * 🟢 **Green**: Greed & Task Baits (*"Earn ₹3,500-₹8,000 daily liking YouTube videos"*)
* **Interactive Bottom Sheet**: Tap any highlighted span to view psychological explanations, legitimate banking/institutional protocols, and safe alternative actions.

---

### 2. 🔊 Multilingual Voice Verifying Engine
* **Web Speech & Audio Synthesizer**: Automatically announces whether a message is an active fraud trap or safe to proceed.
* **Dual Voice Tones**:
  * **Shield Pro (Authoritative)**: Official law-enforcement alert explaining why you must not pay or share OTPs.
  * **Street Alert (Direct & Punchy)**: Colloquial, high-impact warning (*"Warning! This is a scam, you just got trapped if you believed this! Stop immediately..."*).
* **8 Indian & Regional Languages Supported**:
  * 🇮🇳 English (India/Global)
  * 🇮🇳 Hindi (हिंदी)
  * 🇮🇳 Hinglish (Colloquial Hindi-English mix)
  * 🇮🇳 Tamil (தமிழ்)
  * 🇮🇳 Telugu (తెలుగు)
  * 🇮🇳 Kannada (ಕನ್ನಡ)
  * 🇮🇳 Bengali (বাংলা)
  * 🇮🇳 Marathi (मराठी)
* **Audio Cues**: Dual-tone emergency siren on fraud detection and harmonic major chord on verified safe content.

---

### 3. 💬 WhatsApp Scam Studio & Share-to-Scan
* **Two-Way Chat Simulator**:
  * Role switcher: Type incoming messages from suspects (🔴 Incoming) or test your responses (🟢 Outgoing green bubbles).
  * "Mark Forwarded" toggle: Simulates WhatsApp's *Forwarded many times* viral trigger.
  * Inline editable contact header with country prefix risk badges (`+92` Pakistan, `+84` Vietnam, `+62` Indonesia, `+234` Nigeria).
* **Image & Screenshot Radar**:
  * 📎 Attachment upload, Drag-and-Drop, or Clipboard Paste (<kbd>Ctrl+V</kbd>).
  * Client-side OCR (`tesseract.js`) extracts text from screenshots of WhatsApp chats, fake warrants, or payment slips.
  * Full-Screen Lightbox Zoom for inspecting fine document details.
* **1-Click WhatsApp Share**:
  * Tap **"Share to WhatsApp"** to forward pre-formatted fraud alerts to family or group chats.
  * Generates **Share-to-Scan** links (`/?scan=...&tab=whatsapp`) that automatically load the text and trigger voice verification on other phones.

---

### 4. 📱 QR Code Verifier & UPI Payment Trap Shield
* **Camera Scanner & Image Upload**: Real-time camera video stream or image file QR decoding via `jsQR`.
* **UPI Reverse Collect Trap Detection**:
  * Inspects `upi://pay` URLs for the notorious "Scan to Receive Money" fraud.
  * Flags hidden debit parameters (`am`, `pa`, `pn`, `tn`) where a scammer claims you are receiving money but the QR actually debits your account.
* **Malicious URL & APK Detection**: Flags QR codes pointing to `.apk` downloads or typosquatted banking portals.

---

### 5. 📞 Call Guardian & Red Signal Radar
* **Phone Number Threat Intelligence**:
  * Direct lookup against reported cybercrime databases (Chakshu, 1930 Helpline).
  * Identifies VOIP virtual gateways and international extortion prefixes.
* **Incoming Call Simulator**:
  * Simulates mobile incoming calls with flashing **🔴 RED SIGNAL visual alarm** and audio buzzer.
  * Live call dialog with real-time speech transcript stream.

---

### 6. 🌐 URL Sandbox & Unshortener
* **SSRF-Protected Redirect Tracker**: Expands shorteners (*bit.ly*, *tinyurl*) up to 6 hops without executing client scripts.
* **Threat Heuristics**: Detects malicious TLDs (`.top`, `.buzz`, `.cc`), raw IP hostnames, and typosquats (e.g. `sbi-kyc-verify-portal.top` vs `onlinesbi.sbi`).

---

### 7. 🚨 Legal & Emergency Hub (1930 & Chakshu)
* **Direct Dial 1930**: 1-tap call button with the "Golden Hour" guide (freezing mule accounts within 2 hours).
* **Automated Complaint Generator**: Drafts formal incident reports citing Section 66D/66C IT Act and Section 420 IPC ready to copy into `cybercrime.gov.in`.

---

## 🛠️ Project Architecture

```
scamlens/
├── .github/
│   └── workflows/
│       └── deploy.yml        # Automated GitHub Pages CI/CD workflow
├── .gitignore                # Excludes node_modules, dist, zip
├── Dockerfile                # Production multi-stage container
├── render.yaml               # 1-Click Render.com deployment manifest
├── vercel.json               # Vercel SPA routing configuration
├── package.json              # Dependencies & scripts
├── vite.config.js            # Vite build configuration (base: './')
├── index.html                # Application root HTML
├── public/
│   └── manifest.json         # PWA Manifest
├── server/
│   └── index.js              # Express 5 backend & REST APIs
└── src/
    ├── App.jsx               # Root application & URL param routing
    ├── index.css             # TailwindCSS v4 imports & theme
    ├── main.jsx              # React 19 entry point
    ├── components/
    │   ├── CallGuardian.jsx          # Phone lookup & Red Signal call HUD
    │   ├── EmergencyHub.jsx          # 1930 guide & legal complaint generator
    │   ├── Header.jsx                # Responsive header & phone access modal
    │   ├── HighlightViewer.jsx       # Character-offset colored text highlighter
    │   ├── ImageMailScanner.jsx      # OCR image screenshot & email radar
    │   ├── MobileBottomNav.jsx       # Mobile bottom navigation bar
    │   ├── MobileBottomSheet.jsx     # Psychological trap deconstruction
    │   ├── PsychologicalInspector.jsx# Psychology trick details
    │   ├── QrScanner.jsx             # Camera & image QR code verifier
    │   ├── ScamAnalyzer.jsx          # Core text analyzer & threat score
    │   ├── ScamScoreMeter.jsx        # Circular gauge threat score
    │   ├── TemplateSelector.jsx      # Preset scam category browser
    │   ├── UrlSandbox.jsx            # URL unshortener & threat sandbox
    │   ├── VoiceAlertBar.jsx         # Multilingual voice verdict bar
    │   └── WhatsAppVerifier.jsx      # Interactive WhatsApp studio & radar
    ├── data/
    │   ├── emailScams.js             # Phishing email headers & templates
    │   ├── psychologyTricks.js       # Social engineering manipulation tricks
    │   ├── qrScams.js                # Demo QR traps (UPI collect, APK)
    │   ├── scamNumbers.js            # Reported cybercrime phone database
    │   ├── templates.js              # Standard Indian scam SMS templates
    │   ├── threatRules.js            # NLP trigger regex rules & keywords
    │   └── whatsappScams.js          # WhatsApp conversations & SVG demo images
    └── services/
        ├── nlpEngine.js              # NLP regex & heuristic scoring engine
        ├── ocrService.js             # Client-side Tesseract OCR service
        ├── qrThreatService.js        # UPI parameters & QR payload inspector
        ├── urlThreatService.js       # URL threat & domain spoof detector
        └── voiceAlertService.js      # Web Speech & Web Audio synthesizer
```

---

## 🚀 Step-by-Step Deployment Guide

### Option 1: Deploy to GitHub Pages (100% Free, Automated CI/CD)

The repository includes a ready-to-use GitHub Actions workflow in [`.github/workflows/deploy.yml`](.github/workflows/deploy.yml).

1. **Create a GitHub Repository**:
   * Go to [github.com/new](https://github.com/new).
   * Set Repository Name to **`scamlens`**.
   * Set visibility to **Public** *(required for free GitHub Pages)*.
   * Do NOT check "Initialize with README".
   * Click **Create repository**.

2. **Push Code to GitHub**:
   ```bash
   cd scamlens
   git remote add origin https://github.com/<YOUR_USERNAME>/scamlens.git
   git branch -M main
   git push -u origin main
   ```

3. **Activate GitHub Pages in Settings**:
   * Open your repository on GitHub.
   * Go to **Settings > Pages** *(left sidebar)*.
   * Under **Build and deployment > Source**, choose **`GitHub Actions`**.
   * Go to the **Actions** tab to watch the build finish (~45 seconds).
   * Your site will be live at:
     ```
     https://<YOUR_USERNAME>.github.io/scamlens/
     ```

---

### Option 2: Deploy to Vercel (1-Click Frontend + API)

Vercel provides automated HTTPS certificates and global CDN delivery:

1. Push your code to GitHub (Option 1 above).
2. Go to [vercel.com/new](https://vercel.com/new) and log in with GitHub.
3. Click **Import** next to your `scamlens` repository.
4. Keep the Framework Preset as **Vite** and Root Directory as `./`.
5. Click **Deploy**.
6. Vercel uses the included [`vercel.json`](vercel.json) to configure SPA routing. Your site will be live at `https://scamlens.vercel.app`.

---

### Option 3: Deploy Full-Stack to Render.com (Node.js Backend + Frontend)

Render supports hosting the Express backend along with the Vite frontend:

1. Push your code to GitHub.
2. Go to [render.com](https://render.com) and click **New > Blueprint**.
3. Select your `scamlens` GitHub repository.
4. Render will detect the included [`render.yaml`](render.yaml) file:
   * **Build Command**: `npm install && npm run build`
   * **Start Command**: `node server/index.js`
   * **Port**: `3001`
5. Click **Apply**. Render will deploy the full-stack app with a custom `https://scamlens.onrender.com` domain.

---

### Option 4: Deploy with Docker Container

A production-ready multi-stage Dockerfile is included:

```bash
# Build the Docker image
docker build -t scamlens .

# Run the container on port 3001
docker run -d -p 3001:3001 --name scamlens-app scamlens
```
Open **http://localhost:3001** in your browser.

---

## 💻 Local Development

```bash
# 1. Install dependencies
npm install

# 2. Run the Vite development server (hot-reload on port 5173)
npm run dev

# 3. Build for production
npm run build

# 4. Start the full-stack production server (serves dist/ on port 3001)
npm run server
```

---

## 🛡️ License

ISC License • Built for public cybercrime defense and citizen awareness.
