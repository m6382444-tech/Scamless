import React, { useState, useEffect, useRef } from 'react';
import { 
  QrCode, ShieldAlert, AlertTriangle, CheckCircle, Upload, Camera, 
  ExternalLink, ArrowRight, RefreshCw, Zap, ShieldCheck, AlertOctagon, 
  Copy, Check, FileText, Info 
} from 'lucide-react';
import QRCode from 'qrcode';
import jsQR from 'jsqr';
import { QR_SCAM_DEMOS } from '../data/qrScams.js';
import { evaluateQrPayload } from '../services/qrThreatService.js';

export default function QrScanner({ onNavigateToSandbox }) {
  const [activeDemoId, setActiveDemoId] = useState('olx-upi-scam');
  const [currentPayload, setCurrentPayload] = useState(QR_SCAM_DEMOS[0].qrPayload);
  const [qrImageUrl, setQrImageUrl] = useState('');
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(false);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState('');
  const [copied, setCopied] = useState(false);

  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);
  const animationFrameRef = useRef(null);

  // Generate QR code image whenever currentPayload changes
  useEffect(() => {
    if (currentPayload) {
      generateQrImage(currentPayload);
      runEvaluation(currentPayload);
    }
  }, [currentPayload]);

  const generateQrImage = async (text) => {
    try {
      const url = await QRCode.toDataURL(text, {
        width: 320,
        margin: 2,
        color: {
          dark: '#ffffff',
          light: '#020617'
        }
      });
      setQrImageUrl(url);
    } catch (err) {
      console.error("QR generation error:", err);
    }
  };

  const runEvaluation = async (text) => {
    setLoading(true);
    try {
      const result = await evaluateQrPayload(text);
      setAnalysis(result);
    } catch (err) {
      console.error("Evaluation error:", err);
    } finally {
      setLoading(false);
    }
  };

  // Handle image upload from file or paste
  const handleFileUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    decodeImageFile(file);
  };

  const decodeImageFile = (file) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        
        // Decode with jsQR
        const code = jsQR(imageData.data, imageData.width, imageData.height);
        if (code) {
          setCurrentPayload(code.data);
          setActiveDemoId(null);
        } else {
          alert("No valid QR code could be read from this image. Please ensure the QR is clear and well-lit.");
        }
      };
      img.src = event.target.result;
    };
    reader.readAsDataURL(file);
  };

  // Camera Scanning Stream
  const startCamera = async () => {
    setIsCameraActive(true);
    setCameraError('');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute('playsinline', 'true');
        videoRef.current.play();
        scanCameraFrame();
      }
    } catch (err) {
      console.error("Camera access error:", err);
      setCameraError("Camera access denied or unavailable. Please use file upload instead.");
      setIsCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
    }
    setIsCameraActive(false);
  };

  const scanCameraFrame = () => {
    if (videoRef.current && videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA) {
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        canvas.height = videoRef.current.videoHeight;
        canvas.width = videoRef.current.videoWidth;
        ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height);
        if (code) {
          setCurrentPayload(code.data);
          setActiveDemoId(null);
          stopCamera();
          return;
        }
      }
    }
    animationFrameRef.current = requestAnimationFrame(scanCameraFrame);
  };

  useEffect(() => {
    return () => stopCamera();
  }, []);

  const handleSelectDemo = (demo) => {
    stopCamera();
    setActiveDemoId(demo.id);
    setCurrentPayload(demo.qrPayload);
  };

  const handleCopyPayload = () => {
    navigator.clipboard.writeText(currentPayload);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="p-4 sm:p-6 rounded-2xl bg-gradient-to-r from-rose-950/60 via-slate-900 to-slate-900 border border-rose-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center space-x-3.5">
          <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400 shrink-0">
            <QrCode className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-lg sm:text-2xl font-bold text-white">
                QR Code Shield & Fraud Verifier
              </h2>
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/30">
                UPI & URL Radar
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
              Scan or upload any QR code to reveal hidden phishing links, fake "Receive Money" UPI collect traps, and malicious APK droppers.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2 w-full md:w-auto">
          {!isCameraActive ? (
            <button
              onClick={startCamera}
              className="flex-1 md:flex-initial px-4 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 font-bold text-xs sm:text-sm text-white shadow-lg flex items-center justify-center space-x-1.5 transition-all"
            >
              <Camera className="w-4 h-4" />
              <span>Scan via Camera</span>
            </button>
          ) : (
            <button
              onClick={stopCamera}
              className="flex-1 md:flex-initial px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 font-semibold text-xs text-slate-200 border border-slate-700 flex items-center justify-center space-x-1.5"
            >
              <span>Stop Camera</span>
            </button>
          )}
        </div>
      </div>

      {/* Demo QR Scams Selector Carousel */}
      <div className="p-3.5 sm:p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2.5">
        <div className="flex items-center justify-between text-xs">
          <span className="font-bold text-white uppercase tracking-wider text-[11px] flex items-center space-x-1.5">
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>Interactive Demo QR Scams (Test Instantly):</span>
          </span>
          <span className="text-slate-400 text-[11px]">Click any chip to decode and analyze</span>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none text-xs">
          {QR_SCAM_DEMOS.map((demo) => (
            <button
              key={demo.id}
              onClick={() => handleSelectDemo(demo)}
              className={`px-3 py-1.5 rounded-xl shrink-0 transition-all font-semibold text-[11px] flex items-center space-x-1.5 border ${
                activeDemoId === demo.id
                  ? 'bg-rose-600 text-white border-rose-500 shadow-md'
                  : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
              }`}
            >
              <span>{demo.title}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Two-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left: QR Display / Upload / Camera Stream */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col items-center justify-center text-center space-y-4 shadow-inner">
            
            {/* Live Camera View */}
            {isCameraActive ? (
              <div className="relative w-full aspect-square max-w-[280px] rounded-2xl overflow-hidden bg-black border-2 border-rose-500 shadow-2xl">
                <video ref={videoRef} className="w-full h-full object-cover"></video>
                <canvas ref={canvasRef} className="hidden"></canvas>
                {/* Laser scanline animation */}
                <div className="absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-rose-500 to-transparent animate-bounce"></div>
                <div className="absolute bottom-2 inset-x-0 text-center">
                  <span className="px-2 py-0.5 rounded-full bg-black/70 text-[10px] text-white font-mono">
                    Point camera at any QR code
                  </span>
                </div>
              </div>
            ) : qrImageUrl ? (
              /* Generated / Uploaded QR Code Canvas */
              <div className="relative p-4 rounded-2xl bg-slate-950 border border-slate-800 shadow-2xl group">
                <img
                  src={qrImageUrl}
                  alt="Decoded QR Code"
                  className="w-56 h-56 object-contain rounded-xl shadow-lg border border-slate-800/80"
                />
                <div className="absolute top-2 right-2 px-2 py-0.5 rounded-md bg-slate-900/90 border border-slate-700 text-[10px] text-slate-400 font-mono">
                  {analysis?.payloadType || 'QR Payload'}
                </div>
              </div>
            ) : null}

            {cameraError && (
              <p className="text-xs text-rose-400 font-medium">{cameraError}</p>
            )}

            {/* Upload or Drop Action */}
            <div className="w-full space-y-2">
              <label className="w-full py-3 px-4 rounded-xl bg-slate-950 hover:bg-slate-800/80 border border-dashed border-slate-700 hover:border-rose-500 text-slate-300 text-xs font-semibold flex items-center justify-center space-x-2 cursor-pointer transition-colors">
                <Upload className="w-4 h-4 text-rose-400" />
                <span>Upload QR Image / Screenshot</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>

              <p className="text-[11px] text-slate-400">
                You can also paste a screenshot from your clipboard (<kbd className="px-1 py-0.5 rounded bg-slate-800 text-[10px] text-slate-300">Ctrl+V</kbd>)
              </p>
            </div>

          </div>
        </div>

        {/* Right: Threat Intelligence & Payload Inspector */}
        <div className="lg:col-span-7 space-y-4">
          
          {analysis && (
            <div className={`p-5 sm:p-6 rounded-2xl border transition-all ${
              analysis.threatScore >= 75
                ? 'bg-gradient-to-b from-red-950/40 to-slate-900 border-red-500/60 shadow-xl'
                : analysis.threatScore >= 40
                ? 'bg-amber-950/30 to-slate-900 border-amber-500/50'
                : 'bg-emerald-950/30 to-slate-900 border-emerald-500/50'
            }`}>
              
              {/* Verdict Header */}
              <div className="flex items-start justify-between gap-3 pb-3 border-b border-slate-800">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border ${
                      analysis.threatScore >= 75
                        ? 'bg-red-500/20 text-red-400 border-red-500/40 animate-pulse'
                        : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                    }`}>
                      {analysis.threatLevel}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">
                      Type: {analysis.payloadType}
                    </span>
                  </div>

                  <h3 className="text-lg sm:text-xl font-extrabold text-white mt-1.5">
                    {analysis.threatScore >= 75
                      ? '⚠️ HIGH-SEVERITY SCAM QR DETECTED'
                      : '✅ VERIFIED SAFE QR CODE'}
                  </h3>
                </div>

                <div className="text-right">
                  <div className={`text-2xl sm:text-3xl font-black font-mono ${
                    analysis.threatScore >= 75 ? 'text-red-500' : 'text-emerald-400'
                  }`}>
                    {analysis.threatScore}%
                  </div>
                  <span className="text-[9px] uppercase font-bold text-slate-400 tracking-wider">
                    Threat Index
                  </span>
                </div>
              </div>

              {/* Decoded Raw Payload Box */}
              <div className="my-3 p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <div className="flex items-center justify-between text-[10px] text-slate-400 font-bold uppercase">
                  <span>Decoded QR String:</span>
                  <button
                    onClick={handleCopyPayload}
                    className="flex items-center space-x-1 text-slate-300 hover:text-white"
                  >
                    {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copied ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <p className="font-mono text-xs text-amber-300 break-all select-all">
                  {analysis.rawPayload}
                </p>
              </div>

              {/* Parsed Parameter Breakdown (e.g. for UPI) */}
              {analysis.payloadType === 'UPI Payment Intent' && (
                <div className="p-3.5 rounded-xl bg-slate-950/90 border border-slate-800 space-y-2 text-xs">
                  <div className="font-bold text-white flex items-center space-x-1.5">
                    <Info className="w-3.5 h-3.5 text-indigo-400" />
                    <span>UPI Transaction Parameters Extracted:</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-[11px]">
                    <div>
                      <span className="text-slate-400 block">Payee VPA Handle:</span>
                      <span className="font-mono font-bold text-white break-all">
                        {analysis.parsedParams.pa}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Merchant / Name:</span>
                      <span className="font-bold text-slate-200">
                        {analysis.parsedParams.pn}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Configured Amount:</span>
                      <span className={`font-mono font-bold text-sm ${
                        analysis.parsedParams.am ? 'text-red-400' : 'text-emerald-400'
                      }`}>
                        {analysis.parsedParams.am ? `₹${analysis.parsedParams.am} (WILL BE DEBITED)` : 'User Enters Amount'}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Transaction Note:</span>
                      <span className="font-mono text-slate-300">
                        {analysis.parsedParams.tn}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Red Flags Trigger List */}
              {analysis.threatFlags && analysis.threatFlags.length > 0 && (
                <div className="my-3 space-y-1.5">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    Detected Threat Red Flags:
                  </p>
                  <div className="space-y-1.5">
                    {analysis.threatFlags.map((flag, idx) => (
                      <div key={idx} className="p-2.5 rounded-xl bg-red-950/40 border border-red-500/30 text-xs space-y-0.5">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-red-300">{flag.type}</span>
                          <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-red-500/20 text-red-400 border border-red-500/30 uppercase">
                            {flag.severity}
                          </span>
                        </div>
                        <p className="text-slate-300 text-[11px]">{flag.detail}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Plain-English Meaning & Safe Action Protocol */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4 pt-3 border-t border-slate-800 text-xs">
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <span className="font-bold text-amber-400 flex items-center space-x-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span>The Scam Mechanism</span>
                  </span>
                  <p className="text-slate-300 text-[11px] leading-relaxed">
                    {analysis.plainWarning}
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/30 space-y-1">
                  <span className="font-bold text-emerald-400 flex items-center space-x-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Safe Action Guide</span>
                  </span>
                  <p className="text-emerald-200/90 text-[11px] leading-relaxed">
                    {analysis.safeAction}
                  </p>
                </div>
              </div>

              {/* Navigation button if URL */}
              {analysis.payloadType === 'Web Hyperlink (URL)' && (
                <div className="mt-4 pt-3 border-t border-slate-800 flex justify-end">
                  <button
                    onClick={() => onNavigateToSandbox(analysis.rawPayload)}
                    className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs flex items-center space-x-1.5 shadow"
                  >
                    <span>Inspect Target in URL Sandbox</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

            </div>
          )}

        </div>

      </div>
    </div>
  );
}
