import React, { useState, useEffect, useRef } from 'react';
import { 
  PhoneCall, PhoneOff, ShieldAlert, AlertTriangle, Radio, Search, CheckCircle, 
  Volume2, VolumeX, Shield, Play, Pause, AlertOctagon, UserX, ExternalLink, 
  HelpCircle, Sparkles, RotateCcw, Edit2, PlusCircle, Check 
} from 'lucide-react';
import { SCAM_CALLER_DATABASE, evaluatePhoneNumber } from '../data/scamNumbers.js';

export default function CallGuardian({ prefilledNumber }) {
  const [phoneNumber, setPhoneNumber] = useState(prefilledNumber || '+91 98765 43210');
  const [customCallerName, setCustomCallerName] = useState('');
  const [forceScamMode, setForceScamMode] = useState(true);
  const [lookupResult, setLookupResult] = useState(() => evaluatePhoneNumber(prefilledNumber || '+91 98765 43210'));
  
  // Community Reporting State
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [reportCategory, setReportCategory] = useState('Electricity Disconnection Threat');
  const [reportNotes, setReportNotes] = useState('');
  const [reportSuccess, setReportSuccess] = useState(false);

  // Incoming Call Simulator State
  const [isCallActive, setIsCallActive] = useState(false);
  const [callState, setCallState] = useState('ringing'); // 'ringing' | 'connected' | 'rejected'
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [transcriptIndex, setTranscriptIndex] = useState(0);
  const audioContextRef = useRef(null);
  const oscillatorRef = useRef(null);

  useEffect(() => {
    if (prefilledNumber) {
      setPhoneNumber(prefilledNumber);
      handleSearch(prefilledNumber);
    }
  }, [prefilledNumber]);

  // Audio tone generator for red signal alarm
  const playAlertSound = () => {
    if (!soundEnabled) return;
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!AudioContext) return;
      
      const ctx = new AudioContext();
      audioContextRef.current = ctx;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(800, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(400, ctx.currentTime + 0.3);

      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.3);
      oscillatorRef.current = osc;
    } catch (e) {
      console.warn("Audio alert unavailable:", e);
    }
  };

  const stopAudio = () => {
    if (audioContextRef.current) {
      try {
        audioContextRef.current.close();
      } catch {}
    }
  };

  // Ringing effect loop
  useEffect(() => {
    let interval;
    if (isCallActive && callState === 'ringing') {
      playAlertSound();
      interval = setInterval(() => {
        playAlertSound();
      }, 1500);
    } else {
      stopAudio();
    }
    return () => {
      clearInterval(interval);
      stopAudio();
    };
  }, [isCallActive, callState, soundEnabled]);

  // Transcript progression when call is answered in simulator
  useEffect(() => {
    let transcriptInterval;
    if (isCallActive && callState === 'connected') {
      const activeData = activeSimulation;
      if (activeData?.audioTranscript) {
        transcriptInterval = setInterval(() => {
          setTranscriptIndex(prev => {
            if (prev < activeData.audioTranscript.length - 1) {
              return prev + 1;
            }
            return prev;
          });
        }, 3200);
      }
    }
    return () => clearInterval(transcriptInterval);
  }, [isCallActive, callState, lookupResult, customCallerName]);

  const handleSearch = (numberToSearch) => {
    const num = numberToSearch !== undefined ? numberToSearch : phoneNumber;
    if (!num) return;
    const res = evaluatePhoneNumber(num);
    setLookupResult(res);
  };

  const handlePhoneInputChange = (e) => {
    const val = e.target.value;
    setPhoneNumber(val);
    if (val.trim()) {
      const res = evaluatePhoneNumber(val);
      setLookupResult(res);
    }
  };

  const startCallSimulation = (selectedNumber) => {
    if (selectedNumber) {
      setPhoneNumber(selectedNumber);
      handleSearch(selectedNumber);
    }
    setCallState('ringing');
    setTranscriptIndex(0);
    setIsCallActive(true);
    
    if (navigator.vibrate) {
      try {
        navigator.vibrate([400, 200, 400, 200, 800]);
      } catch {}
    }
  };

  const handleRejectCall = () => {
    setCallState('rejected');
    stopAudio();
    setTimeout(() => {
      setIsCallActive(false);
    }, 1200);
  };

  const handleAnswerCall = () => {
    setCallState('connected');
    stopAudio();
  };

  const handleCommunityReport = (e) => {
    e.preventDefault();
    setReportSuccess(true);
    setTimeout(() => {
      setReportSuccess(false);
      setReportModalOpen(false);
      // update lookup result to critical
      setLookupResult(prev => ({
        ...prev,
        isScam: true,
        threatScore: 98,
        threatLevel: "Community Blacklisted",
        reportCount: (prev?.reportCount || 0) + 1,
        reasons: [
          `Reported by you just now as '${reportCategory}'`,
          ...(prev?.reasons || [])
        ]
      }));
    }, 1200);
  };

  const isScamVerdict = lookupResult ? (lookupResult.isScam || forceScamMode) : true;

  const activeSimulation = lookupResult?.details?.incomingSimulation || {
    callerDisplay: customCallerName || lookupResult?.callerName || "Suspected Caller",
    subText: isScamVerdict ? "High Risk Cyber Threat • Real-time Red Signal" : "Standard Mobile Call",
    ringtoneNote: "Red Signal Alarm tone",
    audioTranscript: [
      { speaker: "Caller", time: "00:01", text: `Hello, this is an urgent notification regarding phone number ${phoneNumber}.` },
      { speaker: "Caller", time: "00:06", text: "Your KYC and bank account have pending compliance issues. You must verify credentials immediately." },
      { speaker: "Caller", time: "00:12", text: "Do not hang up, or penalty charges and legal suspension will be processed right now!" }
    ]
  };

  return (
    <div className="space-y-6 sm:space-y-8">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-red-950/70 via-slate-900 to-slate-900 p-4 sm:p-6 rounded-2xl border border-red-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center space-x-3.5">
          <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-red-600/20 border border-red-500/40 flex items-center justify-center text-red-400 shrink-0">
            <Radio className="w-5 h-5 sm:w-6 sm:h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-lg sm:text-2xl font-bold text-white">
                Call Guardian & Red Signal Radar
              </h2>
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/30">
                Live Interceptor
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
              Verify real scam phone numbers, inspect carrier routes, and trigger the <strong>flashing Red Signal visual alarm</strong>.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          <button
            onClick={() => setReportModalOpen(true)}
            className="flex-1 md:flex-initial px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 font-semibold text-xs text-rose-300 border border-rose-500/40 flex items-center justify-center space-x-1.5 transition-colors"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Report a Scam Number</span>
          </button>
          
          <button
            onClick={() => startCallSimulation()}
            className="flex-1 md:flex-initial px-4 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 font-bold text-white text-xs shadow-lg shadow-red-950/50 flex items-center justify-center space-x-1.5 transition-all"
          >
            <PhoneCall className="w-4 h-4 animate-bounce" />
            <span>Simulate Incoming Call</span>
          </button>
        </div>
      </div>

      {/* Main Two-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 sm:gap-6 items-start">
        
        {/* Left: Phone Lookup & Database */}
        <div className="lg:col-span-7 space-y-5 sm:space-y-6">
          
          {/* Lookup Input Card */}
          <div className="p-4 sm:p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 shadow-md">
            <div className="flex items-center justify-between">
              <h3 className="text-sm sm:text-base font-bold text-white flex items-center space-x-2">
                <Search className="w-4 h-4 text-rose-500" />
                <span>Verify Real Scam Numbers (Chakshu Radar)</span>
              </h3>
              <span className="text-[11px] text-emerald-400 font-semibold bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-500/30">
                Interactive Check
              </span>
            </div>

            {/* Input Field */}
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative flex-1">
                <input
                  type="text"
                  value={phoneNumber}
                  onChange={handlePhoneInputChange}
                  placeholder="Enter phone number (e.g. +91 98765 43210 or +92...)"
                  className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 font-mono text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-rose-500"
                />
              </div>
              <button
                onClick={() => handleSearch()}
                className="px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs sm:text-sm border border-slate-700 transition-colors flex items-center justify-center space-x-1"
              >
                <span>Check Number</span>
              </button>
            </div>

            {/* Custom Caller Name & Mode Options */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1 text-xs">
              <div>
                <label className="text-slate-400 text-[11px] font-medium block mb-1">Custom Caller Display Name (Optional):</label>
                <input
                  type="text"
                  value={customCallerName}
                  onChange={(e) => setCustomCallerName(e.target.value)}
                  placeholder="e.g. Fake Electricity Officer / Delhi Police"
                  className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 placeholder-slate-600 text-xs focus:outline-none focus:ring-1 focus:ring-rose-500"
                />
              </div>
              <div className="flex flex-col justify-end">
                <div className="flex items-center space-x-2 bg-slate-950 p-2 rounded-lg border border-slate-800">
                  <input
                    type="checkbox"
                    id="force-scam-toggle"
                    checked={forceScamMode}
                    onChange={(e) => setForceScamMode(e.target.checked)}
                    className="w-4 h-4 rounded text-rose-600 focus:ring-rose-500 border-slate-700 bg-slate-900"
                  />
                  <label htmlFor="force-scam-toggle" className="text-[11px] text-slate-300 font-medium cursor-pointer">
                    Force 🔴 Red Signal Alarm for this test
                  </label>
                </div>
              </div>
            </div>

            {/* Quick Demo Preset Chips */}
            <div>
              <p className="text-[11px] text-slate-400 mb-2 font-medium">Or Test Verified High-Risk Scam Callers:</p>
              <div className="flex flex-wrap gap-1.5 text-xs">
                {SCAM_CALLER_DATABASE.map((item, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setPhoneNumber(item.number);
                      setCustomCallerName('');
                      handleSearch(item.number);
                    }}
                    className={`px-2.5 py-1.5 rounded-lg border text-left transition-all ${
                      phoneNumber === item.number
                        ? 'bg-rose-500/20 border-rose-500 text-rose-300 font-semibold'
                        : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <span className="font-mono text-[11px]">{item.number}</span>
                    <span className="text-[9px] text-slate-400 block truncate max-w-[120px]">{item.category}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Search Result Card */}
          {lookupResult && (
            <div className={`p-5 sm:p-6 rounded-2xl border transition-all ${
              lookupResult.isScam
                ? 'bg-gradient-to-b from-red-950/40 to-slate-900 border-red-500/60 shadow-xl shadow-red-950/20'
                : 'bg-slate-900 border-slate-800'
            }`}>
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className={`text-[10px] sm:text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border ${
                      lookupResult.isScam
                        ? 'bg-red-500/20 text-red-400 border-red-500/40 animate-pulse'
                        : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                    }`}>
                      {lookupResult.threatLevel}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">
                      {phoneNumber}
                    </span>
                  </div>
                  <h4 className="text-lg sm:text-xl font-extrabold text-white mt-1.5">
                    {customCallerName || lookupResult.callerName}
                  </h4>
                  <p className="text-xs sm:text-sm font-semibold text-rose-400 mt-0.5">
                    Category: {lookupResult.category}
                  </p>
                </div>

                {/* Threat Score Badge */}
                <div className="text-right">
                  <div className="text-2xl sm:text-3xl font-extrabold text-red-500 font-mono">
                    {lookupResult.riskScore}%
                  </div>
                  <div className="text-[9px] sm:text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                    Scam Risk
                  </div>
                </div>
              </div>

              {/* Meta stats */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 my-3.5 py-3 border-y border-slate-800 text-xs">
                <div>
                  <span className="text-slate-400 block text-[11px]">Reported Incidents:</span>
                  <span className="font-bold text-white text-xs sm:text-sm">
                    {lookupResult.reportCount > 0 ? `${lookupResult.reportCount}+ Confirmed Reports` : '0 Prior Reports'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Carrier Route:</span>
                  <span className="font-semibold text-slate-200 text-[11px] truncate block">
                    {lookupResult.carrier}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Circle:</span>
                  <span className="font-semibold text-slate-200 text-[11px] truncate block">
                    {lookupResult.circle}
                  </span>
                </div>
              </div>

              {/* Threat Indicators List */}
              <div className="space-y-1.5">
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Detected Threat Heuristics:
                </p>
                <ul className="space-y-1 text-xs text-slate-300">
                  {lookupResult.reasons.map((r, i) => (
                    <li key={i} className="flex items-start space-x-2">
                      <AlertTriangle className="w-3.5 h-3.5 text-red-400 shrink-0 mt-0.5" />
                      <span className="text-[11px] sm:text-xs">{r}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Action buttons */}
              <div className="mt-4 pt-3.5 border-t border-slate-800/80 flex flex-wrap gap-2.5">
                <button
                  onClick={() => startCallSimulation(phoneNumber)}
                  className="px-3.5 py-2 rounded-xl bg-red-600 hover:bg-red-500 font-bold text-xs text-white flex items-center space-x-1.5 shadow"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>Launch Red Signal Call HUD</span>
                </button>
                <a
                  href="https://sancharsaathi.gov.in/sfc/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 font-semibold text-xs text-amber-400 border border-amber-500/30 flex items-center space-x-1.5"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>File Complaint on Chakshu (DoT)</span>
                </a>
              </div>

            </div>
          )}

        </div>

        {/* Right: Phone Simulator with Flashing RED SIGNAL Alert */}
        <div className="lg:col-span-5">
          <div className="sticky top-20 sm:top-24 space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-400 px-1">
              <span className="font-semibold uppercase tracking-wider text-[11px]">
                Mobile Incoming Call HUD
              </span>
              <button
                onClick={() => setSoundEnabled(!soundEnabled)}
                className="flex items-center space-x-1 text-slate-400 hover:text-white text-[11px]"
                title="Toggle Warning Sound"
              >
                {soundEnabled ? (
                  <>
                    <Volume2 className="w-3.5 h-3.5 text-rose-400" />
                    <span>Siren Audio ON</span>
                  </>
                ) : (
                  <>
                    <VolumeX className="w-3.5 h-3.5 text-slate-500" />
                    <span>Audio Muted</span>
                  </>
                )}
              </button>
            </div>

            {/* Smartphone Enclosure */}
            <div className={`relative mx-auto w-full max-w-[320px] sm:max-w-[340px] rounded-[38px] p-3 bg-slate-950 border-[5px] transition-all duration-300 shadow-2xl overflow-hidden ${
              isCallActive && callState === 'ringing'
                ? 'border-red-500 animate-red-signal'
                : 'border-slate-800'
            }`}>
              
              {/* Speaker & Camera Notch */}
              <div className="absolute top-3.5 left-1/2 -translate-x-1/2 w-28 h-3.5 bg-slate-900 rounded-full flex items-center justify-center space-x-2 z-20">
                <div className="w-2 h-2 rounded-full bg-slate-950 border border-slate-800"></div>
                <div className="w-8 h-1 rounded-full bg-slate-800"></div>
              </div>

              {/* Screen Content */}
              <div className={`rounded-[30px] p-5 pt-8 min-h-[480px] sm:min-h-[500px] flex flex-col justify-between relative transition-all ${
                isCallActive && callState === 'ringing'
                  ? 'animate-siren-bg bg-gradient-to-b from-red-950/80 via-slate-950 to-slate-950'
                  : 'bg-slate-900/90'
              }`}>
                
                {/* IDLE STATE */}
                {!isCallActive && (
                  <div className="flex flex-col items-center justify-center text-center my-auto space-y-3.5">
                    <div className="w-14 h-14 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-400">
                      <Shield className="w-7 h-7 text-emerald-400" />
                    </div>
                    <div>
                      <h5 className="font-bold text-white text-sm">Call Guardian Armed</h5>
                      <p className="text-[11px] text-slate-400 mt-1 max-w-[200px] mx-auto">
                        Ready to intercept suspicious calls from <strong>{phoneNumber}</strong>
                      </p>
                    </div>
                    <button
                      onClick={() => startCallSimulation()}
                      className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-xs font-bold text-white shadow-lg shadow-red-950/40"
                    >
                      Trigger Call Test
                    </button>
                  </div>
                )}

                {/* ACTIVE CALL - RINGING (RED SIGNAL ALERT) */}
                {isCallActive && callState === 'ringing' && (
                  <>
                    {/* Pulsing RED SIGNAL Banner */}
                    <div className="text-center space-y-2">
                      <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-red-600 text-white font-extrabold text-[10px] tracking-wider uppercase shadow-lg shadow-red-900/60 animate-bounce">
                        <AlertOctagon className="w-3.5 h-3.5" />
                        <span>🔴 RED SIGNAL: SCAM ALERT</span>
                      </div>
                      
                      <div className="text-2xl sm:text-3xl font-black text-red-500 tracking-tight animate-pulse font-mono">
                        {lookupResult?.riskScore || 98}% SCAM
                      </div>

                      <div className="pt-1">
                        <div className="text-[10px] font-semibold uppercase tracking-widest text-slate-400">
                          Incoming Call
                        </div>
                        <h4 className="text-lg font-bold text-white mt-0.5 leading-snug">
                          {activeSimulation.callerDisplay}
                        </h4>
                        <div className="text-xs font-mono text-rose-300">
                          {phoneNumber}
                        </div>
                        <p className="text-[10px] text-red-400 font-semibold mt-1 bg-red-950/60 py-0.5 px-2 rounded-lg border border-red-500/40">
                          {activeSimulation.subText}
                        </p>
                      </div>
                    </div>

                    {/* In-Call Safety Warning Card */}
                    <div className="my-3 p-2.5 rounded-xl bg-red-950/70 border border-red-500/50 text-[10px] text-red-200 space-y-0.5 text-left">
                      <p className="font-bold flex items-center space-x-1 text-white">
                        <AlertTriangle className="w-3 h-3 text-red-400" />
                        <span>SCAMLENS DEFENSE RULES:</span>
                      </p>
                      <p>• NEVER transfer money to "secure accounts"</p>
                      <p>• Police NEVER issue arrest warrants on video</p>
                      <p>• NEVER install remote apps (AnyDesk/APK)</p>
                    </div>

                    {/* Action Buttons: Reject vs Answer */}
                    <div className="pt-2">
                      <div className="flex items-center justify-around">
                        
                        {/* Reject / Block Button */}
                        <div className="flex flex-col items-center space-y-1">
                          <button
                            onClick={handleRejectCall}
                            className="w-14 h-14 rounded-full bg-red-600 hover:bg-red-700 text-white flex items-center justify-center shadow-lg shadow-red-950/80 transition-all transform hover:scale-110 active:scale-95"
                            title="Reject and Block Number"
                          >
                            <PhoneOff className="w-6 h-6" />
                          </button>
                          <span className="text-[10px] font-bold text-red-400">Reject & Block</span>
                        </div>

                        {/* Answer Button (Simulation Mode) */}
                        <div className="flex flex-col items-center space-y-1">
                          <button
                            onClick={handleAnswerCall}
                            className="w-14 h-14 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white flex items-center justify-center shadow-lg shadow-emerald-950/80 transition-all transform hover:scale-110 active:scale-95"
                            title="Answer in Simulator to inspect audio"
                          >
                            <PhoneCall className="w-6 h-6" />
                          </button>
                          <span className="text-[10px] font-semibold text-emerald-400">Inspect Audio</span>
                        </div>

                      </div>
                    </div>
                  </>
                )}

                {/* CONNECTED STATE (LIVE AUDIO TRANSCRIPT STREAM) */}
                {isCallActive && callState === 'connected' && (
                  <div className="flex flex-col justify-between h-full space-y-3">
                    <div className="text-center">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/30">
                        Live Call Analyzer
                      </span>
                      <h4 className="text-sm font-bold text-white mt-1">
                        {activeSimulation.callerDisplay}
                      </h4>
                      <p className="text-[11px] font-mono text-slate-400">{phoneNumber}</p>
                    </div>

                    {/* Live Transcript Box */}
                    <div className="flex-1 bg-slate-950/90 rounded-2xl p-2.5 border border-slate-800 space-y-2 overflow-y-auto max-h-[240px] text-xs">
                      <div className="text-[9px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-800 pb-1 flex items-center justify-between">
                        <span>Real-time Audio Transcript</span>
                        <span className="inline-flex h-2 w-2 rounded-full bg-rose-500 animate-ping"></span>
                      </div>
                      
                      {activeSimulation.audioTranscript.slice(0, transcriptIndex + 1).map((line, idx) => (
                        <div key={idx} className="p-2 rounded-lg bg-red-950/30 border border-red-500/20 animate-in fade-in">
                          <div className="flex justify-between text-[9px] text-rose-400 font-semibold mb-0.5">
                            <span>{line.speaker}</span>
                            <span>{line.time}</span>
                          </div>
                          <p className="text-slate-200 text-[11px]">{line.text}</p>
                        </div>
                      ))}
                    </div>

                    <button
                      onClick={handleRejectCall}
                      className="w-full py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs flex items-center justify-center space-x-1.5"
                    >
                      <PhoneOff className="w-3.5 h-3.5" />
                      <span>Hang Up & Block Caller</span>
                    </button>
                  </div>
                )}

                {/* REJECTED / BLOCKED STATE */}
                {isCallActive && callState === 'rejected' && (
                  <div className="my-auto text-center space-y-2.5">
                    <div className="w-12 h-12 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/40 flex items-center justify-center mx-auto">
                      <UserX className="w-6 h-6" />
                    </div>
                    <div>
                      <h5 className="text-base font-bold text-white">Call Terminated & Blocked</h5>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Threat deflected safely. Zero credentials shared.
                      </p>
                    </div>
                  </div>
                )}

              </div>
            </div>

            <p className="text-center text-[10px] text-slate-400">
              ScamLens Incoming Call Guardian alerts users before answering suspicious calls.
            </p>
          </div>
        </div>

      </div>

      {/* Community Number Reporting Modal */}
      {reportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl">
            <div className="flex items-center space-x-2 text-white">
              <ShieldAlert className="w-5 h-5 text-rose-500" />
              <h3 className="text-base font-bold">Report a Scam Number</h3>
            </div>
            <p className="text-xs text-slate-400">
              Submit suspicious numbers to flag them on ScamLens and prepare a Chakshu Sanchar Saathi complaint.
            </p>

            <form onSubmit={handleCommunityReport} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">Suspect Phone Number:</label>
                <input
                  type="text"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  required
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono focus:outline-none focus:ring-1 focus:ring-rose-500"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Scam Category:</label>
                <select
                  value={reportCategory}
                  onChange={(e) => setReportCategory(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-1 focus:ring-rose-500"
                >
                  <option value="Electricity Disconnection Threat">Electricity Disconnection Threat</option>
                  <option value="Digital Arrest / Police Extortion">Digital Arrest / Police Extortion</option>
                  <option value="Banking YONO / KYC Phishing">Banking YONO / KYC Phishing</option>
                  <option value="Part-Time Telegram Job Scam">Part-Time Telegram Job Scam</option>
                  <option value="Courier / India Post Smishing">Courier / India Post Smishing</option>
                  <option value="Loan App Harassment">Loan App Harassment</option>
                </select>
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Incident Notes & Modus Operandi:</label>
                <textarea
                  value={reportNotes}
                  onChange={(e) => setReportNotes(e.target.value)}
                  rows={3}
                  placeholder="e.g. Caller threatened power cut tonight unless I installed AnyDesk..."
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-1 focus:ring-rose-500"
                ></textarea>
              </div>

              {reportSuccess && (
                <div className="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-xs flex items-center space-x-1.5">
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span>Number successfully added to local blacklist!</span>
                </div>
              )}

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setReportModalOpen(false)}
                  className="flex-1 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold shadow"
                >
                  Confirm Report
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
