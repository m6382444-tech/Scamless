# ScamLens Backend – REST API & Threat Intelligence Service

A lightweight, high-performance Node.js & Express 5 backend microservice providing:
- **NLP Cognitive Trap Analysis API** (`POST /api/analyze`)
- **Safe SSRF-Protected URL Unshortener** (`POST /api/unshorten`)
- **Domain & Phishing Threat Intelligence** (`POST /api/threat-intel`)
- **Caller GPS Location & Subscriber Identity Radar** (`POST /api/phone-lookup`)
- **Chakshu & 1930 Legal Complaint Draft Generator** (`POST /api/generate-complaint`)

---

## 🚀 Quick Setup & Run

```bash
# 1. Install dependencies
npm install

# 2. Run in development mode (with auto-restart)
npm run dev

# 3. Run in production mode
npm start
```
Server runs on **http://localhost:3001** (or `$PORT`).

---

## 📡 API Endpoints & cURL Examples

### 1. Caller GPS & Identity Lookup
```bash
curl -X POST http://localhost:3001/api/phone-lookup \
  -H "Content-Type: application/json" \
  -d '{"number": "+91 98765 43210"}'
```
**Response**:
```json
{
  "isScam": true,
  "riskScore": 98,
  "threatLevel": "Critical Scam",
  "category": "Electricity Disconnection Threat",
  "callerName": "Electricity Officer Mr. Sharma (SPOOFED)",
  "carrier": "Virtual / Leased PRI Gateway",
  "circle": "Mumbai / Maharashtra",
  "location": "Mumbai, Maharashtra, India",
  "coordinates": { "lat": 19.076, "lng": 72.8777 }
}
```

### 2. NLP Message Red-Flag Analysis
```bash
curl -X POST http://localhost:3001/api/analyze \
  -H "Content-Type: application/json" \
  -d '{"text": "Electricity will be disconnected tonight at 9:30 PM. Call Mr. Sharma at 9876543210"}'
```

### 3. Safe URL Unshortener (SSRF Protected)
```bash
curl -X POST http://localhost:3001/api/unshorten \
  -H "Content-Type: application/json" \
  -d '{"url": "https://bit.ly/power-pay-bill"}'
```

---

## 🌐 1-Click Deployment (Render / Railway / Docker)

1. **Render.com**: Connect this directory to Render; it detects the included `render.yaml` automatically.
2. **Railway / Fly.io / Cloud Run**: Deploy with the included multi-stage `Dockerfile`.
3. **AWS / VPS**: Run `docker build -t scamlens-backend . && docker run -p 3001:3001 scamlens-backend`.
