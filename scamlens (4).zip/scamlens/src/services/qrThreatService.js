import { analyzeUrlThreat } from './urlThreatService.js';
import { analyzeMessageNLP } from './nlpEngine.js';

export async function evaluateQrPayload(rawPayload) {
  if (!rawPayload || typeof rawPayload !== 'string') {
    return {
      isValid: false,
      error: "No QR code payload detected"
    };
  }

  const trimmed = rawPayload.trim();
  const threatFlags = [];
  let riskScore = 10;
  let payloadType = "Unknown String";
  let parsedParams = {};
  let plainWarning = "Standard QR code.";
  let safeAction = "Verify the destination before taking action.";

  // 1. UPI Payment URI Analysis (upi://pay?...)
  if (trimmed.startsWith('upi://') || trimmed.includes('pa=') || trimmed.includes('pn=')) {
    payloadType = "UPI Payment Intent";
    try {
      let queryString = trimmed.includes('?') ? trimmed.split('?')[1] : trimmed;
      const urlParams = new URLSearchParams(queryString);
      parsedParams = {
        pa: urlParams.get('pa') || 'N/A', // Payee Address (VPA)
        pn: urlParams.get('pn') || 'N/A', // Payee Name
        am: urlParams.get('am') || null,   // Amount
        cu: urlParams.get('cu') || 'INR',  // Currency
        tn: urlParams.get('tn') || 'N/A',  // Transaction Note
        mc: urlParams.get('mc') || null    // Merchant Code
      };

      const vpa = parsedParams.pa.toLowerCase();
      const amount = parsedParams.am;
      const note = parsedParams.tn.toLowerCase();

      // Threat 1: Reverse UPI Collect Request (OLX / Marketplace Scam)
      if (amount && parseFloat(amount) > 0) {
        riskScore += 55;
        threatFlags.push({
          type: "Pre-Configured Debit Amount",
          severity: "Critical",
          detail: `This QR code attempts to DEDUCT ₹${amount} from your bank account! Scanning it will NOT receive money.`
        });
        plainWarning = `CRITICAL ALERT: This QR code is configured to DEBIT ₹${amount} from your account. If someone sent you this saying 'Scan to Receive Money', it is an ACTIVE SCAM. You NEVER enter your UPI PIN to receive money.`;
        safeAction = "Do NOT scan this code or enter your UPI PIN. Entering your PIN will instantly deduct money from your account.";
      }

      // Threat 2: Deceptive VPA Keywords
      const deceptiveVpaWords = ['refund', 'kyc', 'support', 'discom', 'cashback', 'reward', 'gift', 'helpline', 'officer', 'olx'];
      const matchedWord = deceptiveVpaWords.find(w => vpa.includes(w));
      if (matchedWord) {
        riskScore += 30;
        threatFlags.push({
          type: `Deceptive VPA Keyword ('${matchedWord}')`,
          severity: "High",
          detail: `The UPI handle '${parsedParams.pa}' uses words like '${matchedWord}' to impersonate official support services.`
        });
      }

      // Safe merchant check
      if (parsedParams.pn.includes('VerifiedMerchant') || vpa.endsWith('@icici') && !amount) {
        riskScore = 5;
        plainWarning = "Legitimate merchant payment QR code. Standard checkout flow.";
        safeAction = "Safe to proceed if you intend to purchase from this merchant.";
      }

    } catch (err) {
      threatFlags.push({
        type: "Malformed UPI Syntax",
        severity: "Medium",
        detail: "Unusual UPI parameter formatting detected."
      });
    }
  } 
  // 2. Web Hyperlink (http / https)
  else if (trimmed.startsWith('http://') || trimmed.startsWith('https://') || trimmed.includes('.com') || trimmed.includes('.top') || trimmed.includes('.buzz')) {
    payloadType = "Web Hyperlink (URL)";
    
    // Analyze URL using URL Threat Service
    try {
      const urlThreat = await analyzeUrlThreat(trimmed);
      riskScore = urlThreat.riskScore;
      parsedParams = {
        hostname: urlThreat.hostname,
        protocol: urlThreat.protocol,
        isShortener: urlThreat.isShortener,
        unshortenedDestination: urlThreat.unshortenedDestination
      };

      urlThreat.redFlags.forEach(f => {
        threatFlags.push({
          type: f.type,
          severity: f.severity,
          detail: f.detail
        });
      });

      plainWarning = urlThreat.sandboxDetails?.safeVerdictDescription || "Web URL embedded in QR code.";
      safeAction = riskScore >= 70
        ? "Do NOT open this link in your browser. It points to a high-risk phishing destination or malware dropper."
        : "Verify sender before entering credentials.";
    } catch {
      riskScore += 25;
      threatFlags.push({
        type: "Unverified Web Destination",
        severity: "Medium",
        detail: "Could not safely verify destination host."
      });
    }
  } 
  // 3. Plain Text / SMS
  else {
    payloadType = "Plain Text / Command";
    const nlpResult = analyzeMessageNLP(trimmed);
    if (nlpResult.threatScore > 30) {
      riskScore = nlpResult.threatScore;
      nlpResult.highlights.forEach(h => {
        threatFlags.push({
          type: h.label,
          severity: h.severity,
          detail: `Contains manipulation trigger: "${h.text}"`
        });
      });
      plainWarning = nlpResult.verdictSummary;
      safeAction = "Do not comply with unsolicited instructions embedded in QR codes.";
    }
  }

  const finalScore = Math.min(100, Math.max(5, riskScore));
  let threatLevel = "Safe / Low Risk";
  if (finalScore >= 80) {
    threatLevel = "CRITICAL FRAUD / THREAT";
  } else if (finalScore >= 50) {
    threatLevel = "HIGH RISK SUSPICIOUS QR";
  } else if (finalScore >= 25) {
    threatLevel = "CAUTION REQUIRED";
  }

  return {
    isValid: true,
    rawPayload: trimmed,
    payloadType,
    parsedParams,
    threatScore: finalScore,
    threatLevel,
    threatFlags,
    plainWarning,
    safeAction
  };
}
